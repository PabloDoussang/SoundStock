from django.contrib import messages
from django.contrib.auth import authenticate, login as iniciar_sesion, logout as cerrar_sesion, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_http_methods, require_POST

from inventario.access import roles_permitidos
from .models import Usuario


def _destino_seguro(request):
    destino = request.POST.get('next', '') if request.method == 'POST' else request.GET.get('next', '')
    return destino if destino and url_has_allowed_host_and_scheme(destino,
        allowed_hosts={request.get_host()}, require_https=request.is_secure()) else None


@sensitive_post_parameters('password')
@require_http_methods(['GET', 'POST'])
def ingresar(request):
    destino = _destino_seguro(request)
    if request.user.is_authenticated:
        return redirect(destino or 'inicio')
    datos = {'username': '', 'next': destino or ''}
    errores = {}
    if request.method == 'POST':
        datos['username'] = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        if not datos['username'] or not password:
            errores['general'] = ['Escribe tu nombre de usuario y contraseña.']
        elif len(datos['username']) > 150 or len(password) > 4096:
            errores['general'] = ['Usuario o contraseña incorrectos.']
        else:
            usuario = authenticate(request, username=datos['username'], password=password)
            if usuario is None:
                errores['general'] = ['Usuario o contraseña incorrectos, o cuenta desactivada.']
            else:
                iniciar_sesion(request, usuario)
                messages.success(request, 'Sesión iniciada correctamente.')
                return redirect(destino or 'inicio')
    return render(request, 'registration/login.html', {'datos': datos, 'errores': errores, 'next': datos['next']})


@require_POST
def salir(request):
    cerrar_sesion(request)
    messages.success(request, 'Sesión cerrada correctamente.')
    return redirect('login')


@roles_permitidos('Administrador')
def lista(request):
    rows = Usuario.objects.order_by('username')
    q = request.GET.get('q', '').strip()
    if q:
        rows = rows.filter(Q(username__icontains=q) | Q(email__icontains=q))
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    return render(request, 'usuarios/lista.html', {
        'pagina': Paginator(rows, 20).get_page(request.GET.get('pagina')),
        'filtros_query': parametros.urlencode(),
    })


def _errores_modelo(errores, error):
    detalle = error.message_dict if hasattr(error, 'message_dict') else {'general': error.messages}
    for campo, lista in detalle.items():
        errores.setdefault('general' if campo == '__all__' else campo, []).extend(str(mensaje) for mensaje in lista)


def _capturar_usuario(request, usuario):
    datos = {campo: request.POST.get(campo, '').strip() for campo in (
        'username', 'first_name', 'last_name', 'email', 'rol')}
    datos['is_active'] = request.POST.get('is_active', '').lower() in ('on', '1', 'true')
    errores = {}
    if usuario.pk == request.user.pk and (datos['rol'] != 'Administrador' or not datos['is_active']):
        errores['general'] = ['No puedes desactivar tu propia cuenta ni quitarte el rol Administrador.']
    for campo, valor in datos.items():
        setattr(usuario, campo, valor)
    duplicado = Usuario.objects.filter(username__iexact=datos['username']).exclude(pk=usuario.pk).exists()
    if duplicado:
        errores['username'] = ['Ya existe un usuario con ese nombre.']
    if not usuario.pk:
        usuario.set_unusable_password()
    try:
        usuario.full_clean()
    except ValidationError as error:
        _errores_modelo(errores, error)
    return datos, errores


def _validar_clave(password, confirmacion, usuario, errores, campo='password1', campo2='password2'):
    if not password:
        errores[campo] = ['La contraseña es obligatoria.']
    elif len(password) > 4096:
        errores[campo] = ['La contraseña es demasiado larga.']
    else:
        try:
            validate_password(password, user=usuario)
        except ValidationError as error:
            errores[campo] = list(error.messages)
    if password != confirmacion:
        errores[campo2] = ['Las contraseñas no coinciden.']


@sensitive_post_parameters('password1', 'password2')
@roles_permitidos('Administrador')
def crear(request):
    datos = {'username': '', 'first_name': '', 'last_name': '', 'email': '', 'rol': 'Consulta', 'is_active': True}
    errores = {}
    if request.method == 'POST':
        usuario = Usuario()
        datos, errores = _capturar_usuario(request, usuario)
        password = request.POST.get('password1', '')
        _validar_clave(password, request.POST.get('password2', ''), usuario, errores)
        if not errores:
            try:
                with transaction.atomic():
                    usuario.set_password(password)
                    usuario.save()
                messages.success(request, 'Usuario creado.')
                return redirect('usuarios')
            except IntegrityError:
                errores['username'] = ['Ya existe un usuario con ese nombre.']
    return render(request, 'gestion/formulario.html', {'tipo_formulario': 'usuario', 'crear_usuario': True,
        'datos': datos, 'errores': errores, 'roles': Usuario.ROLES, 'titulo': 'Crear usuario', 'volver': 'usuarios'})


@roles_permitidos('Administrador')
def editar(request, pk):
    with transaction.atomic():
        usuario = get_object_or_404(Usuario.objects.select_for_update(), pk=pk)
        datos = {campo: getattr(usuario, campo) for campo in ('username', 'first_name', 'last_name', 'email', 'rol', 'is_active')}
        errores = {}
        if request.method == 'POST':
            datos, errores = _capturar_usuario(request, usuario)
            if not errores:
                try:
                    with transaction.atomic():
                        usuario.save()
                    messages.success(request, 'Usuario actualizado.')
                    return redirect('usuarios')
                except IntegrityError:
                    errores['username'] = ['Ya existe un usuario con ese nombre.']
    return render(request, 'gestion/formulario.html', {'tipo_formulario': 'usuario', 'crear_usuario': False,
        'datos': datos, 'errores': errores, 'roles': Usuario.ROLES, 'titulo': 'Editar usuario', 'volver': 'usuarios'})


@require_POST
@roles_permitidos('Administrador')
def cambiar_estado(request, pk):
    with transaction.atomic():
        usuario = get_object_or_404(Usuario.objects.select_for_update(), pk=pk)
        if usuario.pk == request.user.pk:
            messages.error(request, 'No puedes desactivar tu propia cuenta.')
        else:
            usuario.is_active = not usuario.is_active
            usuario.save()
            messages.success(request, 'Estado del usuario actualizado. Se conserva su historial.')
    return redirect('usuarios')


@sensitive_post_parameters('new_password1', 'new_password2')
@roles_permitidos('Administrador')
def clave(request, pk):
    usuario = get_object_or_404(Usuario, pk=pk)
    errores = {}
    if request.method == 'POST':
        password = request.POST.get('new_password1', '')
        _validar_clave(password, request.POST.get('new_password2', ''), usuario, errores, 'new_password1', 'new_password2')
        if not errores:
            usuario.set_password(password)
            usuario.save(update_fields=['password'])
            if usuario.pk == request.user.pk:
                update_session_auth_hash(request, usuario)
            messages.success(request, 'Contraseña actualizada.')
            return redirect('usuarios')
    return render(request, 'gestion/formulario.html', {'tipo_formulario': 'clave', 'datos': {}, 'errores': errores,
        'titulo': f'Cambiar contraseña de {usuario.username}', 'volver': 'usuarios'})
