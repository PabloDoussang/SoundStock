from django.contrib import admin
from django.conf import settings
from usuarios import views as usuarios_views
from django.urls import include, path

admin.site.site_header = 'SoundStock · Administración'
admin.site.site_title = 'SoundStock Admin'
admin.site.index_title = 'Usuarios, catálogo e inventario'

urlpatterns = [
    path('ingresar/', usuarios_views.ingresar, name='login'),
    path('salir/', usuarios_views.salir, name='logout'),
    path('productos/', include('catalogo.urls')),
    path('usuarios/', include('usuarios.urls')),
    path('', include('inventario.urls')),
]

if settings.HABILITAR_DJANGO_ADMIN:
    urlpatterns += [path('admin/', admin.site.urls)]
