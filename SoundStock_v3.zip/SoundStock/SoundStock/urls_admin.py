"""Rutas de compatibilidad para las pruebas de la Evaluación 2."""
from django.contrib import admin
from django.urls import path
from .urls import urlpatterns as propias

urlpatterns = propias + [path('admin/', admin.site.urls)]
