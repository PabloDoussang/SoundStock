from django.urls import path
from . import views

urlpatterns = [
    path('', views.lista, name='usuarios'),
    path('nuevo/', views.crear, name='usuario_crear'),
    path('<int:pk>/editar/', views.editar, name='usuario_editar'),
    path('<int:pk>/estado/', views.cambiar_estado, name='usuario_estado'),
    path('<int:pk>/clave/', views.clave, name='usuario_clave'),
]
