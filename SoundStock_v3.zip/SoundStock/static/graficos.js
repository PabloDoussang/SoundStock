/* Gráficos locales a partir de JSON escapado por Django. Sin CDN. */
(() => {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const colors = ['#9984e7', '#67c6b1', '#e9b366', '#de8e9d', '#7da1cf', '#b8a4c9', '#83bdcd', '#c8bd92'];
  const format = (n, unit = '') => new Intl.NumberFormat('es-CL', {maximumFractionDigits: unit === 'CLP' ? 2 : 0}).format(n);
  const text = (tag, value, className) => { const el = document.createElement(tag); if (className) el.className = className; if (value !== undefined) el.textContent = value; return el; };
  const svg = (tag, attrs = {}, value) => { const el = document.createElementNS(NS, tag); Object.entries(attrs).forEach(([k,v]) => el.setAttribute(k, String(v))); if (value !== undefined) el.textContent = value; return el; };
  function tooltip(host) {
    const tip = text('div', '', 'chart-tooltip'); tip.setAttribute('role', 'status'); host.append(tip);
    return {show(value, x, y) { tip.textContent = value; tip.classList.add('visible'); const width = tip.offsetWidth; tip.style.left = Math.max(0, Math.min(x, host.clientWidth - width)) + 'px'; tip.style.top = Math.max(0, y - tip.offsetHeight - 8) + 'px'; }, hide() { tip.classList.remove('visible'); }};
  }
  function legend(host, data) {
    if (data.series.length < 2) return;
    const list = text('div', undefined, 'chart-legend');
    data.series.forEach((s, i) => { const item = text('span'); const dot = text('i'); dot.style.background = s.color || colors[i % colors.length]; item.append(dot, text('span', s.name)); list.append(item); }); host.append(list);
  }
  function empty(host, message = 'Todavía no hay datos para mostrar.') { const el = text('div', message, 'chart-empty'); host.append(el); }
  function line(host, data, id) {
    const width=Math.max(280,Math.min(1000,Math.round(host.clientWidth || 800))), height=238, pad={l:38,r:18,t:20,b:35};
    const pw=width-pad.l-pad.r, ph=height-pad.t-pad.b, count=data.labels.length;
    if (!count) { empty(host); return; }
    const maxRaw=Math.max(4,...data.series.flatMap(s=>s.values));
    const magnitude=10 ** Math.floor(Math.log10(maxRaw/4));
    const step=Math.ceil(maxRaw/4/magnitude)*magnitude, maximum=step*4;
    const x=i=>pad.l+(count>1 ? i/(count-1)*pw : pw/2), y=n=>pad.t+ph-Math.max(0,n)/maximum*ph;
    const root=svg('svg',{viewBox:`0 0 ${width} ${height}`,role:'img','aria-label':host.getAttribute('aria-label') || 'Gráfico de movimientos'});
    root.append(svg('title',{},'Entradas y salidas por día'),svg('desc',{},'Pasa el cursor por el gráfico o enfoca un punto para consultar las unidades exactas. Los datos también están en la tabla.'));
    const defs=svg('defs');root.append(defs);
    for(let i=0;i<=4;i++){ const value=step*i, cy=y(value);root.append(svg('line',{x1:pad.l,y1:cy,x2:width-pad.r,y2:cy,class:'chart-grid'}),svg('text',{x:pad.l-9,y:cy+3,'text-anchor':'end'},format(value))); }
    [...new Set(Array.from({length:6},(_,i)=>Math.round((count-1)*i/5)))].forEach(i=>root.append(svg('text',{x:x(i),y:height-11,'text-anchor':'middle'},data.labels[i])));
    data.series.forEach((s,j)=>{
      const color=s.color || colors[j];const gradient=svg('linearGradient',{id:`${id}-gradient-${j}`,x1:'0',y1:'0',x2:'0',y2:'1'});
      gradient.append(svg('stop',{offset:'0%','stop-color':color,'stop-opacity':'.17'}),svg('stop',{offset:'100%','stop-color':color,'stop-opacity':'.015'}));defs.append(gradient);
      const path=s.values.map((n,i)=>`${i===0?'M':'L'}${x(i)},${y(n)}`).join(' ');
      root.append(svg('path',{d:`${path} L${x(count-1)},${y(0)} L${x(0)},${y(0)} Z`,fill:`url(#${id}-gradient-${j})`}));
      root.append(svg('path',{d:path,fill:'none',stroke:color,'stroke-width':'2.6','stroke-linejoin':'round','stroke-linecap':'round'}));
    });
    const guide=svg('line',{x1:0,x2:0,y1:pad.t,y2:height-pad.b,stroke:'#bcb4df','stroke-dasharray':'3 4',opacity:0});root.append(guide);
    host.append(root);const tip=tooltip(host);
    const show=(index,positionX,positionY)=>{guide.setAttribute('x1',x(index));guide.setAttribute('x2',x(index));guide.setAttribute('opacity','1');tip.show(data.labels[index]+'\n'+data.series.map(s=>`${s.name}: ${format(s.values[index])} ${data.unit || ''}`).join('\n'),positionX,positionY);};
    root.addEventListener('pointermove',e=>{const box=root.getBoundingClientRect();const px=(e.clientX-box.left)/box.width*width;const i=Math.max(0,Math.min(count-1,Math.round((px-pad.l)/pw*(count-1))));const parent=host.getBoundingClientRect();show(i,e.clientX-parent.left+10,e.clientY-parent.top);});
    root.addEventListener('pointerleave',()=>{tip.hide();guide.setAttribute('opacity','0');});
    data.series.forEach((s,j)=>s.values.forEach((value,i)=>{
      if (i % Math.max(1,Math.ceil(count/12)) !== 0 && i!==count-1) return;
      const point=svg('circle',{cx:x(i),cy:y(value),r:3,fill:s.color||colors[j],stroke:'white','stroke-width':1.5,tabindex:0,role:'img','aria-label':`${data.labels[i]}, ${s.name}: ${format(value)} unidades`});
      point.append(svg('title',{},`${data.labels[i]} · ${s.name}: ${format(value)}`));
      point.addEventListener('focus',()=>{const box=root.getBoundingClientRect();show(i,x(i)/width*box.width,y(value)/height*box.height);});point.addEventListener('blur',()=>{tip.hide();guide.setAttribute('opacity','0');});root.append(point);
    }));
    if(data.series.every(s=>s.values.every(v=>v===0))) {const note=text('p','Sin entradas ni salidas durante este período.','chart-caption');host.append(note);}
  }
  function bar(host,data){
    if(!data.labels.length){empty(host,'No hay resultados para esta selección.');return;}
    legend(host,data);const maximum=Math.max(1,...data.series.flatMap(s=>s.values));
    data.labels.forEach((label,i)=>{
      const row=text('div',undefined,'bar-row');row.tabIndex=0;row.setAttribute('role','img');row.setAttribute('aria-label',label+'. '+data.series.map(s=>s.name+': '+format(s.values[i],data.unit)+' '+data.unit).join('. '));row.title=row.getAttribute('aria-label');
      const name=text('span',label,'bar-name');const values=text('div',undefined,'bar-values');
      data.series.forEach((s,j)=>{const group=text('div',undefined,'bar-series');const track=text('div',undefined,'bar-track');const fill=text('div',undefined,'bar-fill');fill.style.width=(Math.max(0,s.values[i])/maximum*100)+'%';fill.style.background=s.color || (data.series.length===1 ? colors[i%colors.length] : colors[j%colors.length]);track.append(fill);group.append(track,text('span',format(s.values[i],data.unit),'bar-value'));values.append(group);});
      row.append(name,values);host.append(row);
    });
  }
  function donut(host,data){
    const values=data.series[0]?.values || [],total=values.reduce((a,b)=>a+b,0),radius=62,length=2*Math.PI*radius;
    const wrap=text('div',undefined,'donut-wrap');const root=svg('svg',{viewBox:'0 0 180 180',role:'img','aria-label':host.getAttribute('aria-label') || 'Distribución por estado'});
    root.append(svg('circle',{cx:90,cy:90,r:radius,fill:'none',stroke:'#f2f0f8','stroke-width':19}));
    const center=text('div',undefined,'donut-center');center.append(text('strong',format(total)),text('span',data.unit||'registros'));
    wrap.append(root,center);host.append(wrap);const tip=tooltip(host);let offset=0;
    values.forEach((value,i)=>{
      if(!value || !total)return;const arc=length*value/total;
      const circle=svg('circle',{cx:90,cy:90,r:radius,fill:'none',stroke:(data.colors||colors)[i%((data.colors||colors).length)],'stroke-width':19,'stroke-dasharray':`${Math.max(0,arc-3)} ${length-Math.max(0,arc-3)}`,'stroke-dashoffset':-offset,transform:'rotate(-90 90 90)',tabindex:0,role:'img','aria-label':`${data.labels[i]}: ${format(value)}, ${format(value/total*100)}%`});
      const title=`${data.labels[i]}: ${format(value)} (${format(value/total*100)}%)`;circle.append(svg('title',{},title));
      circle.addEventListener('pointerenter',e=>{const box=host.getBoundingClientRect();tip.show(title,e.clientX-box.left,e.clientY-box.top);});circle.addEventListener('pointerleave',()=>tip.hide());circle.addEventListener('focus',()=>tip.show(title,host.clientWidth/2,90));circle.addEventListener('blur',()=>tip.hide());root.append(circle);offset+=arc;
    });
    const list=text('div',undefined,'donut-legend');data.labels.forEach((label,i)=>{const item=text('div');const dot=text('i');dot.style.background=(data.colors||colors)[i%((data.colors||colors).length)];item.append(dot,text('span',label),text('strong',format(values[i]||0)));list.append(item);});host.append(list);
    if(total===0)empty(host,'Cuando registres solicitudes, verás aquí su distribución.');
  }
  document.querySelectorAll('[data-chart]').forEach((host,index)=>{
    try{
      const source=document.getElementById(host.dataset.chart);if(!source)return;
      const data=JSON.parse(source.textContent);
      data.series.forEach(s=>{s.values=s.values.map(v=>{const n=Number(v);return Number.isFinite(n)?n:0;});});
      if(data.type==='line') {
        line(host,data,`chart-${index}`);
        let previousWidth=host.clientWidth;
        if(window.ResizeObserver) new ResizeObserver(()=>{
          const currentWidth=host.clientWidth;
          if(currentWidth>0 && Math.abs(currentWidth-previousWidth)>2) {
            previousWidth=currentWidth;host.replaceChildren();line(host,data,`chart-${index}`);
          }
        }).observe(host);
      } else if(data.type==='donut')donut(host,data);else bar(host,data);
      host.dataset.rendered='true';
    }catch(error){empty(host,'Consulta la tabla para ver los datos de este gráfico.');host.dataset.rendered='error';}
  });
})();
