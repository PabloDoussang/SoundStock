/* Interacciones del CRUD. Sin dependencias ni solicitudes a servicios externos. */
(() => {
  'use strict';
  const sidebar = document.querySelector('.sidebar');
  const opener = document.querySelector('.abrir-menu');
  const closeMenu = () => {
    document.body.classList.remove('sidebar-open');
    opener?.setAttribute('aria-expanded', 'false');
    opener?.focus({preventScroll: true});
  };
  opener?.addEventListener('click', () => {
    document.body.classList.add('sidebar-open');
    opener.setAttribute('aria-expanded', 'true');
    sidebar.querySelector('.cerrar-menu')?.focus();
  });
  document.querySelector('.cerrar-menu')?.addEventListener('click', closeMenu);
  document.querySelector('.sidebar-overlay')?.addEventListener('click', closeMenu);
  document.addEventListener('keydown', event => {
    if (!document.body.classList.contains('sidebar-open')) return;
    if (event.key === 'Escape') closeMenu();
    if (event.key === 'Tab') {
      const elements = [...sidebar.querySelectorAll('a[href], button, input')].filter(el => el.offsetParent !== null);
      const first = elements[0], last = elements[elements.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  window.matchMedia('(min-width:1001px)').addEventListener('change', event => {
    if (event.matches && document.body.classList.contains('sidebar-open')) closeMenu();
  });
  document.querySelectorAll('[data-dismiss-message]').forEach(button => button.addEventListener('click', () => button.closest('.mensaje').remove()));
  document.querySelectorAll('[data-submit-on-change]').forEach(input => input.addEventListener('change', () => input.form.requestSubmit()));
  document.querySelector('[data-toggle-password]')?.addEventListener('click', event => {
    const button = event.currentTarget;
    const input = document.getElementById(button.dataset.togglePassword);
    const visible = input.type === 'password';
    input.type = visible ? 'text' : 'password';
    button.textContent = visible ? 'Ocultar' : 'Mostrar';
    button.setAttribute('aria-pressed', String(visible));
  });
  const reportSelect = document.getElementById('id_reporte');
  const updateReportFilters = () => {
    const needed = {2:['categoria'], 6:['proveedor'], 7:['sucursal'], 8:['solicitud'], 10:['desde','hasta'], 20:['desde','hasta']};
    document.querySelectorAll('[data-report-field]').forEach(wrapper => {
      const show = (needed[Number(reportSelect.value)] || []).includes(wrapper.dataset.reportField);
      // Un campo que tiene error sigue visible para explicar cómo corregirlo.
      wrapper.hidden = !show && !wrapper.classList.contains('field-error');
      const input = wrapper.querySelector('input,select');
      if (input) input.disabled = !show && !wrapper.classList.contains('field-error');
    });
  };
  if (reportSelect) { updateReportFilters(); reportSelect.addEventListener('change', updateReportFilters); }
  const addRow = document.getElementById('agregar-linea');
  addRow?.addEventListener('click', () => {
    const total = document.getElementById('id_detalles-TOTAL_FORMS');
    const index = Number(total.value);
    if (index >= 100) return;
    const content = document.getElementById('linea-vacia').innerHTML.replaceAll('__prefix__', String(index));
    document.getElementById('lineas-adicionales').insertAdjacentHTML('beforeend', content);
    total.value = index + 1;
    document.getElementById(`id_detalles-${index}-producto`)?.focus();
  });
  document.addEventListener('change', event => {
    if (event.target.matches('input[name$="-DELETE"]')) event.target.closest('tr')?.classList.toggle('row-deleted', event.target.checked);
  });
  document.querySelectorAll('form[method="post"]').forEach(form => form.addEventListener('submit', event => {
    if (form.dataset.submitting === '1') { event.preventDefault(); return; }
    form.dataset.submitting = '1';
    form.classList.add('form-submitting');
    form.setAttribute('aria-busy', 'true');
    // Los botones mantienen nombre y valor para aprobar/rechazar correctamente.
  }));
  window.addEventListener('pageshow', () => document.querySelectorAll('form[data-submitting]').forEach(form => {
    delete form.dataset.submitting; form.classList.remove('form-submitting'); form.removeAttribute('aria-busy');
  }));
})();
