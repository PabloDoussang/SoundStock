from datetime import datetime, time, timedelta
from decimal import Decimal
from io import StringIO
from uuid import uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.db import IntegrityError, transaction
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from catalogo.models import Categoria, Producto, Proveedor
from inventario.models import DetalleSolicitud, Movimiento, Solicitud, Sucursal
from inventario.reportes import generar_reporte
from inventario.services import (despachar_solicitud, eliminar_ultimo,
    registrar_movimiento, revisar_solicitud)
from usuarios.models import Usuario


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class BodegaE3Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = Usuario.objects.create_superuser('admin_e3', password='Prueba-SoundStock-2026!')
        cls.operador = Usuario.objects.create_user('op_e3', password='Prueba-SoundStock-2026!', rol='Operador')
        cls.consulta = Usuario.objects.create_user('ver_e3', password='Prueba-SoundStock-2026!')
        cls.cat = Categoria.objects.create(nombre='Cuerdas E3')
        cls.audio = Categoria.objects.create(nombre='Audio E3')
        cls.vacia = Categoria.objects.create(nombre='Vacía E3')
        cls.prov = Proveedor.objects.create(nombre='Proveedor E3 A')
        cls.otro_prov = Proveedor.objects.create(nombre='Proveedor E3 B')
        cls.sucursal = Sucursal.objects.create(nombre='Centro E3', direccion='Calle 1')
        cls.otra_sucursal = Sucursal.objects.create(nombre='Norte E3', direccion='Calle 2')
        cls.tercera_sucursal = Sucursal.objects.create(nombre='Sur E3', direccion='Calle 3')
        cls.p1 = Producto.objects.create(codigo='E3-GTR', nombre='Guitarra E3', categoria=cls.cat,
            proveedor=cls.prov, precio=100, stock_minimo=3, ubicacion='A')
        cls.p2 = Producto.objects.create(codigo='E3-BAS', nombre='Bajo E3', categoria=cls.cat,
            proveedor=cls.prov, precio=200, stock_minimo=2, ubicacion='B')
        cls.p3 = Producto.objects.create(codigo='E3-KEY', nombre='Teclado E3', categoria=cls.audio,
            proveedor=cls.otro_prov, precio=50, stock_minimo=5, ubicacion='C')
        cls.p4 = Producto.objects.create(codigo='E3-ARC', nombre='Archivado E3', categoria=cls.audio,
            precio=10, activo=False, ubicacion='D')
        for p, cantidad in [(cls.p1, 10), (cls.p2, 1), (cls.p3, 5)]:
            registrar_movimiento(producto_id=p.pk, usuario=cls.admin, tipo='entrada', cantidad=cantidad, motivo='Inicial E3')
        cls.pendiente = Solicitud.objects.create(sucursal=cls.sucursal, usuario=cls.operador)
        DetalleSolicitud.objects.create(solicitud=cls.pendiente, producto=cls.p1, cantidad=2)
        DetalleSolicitud.objects.create(solicitud=cls.pendiente, producto=cls.p2, cantidad=1)
        cls.aprobada = Solicitud.objects.create(sucursal=cls.otra_sucursal, usuario=cls.operador)
        DetalleSolicitud.objects.create(solicitud=cls.aprobada, producto=cls.p1, cantidad=4)
        revisar_solicitud(solicitud_id=cls.aprobada.pk, usuario=cls.admin, estado='aprobada')
        cls.rechazada = Solicitud.objects.create(sucursal=cls.sucursal, usuario=cls.operador)
        DetalleSolicitud.objects.create(solicitud=cls.rechazada, producto=cls.p1, cantidad=1)
        revisar_solicitud(solicitud_id=cls.rechazada.pk, usuario=cls.admin, estado='rechazada', respuesta='No corresponde')
        otra = Solicitud.objects.create(sucursal=cls.tercera_sucursal, usuario=cls.operador)
        DetalleSolicitud.objects.create(solicitud=otra, producto=cls.p3, cantidad=5)

    def setUp(self):
        self.client.force_login(self.admin)

    def formulario_solicitud(self, cantidad=2):
        return {'sucursal': self.sucursal.pk, 'observacion': 'Pedido de prueba',
            'detalles-TOTAL_FORMS': '1', 'detalles-INITIAL_FORMS': '0',
            'detalles-MIN_NUM_FORMS': '1', 'detalles-MAX_NUM_FORMS': '100',
            'detalles-0-producto': self.p1.pk, 'detalles-0-cantidad': str(cantidad)}

    def test_inicio_cierre_de_sesion_y_urls_directas(self):
        self.client.logout()
        for ruta in ['inicio', 'productos', 'categorias', 'proveedores', 'sucursales',
                     'solicitudes', 'usuarios', 'reportes', 'movimientos', 'ubicaciones']:
            with self.subTest(ruta=ruta):
                self.assertEqual(self.client.get(reverse(ruta)).status_code, 302)
        self.assertFalse(self.client.login(username='admin_e3', password='incorrecta'))
        response = self.client.post(reverse('login'), {'username': 'admin_e3', 'password': 'Prueba-SoundStock-2026!'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('_auth_user_id', self.client.session)
        self.assertEqual(self.client.get(reverse('logout')).status_code, 405)
        self.assertEqual(self.client.post(reverse('logout')).status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertEqual(self.client.get(reverse('reportes')).status_code, 302)

    def test_admin_django_desactivado_y_paginas_sin_cache(self):
        self.assertEqual(self.client.get('/admin/').status_code, 404)
        self.assertIn('no-store', self.client.get(reverse('inicio'))['Cache-Control'])

    def test_csrf_y_ausencia_de_mutaciones_por_get(self):
        protegido = Client(enforce_csrf_checks=True)
        protegido.force_login(self.admin)
        self.assertEqual(protegido.post(reverse('solicitud_despachar', args=[self.aprobada.pk])).status_code, 403)
        for ruta, pk in [('solicitud_despachar', self.aprobada.pk), ('solicitud_revisar', self.pendiente.pk),
                         ('usuario_estado', self.operador.pk), ('producto_archivar', self.p1.pk)]:
            self.assertEqual(self.client.get(reverse(ruta, args=[pk])).status_code, 405)

    def test_usuario_consulta_no_puede_modificar_ni_escalar_privilegios(self):
        self.client.force_login(self.consulta)
        for ruta in ['usuario_crear', 'usuarios', 'producto_crear', 'categorias_crear',
                     'proveedores_crear', 'sucursales_crear', 'solicitud_crear', 'movimiento_crear']:
            self.assertEqual(self.client.post(reverse(ruta), {'rol': 'Administrador'}).status_code, 403)
        self.assertEqual(self.client.post(reverse('solicitud_despachar', args=[self.aprobada.pk])).status_code, 403)
        self.client.force_login(self.operador)
        self.assertEqual(self.client.post(reverse('solicitud_revisar', args=[self.pendiente.pk]), {'estado': 'aprobada'}).status_code, 403)

    def test_crud_propio_de_usuarios_y_hash_de_clave(self):
        valores = {'username': 'nuevo_e3', 'rol': 'Consulta', 'is_active': 'on', 'email': 'e3@example.com',
            'password1': 'Clave-Nueva-SoundStock-2026!', 'password2': 'Clave-Nueva-SoundStock-2026!'}
        self.assertEqual(self.client.post(reverse('usuario_crear'), valores).status_code, 302)
        usuario = Usuario.objects.get(username='nuevo_e3')
        self.assertNotEqual(usuario.password, valores['password1'])
        self.assertTrue(usuario.check_password(valores['password1']))
        self.assertContains(self.client.get(reverse('usuarios'), {'q': 'nuevo_e3'}), 'nuevo_e3')
        valores.update(rol='Operador', first_name='Editado')
        self.client.post(reverse('usuario_editar', args=[usuario.pk]), valores)
        usuario.refresh_from_db()
        self.assertEqual(usuario.rol, 'Operador')
        self.assertFalse(usuario.is_superuser)
        self.client.post(reverse('usuario_estado', args=[usuario.pk]))
        self.assertFalse(Usuario.objects.get(pk=usuario.pk).is_active)
        self.assertFalse(self.client.login(username='nuevo_e3', password=valores['password1']))

    def test_proteccion_de_cuenta_propia_y_clave(self):
        self.client.post(reverse('usuario_estado', args=[self.admin.pk]))
        self.client.post(reverse('usuario_editar', args=[self.admin.pk]), {'username': self.admin.username,
            'rol': 'Consulta', 'is_active': 'on'})
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.is_active)
        self.assertEqual(self.admin.rol, 'Administrador')
        respuesta = self.client.post(reverse('usuario_clave', args=[self.admin.pk]), {
            'new_password1': 'Otra-Clave-SoundStock-2026!', 'new_password2': 'Otra-Clave-SoundStock-2026!'})
        self.assertEqual(respuesta.status_code, 302)
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password('Otra-Clave-SoundStock-2026!'))
        self.assertEqual(self.client.get(reverse('usuarios')).status_code, 200)

    def test_usuario_desactivado_pierde_sesion_en_la_siguiente_peticion(self):
        otro = Client()
        otro.force_login(self.operador)
        self.assertEqual(otro.get(reverse('inicio')).status_code, 200)
        self.client.post(reverse('usuario_estado', args=[self.operador.pk]))
        self.assertEqual(otro.get(reverse('inicio')).status_code, 302)

    def test_crud_catalogos_propios_y_relaciones_protegidas(self):
        for nombre, modelo, datos in [('categorias', Categoria, {'nombre': 'Temporal'}),
            ('proveedores', Proveedor, {'nombre': 'Temporal', 'email': 'temporal@example.com'}),
            ('sucursales', Sucursal, {'nombre': 'Temporal', 'direccion': 'Temporal 10'})]:
            with self.subTest(nombre=nombre):
                self.assertEqual(self.client.post(reverse(nombre + '_crear'), datos).status_code, 302)
                obj = modelo.objects.get(nombre='Temporal')
                datos['nombre'] = 'Temporal editado'
                self.assertEqual(self.client.post(reverse(nombre + '_editar', args=[obj.pk]), datos).status_code, 302)
                self.assertContains(self.client.get(reverse(nombre)), 'Temporal editado')
                self.assertEqual(self.client.get(reverse(nombre + '_eliminar', args=[obj.pk])).status_code, 200)
                self.client.post(reverse(nombre + '_eliminar', args=[obj.pk]))
                self.assertFalse(modelo.objects.filter(pk=obj.pk).exists())
        self.client.post(reverse('proveedores_eliminar', args=[self.prov.pk]))
        self.client.post(reverse('sucursales_eliminar', args=[self.sucursal.pk]))
        self.assertTrue(Proveedor.objects.filter(pk=self.prov.pk).exists())
        self.assertTrue(Sucursal.objects.filter(pk=self.sucursal.pk).exists())

    def test_filtros_y_formularios_invalidos_no_producen_error_servidor(self):
        for params in [{'categoria': 'texto'}, {'proveedor': '-1'}, {'categoria': '9' * 100}]:
            self.assertEqual(self.client.get(reverse('productos'), params).status_code, 200)
        for params in [{'reporte': 'abc'}, {'reporte': 2, 'categoria': 'abc'}, {'reporte': 10,
                       'desde': '2026-11-30', 'hasta': '2026-11-01'}, {'reporte': 20, 'desde': 'invalida'}]:
            respuesta = self.client.get(reverse('reportes'), params)
            self.assertEqual(respuesta.status_code, 200)
            self.assertTrue(respuesta.context['errores'])

    def test_alta_edicion_y_eliminacion_web_de_solicitud(self):
        datos = self.formulario_solicitud()
        self.assertEqual(self.client.post(reverse('solicitud_crear'), datos).status_code, 302)
        solicitud = Solicitud.objects.get(observacion='Pedido de prueba')
        detalle = solicitud.detalles.get()
        datos.update({'detalles-INITIAL_FORMS': '1', 'detalles-0-id': detalle.pk,
            'detalles-0-solicitud': solicitud.pk, 'detalles-0-cantidad': '3'})
        self.assertEqual(self.client.post(reverse('solicitud_editar', args=[solicitud.pk]), datos).status_code, 302)
        self.assertEqual(solicitud.detalles.get().cantidad, 3)
        self.assertContains(self.client.get(reverse('solicitud_detalle', args=[solicitud.pk])), 'Guitarra E3')
        self.client.post(reverse('solicitud_eliminar', args=[solicitud.pk]))
        self.assertFalse(Solicitud.objects.filter(pk=solicitud.pk).exists())
        self.p1.refresh_from_db()
        self.assertEqual(self.p1.stock, 10)

    def test_solicitud_sin_detalles_o_duplicados_no_se_guarda(self):
        for cantidad in ['0', '-1', 'invalida']:
            datos = self.formulario_solicitud(cantidad)
            self.assertEqual(self.client.post(reverse('solicitud_crear'), datos).status_code, 200)
        datos = self.formulario_solicitud()
        datos.update({'detalles-TOTAL_FORMS': '2', 'detalles-1-producto': self.p1.pk, 'detalles-1-cantidad': '3'})
        self.assertEqual(self.client.post(reverse('solicitud_crear'), datos).status_code, 200)
        self.assertFalse(Solicitud.objects.filter(observacion='Pedido de prueba').exists())

    def test_aprobacion_no_descontar_y_rechazo_obligatorio(self):
        self.client.post(reverse('solicitud_revisar', args=[self.pendiente.pk]), {'estado': 'rechazada'})
        self.pendiente.refresh_from_db()
        self.assertEqual(self.pendiente.estado, 'pendiente')
        self.client.post(reverse('solicitud_revisar', args=[self.pendiente.pk]), {'estado': 'aprobada'})
        self.pendiente.refresh_from_db()
        self.p1.refresh_from_db()
        self.assertEqual((self.pendiente.estado, self.p1.stock), ('aprobada', 10))
        self.assertEqual(self.client.post(reverse('solicitud_editar', args=[self.pendiente.pk]),
            self.formulario_solicitud()).status_code, 302)
        self.assertEqual(self.pendiente.detalles.get(producto=self.p1).cantidad, 2)

    def test_despacho_web_idempotente_con_historial(self):
        self.client.force_login(self.operador)
        ruta = reverse('solicitud_despachar', args=[self.aprobada.pk])
        self.assertEqual(self.client.post(ruta).status_code, 302)
        self.assertEqual(self.client.post(ruta).status_code, 302)
        self.p1.refresh_from_db()
        self.aprobada.refresh_from_db()
        self.assertEqual((self.p1.stock, self.aprobada.estado), (6, 'despachada'))
        salida = Movimiento.objects.get(detalle_solicitud__solicitud=self.aprobada)
        self.assertEqual((salida.variacion, salida.destino), (-4, self.otra_sucursal.nombre))
        detalle = self.aprobada.detalles.get()
        self.assertEqual((detalle.cantidad, detalle.cantidad_aprobada, detalle.cantidad_despachada), (4, 4, 4))
        with self.assertRaises(ValidationError):
            eliminar_ultimo(salida)

    def test_despacho_multilinea_revierte_todo_si_falta_stock(self):
        DetalleSolicitud.objects.create(solicitud=self.aprobada, producto=self.p2, cantidad=2)
        antes = Movimiento.objects.count()
        with self.assertRaises(ValidationError):
            despachar_solicitud(solicitud_id=self.aprobada.pk, usuario=self.operador)
        self.p1.refresh_from_db()
        self.p2.refresh_from_db()
        self.aprobada.refresh_from_db()
        self.assertEqual((self.p1.stock, self.p2.stock), (10, 1))
        self.assertEqual(self.aprobada.estado, 'aprobada')
        self.assertEqual(Movimiento.objects.count(), antes)

    def test_no_despachar_rechazada_pendiente_o_producto_archivado(self):
        for obj in (self.pendiente, self.rechazada):
            with self.assertRaises(ValidationError):
                despachar_solicitud(solicitud_id=obj.pk, usuario=self.admin)
        Producto.objects.filter(pk=self.p1.pk).update(activo=False)
        with self.assertRaises(ValidationError):
            eliminar_ultimo(Movimiento.objects.get(producto=self.p1))
        with self.assertRaises(ValidationError):
            despachar_solicitud(solicitud_id=self.aprobada.pk, usuario=self.admin)
        with self.assertRaises(PermissionDenied):
            revisar_solicitud(solicitud_id=self.pendiente.pk, usuario=self.consulta, estado='aprobada')

    def test_correccion_y_eliminacion_de_movimiento_en_interfaz_propia(self):
        ultimo = Movimiento.objects.get(producto=self.p3)
        datos = {'tipo': 'entrada', 'cantidad': 8, 'motivo': 'Corregido', 'destino': '', 'token': str(uuid4())}
        self.assertEqual(self.client.post(reverse('movimiento_editar', args=[ultimo.pk]), datos).status_code, 302)
        self.p3.refresh_from_db()
        self.assertEqual(self.p3.stock, 8)
        self.client.post(reverse('movimiento_eliminar', args=[ultimo.pk]))
        self.p3.refresh_from_db()
        self.assertEqual(self.p3.stock, 0)

    def test_reutilizar_token_con_datos_distintos_se_rechaza(self):
        token = uuid4()
        registrar_movimiento(producto_id=self.p1.pk, usuario=self.admin, tipo='entrada', cantidad=1, motivo='Token', token=token)
        with self.assertRaises(ValidationError):
            registrar_movimiento(producto_id=self.p2.pk, usuario=self.admin, tipo='entrada', cantidad=1, motivo='Token', token=token)

    def test_restricciones_de_base_para_precio_y_detalles(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Producto.objects.filter(pk=self.p1.pk).update(precio=-1)
        with self.assertRaises(IntegrityError), transaction.atomic():
            DetalleSolicitud.objects.create(solicitud=self.pendiente, producto=self.p3, cantidad=0)
        with self.assertRaises(IntegrityError), transaction.atomic():
            DetalleSolicitud.objects.create(solicitud=self.pendiente, producto=self.p1, cantidad=1)

    def test_los_20_reportes_se_muestran_con_filtros_validos(self):
        hoy = timezone.localdate()
        for numero in range(1, 21):
            with self.subTest(reporte=numero):
                r = self.client.get(reverse('reportes'), {'reporte': numero, 'categoria': self.cat.pk,
                    'proveedor': self.prov.pk, 'sucursal': self.sucursal.pk, 'solicitud': self.pendiente.pk,
                    'desde': hoy.replace(day=1).isoformat(), 'hasta': hoy.isoformat()})
                self.assertEqual(r.status_code, 200)
                self.assertFalse(r.context['errores'])
                self.assertEqual(r.context['numero'], numero)

    def test_resultados_orm_con_valores_conocidos_y_casos_limite(self):
        filtros = {'categoria': self.cat, 'proveedor': self.prov, 'sucursal': self.sucursal, 'solicitud': self.pendiente}
        def filas(numero):
            return list(generar_reporte(numero, filtros)[1])
        self.assertEqual(len(filas(1)), 4)
        self.assertEqual(len(filas(2)), 2)
        self.assertEqual([r[0] for r in filas(3)], ['E3-BAS'])  # Igual al mínimo no es «por debajo».
        self.assertEqual(filas(4)[0][0], 'E3-BAS')
        self.assertIn(('Vacía E3', 0), filas(5))
        self.assertEqual(len(filas(6)), 2)
        self.assertEqual(len(filas(7)), 2)
        self.assertEqual(sum(r[2] for r in filas(8)), 3)
        self.assertEqual(filas(9), [('Pendiente', 2), ('Aprobada', 1), ('Rechazada', 1), ('Despachada', 0)])
        self.assertEqual(filas(11)[0], ('Sur E3', 5))
        self.assertEqual(filas(12)[0], ('E3-GTR', 'Guitarra E3', 7))
        self.assertEqual(filas(13), [('Proveedor E3 A', 2)])
        self.assertEqual(filas(14)[0][1], Decimal('1450.00'))
        self.assertEqual([r[0] for r in filas(15)], ['E3-ARC'])
        self.assertEqual(set(filas(17)), {('Centro E3', 1), ('Sur E3', 1)})
        self.assertEqual(filas(18), [('Cuerdas E3', Decimal('1200'))])
        self.assertEqual(filas(19)[0][1], 3.25)
        Producto.objects.create(codigo='E3-EMPATE', nombre='Empate', categoria=self.audio,
            proveedor=self.otro_prov, precio=0, ubicacion='E')
        self.assertEqual(set(filas(13)), {('Proveedor E3 A', 2), ('Proveedor E3 B', 2)})

    def test_reportes_por_periodo_no_mezclan_fechas(self):
        hoy = timezone.localdate()
        fin = hoy.replace(day=1)
        ultimo_mes_anterior = fin - timedelta(days=1)
        fecha = timezone.make_aware(datetime.combine(ultimo_mes_anterior, time(12)))
        Solicitud.objects.filter(pk=self.aprobada.pk).update(fecha=fecha)
        filas10 = list(generar_reporte(10, {'desde': ultimo_mes_anterior, 'hasta': ultimo_mes_anterior})[1])
        filas20 = list(generar_reporte(20, {'desde': ultimo_mes_anterior, 'hasta': ultimo_mes_anterior})[1])
        self.assertEqual([r[0] for r in filas10], [self.aprobada.pk])
        self.assertEqual(filas20, [('E3-GTR', 'Guitarra E3', 4)])
        salida, _ = registrar_movimiento(producto_id=self.p1.pk, usuario=self.admin,
            tipo='salida', cantidad=2, motivo='Mes anterior', destino='Sucursal')
        Movimiento.objects.filter(pk=salida.pk).update(fecha=fecha)
        self.assertEqual(list(generar_reporte(16, {})[1]), [('E3-GTR', 'Guitarra E3', 2)])

    def test_carga_demo_repetible_sin_duplicar_despachos(self):
        call_command('seed_bodega', stdout=StringIO())
        productos = dict(Producto.objects.values_list('pk', 'stock'))
        solicitudes = Solicitud.objects.count()
        movimientos = Movimiento.objects.count()
        call_command('seed_bodega', stdout=StringIO())
        self.assertEqual(dict(Producto.objects.values_list('pk', 'stock')), productos)
        self.assertEqual(Solicitud.objects.count(), solicitudes)
        self.assertEqual(Movimiento.objects.count(), movimientos)


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class FormulariosHTMLTests(TestCase):
    """Regresión de la captura manual, validación y autorización exigidas en el curso."""

    @classmethod
    def setUpTestData(cls):
        cls.admin = Usuario.objects.create_superuser('admin_html', password='SoundStock-HTML-2026!')
        cls.op = Usuario.objects.create_user('op_html', password='SoundStock-HTML-2026!', rol='Operador')
        cls.cat = Categoria.objects.create(nombre='Categoría HTML')
        cls.prov = Proveedor.objects.create(nombre='Proveedor HTML')
        cls.suc = Sucursal.objects.create(nombre='Sucursal HTML', direccion='Calle HTML 1')
        cls.p1 = Producto.objects.create(codigo='HTML-UNO', nombre='Primero', categoria=cls.cat,
            proveedor=cls.prov, precio=10, ubicacion='A')
        cls.p2 = Producto.objects.create(codigo='HTML-DOS', nombre='Segundo', categoria=cls.cat,
            proveedor=cls.prov, precio=20, ubicacion='B')
        cls.sol = Solicitud.objects.create(sucursal=cls.suc, usuario=cls.op)
        cls.d1 = DetalleSolicitud.objects.create(solicitud=cls.sol, producto=cls.p1, cantidad=2)
        cls.d2 = DetalleSolicitud.objects.create(solicitud=cls.sol, producto=cls.p2, cantidad=3)

    def setUp(self):
        self.client.force_login(self.admin)

    def producto_post(self, **extra):
        datos = dict(codigo='HTML-NUEVO', nombre='Nuevo', categoria=self.cat.pk,
            proveedor=self.prov.pk, precio='12500.25', ubicacion='C', stock_minimo='2', descripcion='Prueba')
        datos.update(extra)
        return datos

    def solicitud_post(self, editar=False, **extra):
        datos = {'sucursal': self.suc.pk, 'observacion': 'Solicitud HTML',
            'detalles-TOTAL_FORMS': '2' if editar else '1', 'detalles-INITIAL_FORMS': '2' if editar else '0',
            'detalles-0-producto': self.p1.pk, 'detalles-0-cantidad': '2'}
        if editar:
            datos.update({'detalles-0-id': self.d1.pk, 'detalles-1-id': self.d2.pk,
                'detalles-1-producto': self.p2.pk, 'detalles-1-cantidad': '3'})
        datos.update(extra)
        return datos

    def test_fuentes_propias_sin_clases_ni_importaciones_de_formularios(self):
        import ast
        from django.conf import settings
        for app in ('catalogo', 'inventario', 'usuarios'):
            for path in (settings.BASE_DIR / app).rglob('*.py'):
                if path.name.startswith('test') or 'migrations' in path.parts:
                    continue
                arbol = ast.parse(path.read_text(encoding='utf-8'))
                for node in ast.walk(arbol):
                    if isinstance(node, ast.ImportFrom):
                        self.assertNotEqual(node.module, 'django.forms', str(path))
                        self.assertNotEqual(node.module, 'django.contrib.auth.forms', str(path))
                        if node.module == 'django':
                            self.assertNotIn('forms', [a.name for a in node.names], str(path))
                    if isinstance(node, ast.Import):
                        self.assertNotIn('django.forms', [a.name for a in node.names], str(path))
                    if isinstance(node, ast.ClassDef):
                        for base in node.bases:
                            nombre = base.id if isinstance(base, ast.Name) else getattr(base, 'attr', '')
                            self.assertNotIn(nombre, ['Form', 'ModelForm', 'UserCreationForm', 'UserChangeForm', 'SetPasswordForm'], str(path))
        for ruta in ('login', 'producto_crear', 'usuario_crear', 'sucursales_crear', 'solicitud_crear', 'movimiento_crear'):
            from django.urls import resolve
            self.assertTrue(resolve(reverse(ruta)).func.__module__.endswith('.views'))

    def test_plantillas_con_html_explicito_csrf_y_campos_en_orden(self):
        from django.conf import settings
        import re
        templates = settings.BASE_DIR / 'templates'
        for path in templates.rglob('*.html'):
            texto = path.read_text(encoding='utf-8')
            self.assertNotRegex(texto, r'\{\{\s*(?:form|formset)\.')
            for cuerpo in re.findall(r'<form\b[^>]*method="post"[^>]*>(.*?)</form>', texto, re.S | re.I):
                self.assertIn('{% csrf_token %}', cuerpo, str(path))
        respuesta = self.client.get(reverse('producto_crear'))
        self.assertNotIn('form', respuesta.context)
        html = respuesta.content.decode()
        campos = ['codigo', 'nombre', 'categoria', 'proveedor', 'precio', 'ubicacion', 'stock_minimo', 'descripcion']
        posiciones = [html.index(f'name="{campo}"') for campo in campos]
        self.assertEqual(posiciones, sorted(posiciones))
        self.assertContains(respuesta, 'name="precio" aria-describedby="error_precio" value="0"')

    def test_lecturas_texto_funcionan_con_codificacion_windows(self):
        from pathlib import Path
        from unittest.mock import patch

        leer_texto = Path.read_text

        def leer_como_windows(archivo, encoding=None, errors=None, **kwargs):
            # Simula un Windows que usa cp1252 cuando no se indica codificación.
            return leer_texto(archivo, encoding=encoding or 'cp1252', errors=errors, **kwargs)

        with patch.object(Path, 'read_text', new=leer_como_windows):
            self.test_fuentes_propias_sin_clases_ni_importaciones_de_formularios()
            self.test_plantillas_con_html_explicito_csrf_y_campos_en_orden()

    def test_precio_y_minimo_invalidos_no_crean_productos(self):
        for valor in ('', '-1', 'NaN', 'Infinity', '1.234', '10000000000', '1e100000'):
            with self.subTest(precio=valor):
                respuesta = self.client.post(reverse('producto_crear'), self.producto_post(precio=valor))
                self.assertEqual(respuesta.status_code, 200)
                self.assertIn('precio', respuesta.context['errores'])
        for valor in ('', '-1', '1.5', '1000001', '9'*100, 'dos'):
            with self.subTest(minimo=valor):
                respuesta = self.client.post(reverse('producto_crear'), self.producto_post(stock_minimo=valor))
                self.assertIn('stock_minimo', respuesta.context['errores'])
        self.assertEqual(Producto.objects.count(), 2)

    def test_relaciones_sku_y_obligatorios_se_validan_en_servidor(self):
        for cambio, campo in [({'categoria': 'texto'}, 'categoria'), ({'proveedor': '999999'}, 'proveedor'),
            ({'nombre': '   '}, 'nombre'), ({'ubicacion': ''}, 'ubicacion'), ({'codigo': 'HTML-UNO'}, 'codigo')]:
            respuesta = self.client.post(reverse('producto_crear'), self.producto_post(**cambio))
            self.assertEqual(respuesta.status_code, 200)
            self.assertIn(campo, respuesta.context['errores'])
        self.prov.activo = False
        self.prov.save()
        respuesta = self.client.post(reverse('producto_crear'), self.producto_post())
        self.assertIn('proveedor', respuesta.context['errores'])
        self.assertEqual(Producto.objects.count(), 2)

    def test_post_solo_asigna_campos_permitidos_y_escapa_html(self):
        datos = self.producto_post(codigo=' html-nuevo ', stock=999, activo='',
            nombre='<script>alert(1)</script>', is_superuser='on')
        self.assertEqual(self.client.post(reverse('producto_crear'), datos).status_code, 302)
        producto = Producto.objects.get(codigo='HTML-NUEVO')
        self.assertEqual(producto.stock, 0)
        self.assertTrue(producto.activo)
        respuesta = self.client.get(reverse('productos'), {'q': 'HTML-NUEVO'})
        self.assertContains(respuesta, '&lt;script&gt;alert(1)&lt;/script&gt;')
        self.assertNotContains(respuesta, '<script>alert(1)</script>')
        datos.update(stock=888, activo='', nombre='Editado')
        self.client.post(reverse('producto_editar', args=[producto.pk]), datos)
        producto.refresh_from_db()
        self.assertEqual((producto.stock, producto.activo), (0, True))

    def test_csrf_real_en_login_y_formularios_post(self):
        navegador = Client(enforce_csrf_checks=True)
        url = reverse('login')
        credenciales = {'username': self.admin.username, 'password': 'SoundStock-HTML-2026!'}
        self.assertEqual(navegador.post(url, credenciales).status_code, 403)
        navegador.get(url)
        credenciales['csrfmiddlewaretoken'] = navegador.cookies['csrftoken'].value
        self.assertEqual(navegador.post(url, credenciales).status_code, 302)
        for ruta in ('producto_crear', 'usuario_crear', 'categorias_crear', 'proveedores_crear',
                     'sucursales_crear', 'solicitud_crear', 'movimiento_crear', 'logout'):
            with self.subTest(ruta=ruta):
                self.assertEqual(navegador.post(reverse(ruta), {}).status_code, 403)

    def test_login_acepta_destino_local_y_rechaza_redireccion_externa(self):
        for destino, esperado in [('https://externo.invalid/', reverse('inicio')),
                                  ('//externo.invalid/', reverse('inicio')), (reverse('productos'), reverse('productos'))]:
            self.client.logout()
            respuesta = self.client.post(reverse('login'), {'username': self.admin.username,
                'password': 'SoundStock-HTML-2026!', 'next': destino})
            self.assertRedirects(respuesta, esperado, fetch_redirect_response=False)
        self.client.post(reverse('logout'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_login_invalido_no_expone_clave_ni_inicia_sesion(self):
        self.client.logout()
        self.op.is_active = False
        self.op.save()
        respuesta = self.client.post(reverse('login'), {'username': self.op.username,
            'password': 'SoundStock-HTML-2026!'})
        self.assertEqual(respuesta.status_code, 200)
        self.assertTrue(respuesta.context['errores'])
        self.assertNotContains(respuesta, 'value="SoundStock-HTML-2026!"')
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_usuario_valida_clave_email_rol_y_no_acepta_privilegios_extra(self):
        datos = dict(username='nuevo_html', rol='Consulta', is_active='on', email='html@example.com',
            password1='123', password2='distinta', is_superuser='on', is_staff='on')
        respuesta = self.client.post(reverse('usuario_crear'), datos)
        self.assertIn('password1', respuesta.context['errores'])
        self.assertIn('password2', respuesta.context['errores'])
        self.assertNotContains(respuesta, 'value="distinta"')
        self.assertFalse(Usuario.objects.filter(username='nuevo_html').exists())
        datos.update(password1='Clave-Segura-HTML-2026!', password2='Clave-Segura-HTML-2026!', email='malo', rol='Hacker')
        respuesta = self.client.post(reverse('usuario_crear'), datos)
        self.assertIn('rol', respuesta.context['errores'])
        self.assertIn('email', respuesta.context['errores'])
        datos.update(email='html@example.com', rol='Consulta')
        self.assertEqual(self.client.post(reverse('usuario_crear'), datos).status_code, 302)
        usuario = Usuario.objects.get(username='nuevo_html')
        self.assertTrue(usuario.check_password(datos['password1']))
        self.assertNotEqual(usuario.password, datos['password1'])
        self.assertFalse(usuario.is_superuser or usuario.is_staff)

    def test_clave_invalida_no_modifica_cuenta_y_duplicado_ignora_mayusculas(self):
        anterior = Usuario.objects.get(pk=self.op.pk).password
        respuesta = self.client.post(reverse('usuario_clave', args=[self.op.pk]), {
            'new_password1': '123', 'new_password2': '456'})
        self.assertTrue(respuesta.context['errores'])
        self.assertEqual(Usuario.objects.get(pk=self.op.pk).password, anterior)
        respuesta = self.client.post(reverse('usuario_crear'), dict(username='OP_HTML', rol='Consulta',
            is_active='on', password1='Clave-Segura-HTML-2026!', password2='Clave-Segura-HTML-2026!'))
        self.assertIn('username', respuesta.context['errores'])

    def test_catalogos_validan_modelo_y_no_guardan_datos_invalidos(self):
        for ruta, datos, campo in [('categorias_crear', {'nombre': ''}, 'nombre'),
            ('proveedores_crear', {'nombre': 'Nuevo', 'email': 'no-es-email'}, 'email'),
            ('sucursales_crear', {'nombre': 'Sucursal HTML', 'direccion': 'Calle'}, 'nombre')]:
            respuesta = self.client.post(reverse(ruta), datos)
            self.assertIn(campo, respuesta.context['errores'])
        self.assertEqual((Categoria.objects.count(), Proveedor.objects.count(), Sucursal.objects.count()), (1, 1, 1))

    def test_solicitud_rechaza_duplicados_limites_cantidad_y_detalle_vacio(self):
        for cambio in [{'detalles-TOTAL_FORMS': '101'}, {'detalles-TOTAL_FORMS': '-1'},
            {'detalles-0-cantidad': '1.5'}, {'detalles-0-cantidad': '1000001'},
            {'detalles-0-producto': '', 'detalles-0-cantidad': ''},
            {'detalles-TOTAL_FORMS': '2', 'detalles-1-producto': self.p1.pk, 'detalles-1-cantidad': '1'}]:
            respuesta = self.client.post(reverse('solicitud_crear'), self.solicitud_post(**cambio))
            self.assertEqual(respuesta.status_code, 200)
            self.assertIn('detalles', respuesta.context['errores'])
        self.assertEqual(Solicitud.objects.count(), 1)
        self.assertEqual(DetalleSolicitud.objects.count(), 2)

    def test_solicitud_rechaza_ids_ajenos_repetidos_y_lineas_omitidas(self):
        otra = Solicitud.objects.create(sucursal=self.suc, usuario=self.op)
        ajena = DetalleSolicitud.objects.create(solicitud=otra, producto=self.p1, cantidad=9)
        for cambio in [{'detalles-0-id': ajena.pk}, {'detalles-1-id': self.d1.pk},
                       {'detalles-TOTAL_FORMS': '1'}]:
            respuesta = self.client.post(reverse('solicitud_editar', args=[self.sol.pk]), self.solicitud_post(True, **cambio))
            self.assertEqual(respuesta.status_code, 200)
            self.assertIn('detalles', respuesta.context['errores'])
        self.assertEqual(list(self.sol.detalles.values_list('pk', 'cantidad')), [(self.d1.pk, 2), (self.d2.pk, 3)])
        self.assertEqual(DetalleSolicitud.objects.get(pk=ajena.pk).cantidad, 9)

    def test_solicitud_intercambia_productos_conservando_ids_y_stock(self):
        datos = self.solicitud_post(True, **{'detalles-0-producto': self.p2.pk, 'detalles-1-producto': self.p1.pk})
        self.assertEqual(self.client.post(reverse('solicitud_editar', args=[self.sol.pk]), datos).status_code, 302)
        self.assertEqual(list(self.sol.detalles.values_list('pk', 'producto_id', 'cantidad')),
            [(self.d1.pk, self.p2.pk, 2), (self.d2.pk, self.p1.pk, 3)])
        self.assertEqual(list(Producto.objects.order_by('pk').values_list('stock', flat=True)), [0, 0])
        self.assertFalse(Movimiento.objects.exists())

    def test_solicitud_quita_y_agrega_linea_sin_confiar_en_initial_forms(self):
        datos = self.solicitud_post(True, **{'detalles-TOTAL_FORMS': '3', 'detalles-INITIAL_FORMS': '0',
            'detalles-0-DELETE': 'on', 'detalles-2-producto': self.p1.pk, 'detalles-2-cantidad': '4'})
        self.assertEqual(self.client.post(reverse('solicitud_editar', args=[self.sol.pk]), datos).status_code, 302)
        self.assertFalse(DetalleSolicitud.objects.filter(pk=self.d1.pk).exists())
        self.assertTrue(DetalleSolicitud.objects.filter(pk=self.d2.pk).exists())
        self.assertEqual(self.sol.detalles.get(producto=self.p1).cantidad, 4)

    def test_solicitud_invalida_no_modifica_cabecera_detalles_ni_estado(self):
        for cambio in [{'sucursal': '999999'}, {'observacion': 'x'*1001}, {'detalles-1-cantidad': '-1'}]:
            datos = self.solicitud_post(True, **cambio)
            datos.update(estado='despachada', usuario=self.admin.pk, cantidad_aprobada='999')
            respuesta = self.client.post(reverse('solicitud_editar', args=[self.sol.pk]), datos)
            self.assertTrue(respuesta.context['errores'])
        self.sol.refresh_from_db()
        self.assertEqual((self.sol.estado, self.sol.usuario_id, self.sol.observacion), ('pendiente', self.op.pk, ''))
        self.assertEqual(list(self.sol.detalles.values_list('cantidad', flat=True)), [2, 3])

    def test_reportes_validan_relaciones_fechas_y_numero_sin_formularios(self):
        for params, campo in [({'reporte': '0'}, 'reporte'), ({'reporte': '2', 'categoria': '99999'}, 'categoria'),
            ({'reporte': '6', 'proveedor': 'no'}, 'proveedor'), ({'reporte': '10', 'desde': '2026-02-30'}, 'desde'),
            ({'reporte': '20', 'desde': '2026-12-31', 'hasta': '2026-01-01'}, 'general')]:
            respuesta = self.client.get(reverse('reportes'), params)
            self.assertEqual(respuesta.status_code, 200)
            self.assertIn(campo, respuesta.context['errores'])
            self.assertIsNone(respuesta.context['numero'])

    def test_movimiento_valida_token_y_no_cambia_producto_al_corregir(self):
        datos = dict(producto=self.p1.pk, tipo='entrada', cantidad='8', motivo='HTML', destino='', token='invalido')
        respuesta = self.client.post(reverse('movimiento_crear'), datos)
        self.assertIn('token', respuesta.context['errores'])
        self.assertFalse(Movimiento.objects.exists())
        datos['token'] = str(uuid4())
        self.assertEqual(self.client.post(reverse('movimiento_crear'), datos).status_code, 302)
        movimiento = Movimiento.objects.get()
        datos.update(producto=self.p2.pk, cantidad='5')
        self.assertEqual(self.client.post(reverse('movimiento_editar', args=[movimiento.pk]), datos).status_code, 302)
        movimiento.refresh_from_db()
        self.assertEqual(movimiento.producto_id, self.p1.pk)
        self.assertEqual(Producto.objects.get(pk=self.p1.pk).stock, 5)
        self.assertEqual(Producto.objects.get(pk=self.p2.pk).stock, 0)
