from uuid import uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from catalogo.models import Producto
from .models import Movimiento, Solicitud


def calcular_saldo(anterior, tipo, cantidad, destino=''):
    if tipo not in dict(Movimiento.TIPOS):
        raise ValidationError('Tipo de movimiento inválido.')
    if cantidad < 0 or (tipo != 'ajuste' and cantidad == 0):
        raise ValidationError('La cantidad debe ser mayor que cero.')
    if tipo == 'salida' and not destino.strip():
        raise ValidationError('La salida requiere un destino.')
    posterior = cantidad if tipo == 'ajuste' else anterior + (cantidad if tipo == 'entrada' else -cantidad)
    if posterior < 0:
        raise ValidationError(f'Stock insuficiente: quedan {anterior} unidades.')
    if posterior > 1000000:
        raise ValidationError('El stock supera el máximo de 1.000.000 de unidades.')
    if posterior == anterior:
        raise ValidationError('El ajuste no cambia el stock.')
    return posterior


@transaction.atomic
def registrar_movimiento(*, producto_id, usuario, tipo, cantidad, motivo, destino='', token=None,
                         instancia=None, detalle_solicitud=None):
    producto = Producto.objects.select_for_update().get(pk=producto_id)
    if not producto.activo:
        raise ValidationError('El producto está archivado.')
    token = token or uuid4()
    if instancia is None:
        existente = Movimiento.objects.filter(token=token).first()
        if existente:
            cantidad_existente = existente.posterior if existente.tipo == 'ajuste' else abs(existente.variacion)
            if (existente.usuario_id != usuario.pk or existente.producto_id != producto.pk
                    or existente.tipo != tipo or cantidad_existente != cantidad
                    or existente.motivo != motivo or existente.destino != (destino if tipo == 'salida' else '')):
                raise ValidationError('Identificador de operación inválido.')
            return existente, False
        anterior = producto.stock
        saldo_guardado = producto.stock
    else:
        guardado = Movimiento.objects.get(pk=instancia.pk)
        if guardado.detalle_solicitud_id:
            raise ValidationError('Un despacho no se corrige de forma aislada. Registra un movimiento compensatorio.')
        ultimo = producto.movimientos.order_by('-pk').first()
        if guardado.producto_id != producto.pk or not ultimo or ultimo.pk != guardado.pk:
            raise ValidationError('Solo se puede editar el último movimiento sin cambiar de producto.')
        anterior = guardado.anterior
        saldo_guardado = guardado.posterior
    if not motivo.strip():
        raise ValidationError('El motivo es obligatorio.')
    posterior = calcular_saldo(anterior, tipo, cantidad, destino)
    movimiento = instancia or Movimiento(token=token)
    movimiento.producto = producto
    movimiento.usuario = usuario
    movimiento.tipo = tipo
    movimiento.anterior = anterior
    movimiento.posterior = posterior
    movimiento.variacion = posterior - anterior
    movimiento.motivo = motivo
    movimiento.destino = destino if tipo == 'salida' else ''
    movimiento.detalle_solicitud = detalle_solicitud
    movimiento.full_clean()
    # El filtro por saldo evita perder cambios también con SQLite, donde SELECT FOR UPDATE no bloquea filas.
    if Producto.objects.filter(pk=producto.pk, stock=saldo_guardado).update(stock=posterior) != 1:
        raise ValidationError('El stock cambió. Recarga el formulario.')
    movimiento.save()
    return movimiento, True


@transaction.atomic
def eliminar_ultimo(movimiento):
    guardado = Movimiento.objects.get(pk=movimiento.pk)
    if guardado.detalle_solicitud_id:
        raise ValidationError('No se elimina un movimiento asociado a un despacho.')
    producto = Producto.objects.select_for_update().get(pk=guardado.producto_id)
    if not producto.activo:
        raise ValidationError('Reactiva el producto antes de corregir su historial.')
    ultimo = producto.movimientos.order_by('-pk').first()
    if not ultimo or ultimo.pk != guardado.pk:
        raise ValidationError('Solo se puede eliminar el último movimiento.')
    if Producto.objects.filter(pk=producto.pk, stock=guardado.posterior).update(stock=guardado.anterior) != 1:
        raise ValidationError('El stock no coincide con el historial.')
    guardado.delete()


def comprobar_rol(usuario, *roles):
    if not usuario.is_active or usuario.rol not in roles:
        raise PermissionDenied


@transaction.atomic
def revisar_solicitud(*, solicitud_id, usuario, estado, respuesta=''):
    comprobar_rol(usuario, 'Administrador')
    solicitud = Solicitud.objects.select_for_update().get(pk=solicitud_id)
    if solicitud.estado != 'pendiente' or estado not in ('aprobada', 'rechazada'):
        raise ValidationError('Solo puedes aprobar o rechazar una solicitud pendiente.')
    if not solicitud.detalles.exists():
        raise ValidationError('La solicitud debe tener al menos un producto.')
    if estado == 'rechazada' and not respuesta.strip():
        raise ValidationError('Explica el motivo del rechazo.')
    solicitud.detalles.update(cantidad_aprobada=F('cantidad') if estado == 'aprobada' else 0)
    solicitud.estado = estado
    solicitud.respuesta = respuesta.strip()
    solicitud.atendida_por = usuario
    solicitud.fecha_revision = timezone.now()
    solicitud.full_clean()
    solicitud.save(update_fields=['estado', 'respuesta', 'atendida_por', 'fecha_revision'])
    return solicitud


@transaction.atomic
def despachar_solicitud(*, solicitud_id, usuario):
    comprobar_rol(usuario, 'Administrador', 'Operador')
    solicitud = Solicitud.objects.select_for_update().select_related('sucursal').get(pk=solicitud_id)
    if solicitud.estado == 'despachada':
        return solicitud, False
    if solicitud.estado != 'aprobada':
        raise ValidationError('Solo se puede despachar una solicitud aprobada.')
    if not solicitud.sucursal.activa:
        raise ValidationError('La sucursal está desactivada.')
    detalles = list(solicitud.detalles.select_related('producto').order_by('producto_id'))
    if not detalles:
        raise ValidationError('La solicitud no tiene productos.')
    for detalle in detalles:
        if detalle.cantidad_aprobada != detalle.cantidad or detalle.cantidad_despachada:
            raise ValidationError('Las cantidades de la solicitud no coinciden con su aprobación.')
        registrar_movimiento(producto_id=detalle.producto_id, usuario=usuario, tipo='salida',
            cantidad=detalle.cantidad_aprobada, motivo=f'Despacho SOL-{solicitud.pk:05d}',
            destino=solicitud.sucursal.nombre, detalle_solicitud=detalle)
        detalle.cantidad_despachada = detalle.cantidad_aprobada
        detalle.save(update_fields=['cantidad_despachada'])
    solicitud.estado = 'despachada'
    solicitud.despachada_por = usuario
    solicitud.fecha_despacho = timezone.now()
    solicitud.save(update_fields=['estado', 'despachada_por', 'fecha_despacho'])
    return solicitud, True
