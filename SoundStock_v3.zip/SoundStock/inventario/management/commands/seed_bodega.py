"""Datos pequeños y repetibles para demostrar todos los reportes de bodega."""
from datetime import datetime, time, timedelta
from decimal import Decimal
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from catalogo.models import Producto, Proveedor
from inventario.models import DetalleSolicitud, Movimiento, Solicitud, Sucursal
from inventario.services import despachar_solicitud, revisar_solicitud
from usuarios.models import Usuario


class Command(BaseCommand):
    help = 'Carga catálogo, precios y proveedores de ejemplo, tres sucursales y cuatro estados de solicitud.'

    @transaction.atomic
    def handle(self, *args, **options):
        admin = Usuario.objects.filter(rol='Administrador', is_active=True).first()
        if not admin:
            raise CommandError('Ejecuta migrate y crea una cuenta administradora antes de cargar datos.')
        call_command('cargar_catalogo', stdout=self.stdout)
        proveedores = [Proveedor.objects.get_or_create(nombre=nombre, defaults={
            'email': f'contacto{n}@example.com', 'contacto': 'Contacto ficticio'})[0]
            for n, nombre in enumerate(('Distribuidora Musical Demo', 'Instrumentos Demo Chile'), 1)]
        productos = list(Producto.objects.filter(codigo__startswith='MP-').order_by('codigo'))
        for n, producto in enumerate(productos):
            cambios = []
            if not producto.proveedor_id:
                producto.proveedor = proveedores[n % 2]
                cambios.append('proveedor')
            if producto.precio == 0:
                producto.precio = Decimal(25000 + n * 15000)
                cambios.append('precio')
            if cambios:
                producto.save(update_fields=cambios)
        sucursales = [Sucursal.objects.get_or_create(nombre=nombre, defaults={
            'direccion': f'Dirección ficticia {n}', 'email': f'sucursal{n}@example.com'})[0]
            for n, nombre in enumerate(('Sucursal Centro Demo', 'Sucursal Puente Alto Demo', 'Sucursal Maipú Demo'), 1)]
        for username, rol in [('operador_demo', 'Operador'), ('consulta_demo', 'Consulta')]:
            cuenta, creada = Usuario.objects.get_or_create(username=username, defaults={'rol': rol})
            if creada:
                cuenta.set_password('SoundStock-Demo-2026!')
                cuenta.save()
        seleccion = list(Producto.objects.filter(codigo__in=['MP-GTR-001', 'MP-GTR-002']).order_by('codigo'))
        if len(seleccion) != 2:
            raise CommandError('No se encontró el catálogo esperado.')
        hoy = timezone.localdate()
        mes_anterior = hoy.replace(day=1) - timedelta(days=1)
        for n, estado in enumerate(('pendiente', 'aprobada', 'rechazada', 'despachada')):
            solicitud, creada = Solicitud.objects.get_or_create(
                observacion=f'DEMO-E3:{estado}', sucursal=sucursales[n % 3], defaults={'usuario': admin})
            if not creada:
                continue
            for i, producto in enumerate(seleccion):
                DetalleSolicitud.objects.create(solicitud=solicitud, producto=producto, cantidad=2 - i)
            if estado != 'pendiente':
                revisar_solicitud(solicitud_id=solicitud.pk, usuario=admin,
                    estado='rechazada' if estado == 'rechazada' else 'aprobada',
                    respuesta='Ejemplo de revisión para la defensa.')
            if estado == 'despachada':
                despachar_solicitud(solicitud_id=solicitud.pk, usuario=admin)
                # Una salida en el mes anterior permite verificar el reporte 16.
                fecha = timezone.make_aware(datetime.combine(mes_anterior, time.min))
                Movimiento.objects.filter(detalle_solicitud__solicitud=solicitud).update(fecha=fecha)
                Solicitud.objects.filter(pk=solicitud.pk).update(fecha=fecha, fecha_revision=fecha, fecha_despacho=fecha)
        self.stdout.write(self.style.SUCCESS('Bodega de demostración preparada. Repetir el comando no duplica solicitudes ni stock.'))
