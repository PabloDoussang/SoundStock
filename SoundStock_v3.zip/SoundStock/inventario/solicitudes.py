"""Se conserva la ubicación de las rutas de solicitudes de la versión anterior.

El procesamiento manual de POST se encuentra en inventario/views.py.
"""
from .views import (
    sucursales, sucursal_guardar, sucursal_eliminar,
    solicitudes_lista as lista, solicitud_guardar as guardar,
    solicitud_detalle as detalle, solicitud_eliminar as eliminar,
    solicitud_revisar as revisar, solicitud_despachar as despachar,
)
