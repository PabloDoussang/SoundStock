"""Indicadores y series del panel. Todos los valores proceden del ORM."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, F, Q, Sum
from django.db.models.functions import TruncDate
from django.utils import timezone

from catalogo.models import Producto
from .models import Movimiento, Solicitud
from .reportes import valor_stock


def contexto_panel(dias=30):
    dias = dias if dias in (7, 30, 90) else 30
    hoy = timezone.localdate()
    inicio = hoy - timedelta(days=dias - 1)
    productos = Producto.objects.filter(activo=True)
    movimientos = Movimiento.objects.select_related('producto', 'usuario')
    cifras = productos.aggregate(unidades=Sum('stock'), valor=Sum(valor_stock()),
        alertas=Count('pk', filter=Q(stock__lt=F('stock_minimo'))),
        agotados=Count('pk', filter=Q(stock=0)))
    por_dia = movimientos.filter(fecha__date__range=(inicio, hoy)).order_by().annotate(
        dia=TruncDate('fecha')).values('dia').annotate(
        entradas=Sum('variacion', filter=Q(tipo='entrada')),
        salidas=Sum('variacion', filter=Q(tipo='salida')),
        ajustes=Sum('variacion', filter=Q(tipo='ajuste'))).order_by('dia')
    indice = {r['dia']: r for r in por_dia}
    fechas = [inicio + timedelta(days=n) for n in range(dias)]
    entradas = [indice.get(d, {}).get('entradas') or 0 for d in fechas]
    salidas = [-(indice.get(d, {}).get('salidas') or 0) for d in fechas]
    ajustes = [indice.get(d, {}).get('ajustes') or 0 for d in fechas]
    categorias = list(productos.order_by().values('categoria__nombre').annotate(
        unidades=Sum('stock')).order_by('-unidades', 'categoria__nombre')[:8])
    estados = dict(Solicitud.objects.order_by().values('estado').annotate(
        total=Count('pk')).values_list('estado', 'total'))
    cantidad = productos.count()
    return {
        'cantidad_productos': cantidad, 'unidades': cifras['unidades'] or 0,
        'valor_inventario': cifras['valor'] or Decimal('0'),
        'alertas': cifras['alertas'], 'agotados': cifras['agotados'],
        'pendientes': estados.get('pendiente', 0),
        'movimientos_hoy': movimientos.filter(fecha__date=hoy).count(),
        'recientes': movimientos[:6],
        'criticos': productos.select_related('categoria').filter(
            Q(stock__lt=F('stock_minimo')) | Q(stock=0)).order_by('stock', 'nombre')[:5],
        'dias': dias, 'desde_panel': inicio, 'hasta_panel': hoy,
        'total_entradas': sum(entradas), 'total_salidas': sum(salidas),
        'grafico_movimientos': {'type': 'line', 'labels': [d.strftime('%d/%m') for d in fechas],
            'series': [{'name': 'Entradas', 'values': entradas, 'color': '#7664ec'},
                       {'name': 'Salidas', 'values': salidas, 'color': '#2ebfa5'}], 'unit': 'unidades'},
        'tabla_actividad': [(d, entradas[i], salidas[i], ajustes[i]) for i, d in enumerate(fechas)],
        'grafico_categorias': {'type': 'bar', 'labels': [r['categoria__nombre'] for r in categorias],
            'series': [{'name': 'Unidades', 'values': [r['unidades'] for r in categorias]}], 'unit': 'unidades'},
        'grafico_solicitudes': {'type': 'donut', 'labels': [label for _, label in Solicitud.ESTADOS],
            'series': [{'name': 'Solicitudes', 'values': [estados.get(key, 0) for key, _ in Solicitud.ESTADOS]}],
            'colors': ['#f5b34e', '#7664ec', '#eb7d8a', '#2ebfa5'], 'unit': 'solicitudes'},
    }


def grafico_reporte(numero, filas):
    """Grafica la página visible, hasta 25 filas, sin materializar todo el reporte."""
    configuracion = {
        3: (1, [2, 3], ['Stock actual', 'Mínimo'], 'unidades'),
        4: (1, [3], ['Precio unitario'], 'CLP'),
        5: (0, [1], ['Productos'], 'productos'),
        8: (1, [2, 3, 4], ['Solicitadas', 'Aprobadas', 'Despachadas'], 'unidades'),
        9: (0, [1], ['Solicitudes'], 'solicitudes'),
        11: (0, [1], ['Unidades solicitadas'], 'unidades'),
        12: (1, [2], ['Unidades solicitadas'], 'unidades'),
        13: (0, [1], ['Productos diferentes'], 'productos'),
        16: (1, [2], ['Unidades salidas'], 'unidades'),
        17: (0, [1], ['Solicitudes pendientes'], 'solicitudes'),
        18: (0, [1], ['Valor del inventario'], 'CLP'),
        20: (1, [2], ['Unidades solicitadas'], 'unidades'),
    }
    if numero not in configuracion:
        return None
    etiqueta, indices, nombres, unidad = configuracion[numero]
    grafico = {'type': 'donut' if numero == 9 else 'bar',
        'labels': [str(f[etiqueta]) for f in filas],
        'series': [{'name': nombre, 'values': [float(f[indice] or 0) for f in filas]}
            for indice, nombre in zip(indices, nombres)], 'unit': unidad}
    if numero == 9:
        grafico['colors'] = ['#f5b34e', '#7664ec', '#eb7d8a', '#2ebfa5']
    return grafico
