import csv
from datetime import date
from uuid import UUID, uuid4

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Count, F, Q, Sum
from django.db.models.deletion import ProtectedError
from django.db.models.functions import TruncDate
from django.http import Http404, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from catalogo.models import Categoria, Producto, Proveedor
from catalogo.gestion import contexto_catalogo
from .access import roles_permitidos
from .models import DetalleSolicitud, Movimiento, Solicitud, Sucursal, codigo_sucursal
from .services import registrar_movimiento, despachar_solicitud, revisar_solicitud
from .services import eliminar_ultimo
from .reportes import TITULOS, generar_reporte
from .panel import contexto_panel, grafico_reporte


@login_required
def inicio(request):
    dias = {'7': 7, '30': 30, '90': 90}.get(request.GET.get('dias'), 30)
    return render(request, 'inventario/inicio.html', contexto_panel(dias))


def filtrar_movimientos(request):
    rows = Movimiento.objects.select_related('producto', 'usuario')
    if request.GET.get('tipo') in dict(Movimiento.TIPOS):
        rows = rows.filter(tipo=request.GET['tipo'])
    q = request.GET.get('q', '').strip()
    if q:
        rows = rows.filter(Q(producto__codigo__icontains=q) | Q(producto__nombre__icontains=q) |
                           Q(motivo__icontains=q) | Q(usuario__username__icontains=q))
    try:
        desde = date.fromisoformat(request.GET['desde']) if request.GET.get('desde') else None
        hasta = date.fromisoformat(request.GET['hasta']) if request.GET.get('hasta') else None
    except ValueError:
        return rows.none()
    if desde and hasta and desde > hasta:
        return rows.none()
    if desde:
        rows = rows.filter(fecha__date__gte=desde)
    if hasta:
        rows = rows.filter(fecha__date__lte=hasta)
    return rows


@login_required
def movimientos(request):
    rows = filtrar_movimientos(request)
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    return render(request, 'inventario/movimientos.html', {
        'pagina': Paginator(rows, 20).get_page(request.GET.get('pagina')),
        'total': rows.count(), 'tipos': Movimiento.TIPOS,
        'filtros_query': parametros.urlencode(),
    })


def _entero(raw, errores, campo, minimo=0, maximo=1000000):
    raw = str(raw or '').strip()
    if not raw.isascii() or not raw.isdecimal() or len(raw) > 18:
        errores.setdefault(campo, []).append(f'Ingresa un entero entre {minimo} y {maximo}.')
        return None
    valor = int(raw)
    if not minimo <= valor <= maximo:
        errores.setdefault(campo, []).append(f'Ingresa un entero entre {minimo} y {maximo}.')
        return None
    return valor


def _errores_modelo(errores, error):
    detalle = error.message_dict if hasattr(error, 'message_dict') else {'general': error.messages}
    for campo, lista in detalle.items():
        clave = 'general' if campo == '__all__' else campo
        errores.setdefault(clave, []).extend(str(mensaje) for mensaje in lista)


def _datos_movimiento(request, movimiento=None):
    errores = {}
    if request.method == 'POST':
        datos = {campo: request.POST.get(campo, '').strip() for campo in ('producto', 'tipo', 'cantidad', 'motivo', 'destino', 'token')}
        # El producto de una corrección no puede alterarse con un campo manipulado.
        if movimiento:
            datos['producto'] = str(movimiento.producto_id)
        cantidad = _entero(datos['cantidad'], errores, 'cantidad')
        producto_id = _entero(datos['producto'], errores, 'producto', 1, 9223372036854775807)
        if producto_id and not Producto.objects.filter(pk=producto_id, activo=True).exists():
            errores['producto'] = ['Selecciona un producto activo.']
        if datos['tipo'] not in dict(Movimiento.TIPOS):
            errores['tipo'] = ['Selecciona un tipo de movimiento válido.']
        if cantidad == 0 and datos['tipo'] != 'ajuste':
            errores['cantidad'] = ['La cantidad debe ser mayor que cero.']
        if not datos['motivo'] or len(datos['motivo']) > 240:
            errores['motivo'] = ['Escribe un motivo de entre 1 y 240 caracteres.']
        if len(datos['destino']) > 120 or (datos['tipo'] == 'salida' and not datos['destino']):
            errores['destino'] = ['Las salidas requieren un destino de hasta 120 caracteres.']
        token = None
        if not movimiento:
            # Compatibilidad del Admin histórico: su formulario anterior no incluía token.
            if not datos['token'] and request.path.startswith('/admin/'):
                datos['token'] = str(uuid4())
            try:
                token = UUID(datos['token'])
            except (ValueError, TypeError, AttributeError):
                errores['token'] = ['Identificador inválido. Recarga la página para iniciar otra operación.']
        return datos, errores, producto_id, cantidad, token
    if movimiento:
        datos = {'producto': str(movimiento.producto_id), 'tipo': movimiento.tipo,
            'cantidad': str(movimiento.posterior if movimiento.tipo == 'ajuste' else abs(movimiento.variacion)),
            'motivo': movimiento.motivo, 'destino': movimiento.destino, 'token': str(uuid4())}
    else:
        datos = {'producto': request.GET.get('producto', ''), 'tipo': 'entrada', 'cantidad': '',
            'motivo': '', 'destino': '', 'token': str(uuid4())}
    return datos, errores, None, None, None


def _pantalla_movimiento(request, datos, errores, movimiento=None):
    opciones = list(Producto.objects.filter(activo=True).order_by('codigo')[:100])
    elegido = datos.get('producto', '')
    if str(elegido).isascii() and str(elegido).isdecimal() and len(str(elegido)) <= 18:
        especifico = Producto.objects.filter(pk=int(elegido)).first()
        if especifico and all(p.pk != especifico.pk for p in opciones):
            opciones.append(especifico)
    return render(request, 'inventario/nuevo_movimiento.html', {'tipo_formulario': 'movimiento',
        'datos': datos, 'errores': errores, 'productos': opciones, 'tipos_movimiento': Movimiento.TIPOS,
        'edicion': movimiento is not None})


@roles_permitidos('Administrador', 'Operador')
def nuevo_movimiento(request):
    datos, errores, producto_id, cantidad, token = _datos_movimiento(request)
    if request.method == 'POST' and not errores:
        try:
            movimiento, creado = registrar_movimiento(producto_id=producto_id, usuario=request.user,
                tipo=datos['tipo'], cantidad=cantidad, motivo=datos['motivo'], destino=datos['destino'], token=token)
            messages.success(request, f'MOV-{movimiento.pk:05d}: stock resultante {movimiento.posterior}.'
                if creado else 'La operación ya estaba registrada; no se duplicó el stock.')
            return redirect('movimientos')
        except ValidationError as error:
            _errores_modelo(errores, error)
        except Producto.DoesNotExist:
            errores['producto'] = ['El producto ya no está disponible.']
    return _pantalla_movimiento(request, datos, errores)


@login_required
def reportes(request):
    datos = request.GET.copy()
    datos.setdefault('reporte', '1')
    errores, filtros = {}, {}
    numero = _entero(datos.get('reporte'), errores, 'reporte', 1, 20)
    for campo, modelo in (('categoria', Categoria), ('proveedor', Proveedor), ('sucursal', Sucursal), ('solicitud', Solicitud)):
        raw = datos.get(campo, '')
        filtros[campo] = None
        if raw:
            pk = _entero(raw, errores, campo, 1, 9223372036854775807)
            if pk:
                filtros[campo] = modelo.objects.filter(pk=pk).first()
                if filtros[campo] is None:
                    errores[campo] = ['Selecciona un registro existente.']
    for campo in ('desde', 'hasta'):
        filtros[campo] = None
        raw = datos.get(campo, '')
        if raw:
            try:
                if len(raw) != 10:
                    raise ValueError
                filtros[campo] = date.fromisoformat(raw)
            except ValueError:
                errores[campo] = ['Ingresa una fecha válida en formato AAAA-MM-DD.']
    for n, campo in ((2, 'categoria'), (6, 'proveedor'), (7, 'sucursal'), (8, 'solicitud')):
        if numero == n and not filtros[campo]:
            errores.setdefault(campo, ['Selecciona un registro para este reporte.'])
    if numero in (10, 20):
        for campo in ('desde', 'hasta'):
            if not filtros[campo]:
                errores.setdefault(campo, ['Indica ambas fechas del período.'])
    if filtros['desde'] and filtros['hasta'] and filtros['desde'] > filtros['hasta']:
        errores['general'] = ['La fecha inicial no puede ser posterior a la final.']
    columnas, rows, titulo = [], [], ''
    if not errores:
        columnas, rows = generar_reporte(numero, filtros)
        titulo = TITULOS[numero - 1]
    else:
        numero = None
    parametros = datos.copy()
    parametros.pop('pagina', None)
    pagina = Paginator(rows, 25).get_page(datos.get('pagina'))
    pagina.object_list = list(pagina.object_list)
    return render(request, 'inventario/reportes.html', {
        'datos': datos, 'errores': errores, 'reportes_disponibles': list(enumerate(TITULOS, 1)),
        'categorias': Categoria.objects.all(), 'proveedores': Proveedor.objects.all(),
        'sucursales': Sucursal.objects.all(), 'solicitudes': Solicitud.objects.select_related('sucursal'),
        'columnas': columnas, 'titulo_reporte': titulo, 'numero': numero,
        'pagina': pagina, 'grafico_reporte': grafico_reporte(numero, pagina.object_list),
        'filtros_query': parametros.urlencode(),
    })


@roles_permitidos('Administrador')
def editar_movimiento(request, pk):
    movimiento = get_object_or_404(Movimiento, pk=pk)
    datos, errores, producto_id, cantidad, _ = _datos_movimiento(request, movimiento)
    if request.method == 'POST' and not errores:
        try:
            registrar_movimiento(producto_id=movimiento.producto_id, usuario=request.user,
                tipo=datos['tipo'], cantidad=cantidad, motivo=datos['motivo'], destino=datos['destino'], instancia=movimiento)
            messages.success(request, 'Último movimiento corregido y saldo actualizado.')
            return redirect('movimientos')
        except ValidationError as error:
            _errores_modelo(errores, error)
    return _pantalla_movimiento(request, datos, errores, movimiento)


@roles_permitidos('Administrador')
def eliminar_movimiento(request, pk):
    movimiento = get_object_or_404(Movimiento, pk=pk)
    if request.method == 'POST':
        try:
            eliminar_ultimo(movimiento)
            messages.success(request, 'Último movimiento eliminado y stock restaurado.')
        except ValidationError as error:
            messages.error(request, ' '.join(error.messages))
        return redirect('movimientos')
    return render(request, 'gestion/eliminar.html', {'objeto': movimiento, 'volver': 'movimientos'})


@login_required
def ubicaciones(request):
    rows = Producto.objects.filter(activo=True)
    q = request.GET.get('q', '').strip()
    if q:
        rows = rows.filter(Q(ubicacion__icontains=q) | Q(nombre__icontains=q) | Q(codigo__icontains=q))
    lugares = rows.order_by().values('ubicacion').annotate(
        productos=Count('pk'), unidades=Sum('stock')).order_by('ubicacion')
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    return render(request, 'inventario/ubicaciones.html', {
        'pagina': Paginator(lugares, 20).get_page(request.GET.get('pagina')),
        'filtros_query': parametros.urlencode(),
    })


class Echo:
    def write(self, text):
        return text


@login_required
def exportar(request, tipo):
    if tipo == 'productos':
        rows = Producto.objects.select_related('categoria').filter(activo=True)
        header = ['SKU', 'Producto', 'Categoría', 'Ubicación', 'Stock', 'Mínimo']
        values = ([p.codigo, p.nombre, p.categoria.nombre, p.ubicacion, p.stock, p.stock_minimo]
                  for p in rows.iterator(chunk_size=2000))
    elif tipo == 'movimientos':
        rows = filtrar_movimientos(request)
        header = ['ID', 'Fecha', 'SKU', 'Tipo', 'Anterior', 'Variación', 'Posterior', 'Responsable', 'Motivo', 'Destino']
        values = ([m.pk, timezone.localtime(m.fecha).isoformat(), m.producto.codigo, m.get_tipo_display(),
                   m.anterior, m.variacion, m.posterior, m.usuario.username, m.motivo, m.destino]
                  for m in rows.iterator(chunk_size=2000))
    else:
        raise Http404

    def content():
        writer = csv.writer(Echo(), delimiter=';')
        yield '\ufeff'
        yield writer.writerow(header)
        for row in values:
            yield writer.writerow(["'" + v if isinstance(v, str) and v.lstrip().startswith(('=', '+', '-', '@')) else v
                                   for v in row])

    response = StreamingHttpResponse(content(), content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = f'attachment; filename="soundstock-{tipo}.csv"'
    return response


# Las rutas conservan sus nombres y orden; las operaciones POST se procesan aquí.
@login_required
def sucursales(request):
    return render(request, 'gestion/lista.html', contexto_catalogo(request, Sucursal,
        titulo='Sucursales', nombre='sucursales', campos=('codigo', 'nombre', 'direccion', 'contacto', 'email', 'activa')))


@roles_permitidos('Administrador', 'Operador')
def sucursal_guardar(request, pk=None):
    obj = get_object_or_404(Sucursal, pk=pk) if pk else Sucursal()
    campos = ('codigo', 'nombre', 'direccion', 'contacto', 'email', 'telefono', 'activa')
    datos = {campo: getattr(obj, campo) for campo in campos}
    errores = {}
    if request.method == 'POST':
        datos = {campo: request.POST.get(campo, '').strip() for campo in campos}
        datos['codigo'] = datos['codigo'].upper() or codigo_sucursal()
        datos['activa'] = datos['activa'].lower() in ('on', '1', 'true')
        for campo in campos:
            setattr(obj, campo, datos[campo])
        try:
            obj.full_clean()
        except ValidationError as error:
            _errores_modelo(errores, error)
        if not errores:
            try:
                with transaction.atomic():
                    obj.save()
                messages.success(request, 'Registro guardado.')
                return redirect('sucursales')
            except IntegrityError:
                errores['general'] = ['El código o nombre de sucursal ya existe.']
    return render(request, 'gestion/formulario.html', {'tipo_formulario': 'sucursal',
        'titulo': f'{"Editar" if pk else "Crear"}: Sucursales', 'datos': datos, 'errores': errores, 'volver': 'sucursales'})


@roles_permitidos('Administrador')
def sucursal_eliminar(request, pk):
    obj = get_object_or_404(Sucursal, pk=pk)
    if request.method == 'POST':
        try:
            with transaction.atomic():
                obj.delete()
            messages.success(request, 'Registro eliminado.')
        except ProtectedError:
            messages.error(request, 'El registro tiene solicitudes asociadas y se debe conservar.')
        return redirect('sucursales')
    return render(request, 'gestion/eliminar.html', {'objeto': obj, 'volver': 'sucursales'})


@login_required
def solicitudes_lista(request):
    rows = Solicitud.objects.select_related('sucursal', 'usuario').annotate(
        productos=Count('detalles'), unidades=Sum('detalles__cantidad')).order_by('-fecha', '-pk')
    if request.GET.get('estado') in dict(Solicitud.ESTADOS):
        rows = rows.filter(estado=request.GET['estado'])
    q = request.GET.get('q', '').strip()
    if q:
        rows = rows.filter(Q(sucursal__nombre__icontains=q) | Q(usuario__username__icontains=q))
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    return render(request, 'inventario/solicitudes.html', {
        'pagina': Paginator(rows, 20).get_page(request.GET.get('pagina')),
        'estados': Solicitud.ESTADOS, 'filtros_query': parametros.urlencode(),
    })


def _capturar_lineas(request, obj, errores):
    existentes = {detalle.pk: detalle for detalle in obj.detalles.all()} if obj.pk else {}
    total = _entero(request.POST.get('detalles-TOTAL_FORMS'), errores, 'detalles', 1, 100)
    lineas, guardar, enviados, productos_usados = [], [], set(), set()
    for i in range(total or 1):
        prefijo = f'detalles-{i}-'
        fila = {'indice': i, 'id': request.POST.get(prefijo+'id', '').strip(),
            'producto': request.POST.get(prefijo+'producto', '').strip(),
            'cantidad': request.POST.get(prefijo+'cantidad', '').strip(),
            'eliminar': request.POST.get(prefijo+'DELETE', '').lower() in ('on','1','true'), 'errores': {}}
        lineas.append(fila)
        row_errors = fila['errores']
        detalle_id = None
        if fila['id']:
            detalle_id = _entero(fila['id'], row_errors, 'id', 1, 9223372036854775807)
            if detalle_id not in existentes or detalle_id in enviados:
                row_errors['id'] = ['Esta línea no pertenece a la solicitud o está repetida.']
            else:
                enviados.add(detalle_id)
        if fila['eliminar']:
            continue
        if not fila['id'] and not fila['producto'] and not fila['cantidad']:
            continue
        producto_id = _entero(fila['producto'], row_errors, 'producto', 1, 9223372036854775807)
        cantidad = _entero(fila['cantidad'], row_errors, 'cantidad', 1, 1000000)
        producto = Producto.objects.filter(pk=producto_id, activo=True).first() if producto_id else None
        if producto_id and not producto:
            row_errors['producto'] = ['Selecciona un producto activo.']
        if producto_id in productos_usados:
            row_errors['producto'] = ['Un producto solo puede aparecer una vez por solicitud.']
        productos_usados.add(producto_id)
        if not row_errors:
            guardar.append({'id': detalle_id, 'producto': producto, 'cantidad': cantidad})
    if enviados != set(existentes):
        errores['detalles'] = ['El detalle cambió o faltan líneas existentes. Recarga la solicitud antes de editar.']
    if any(fila['errores'] for fila in lineas):
        errores.setdefault('detalles', []).append('Revisa los productos y cantidades de las líneas marcadas.')
    if not guardar and not errores:
        errores['detalles'] = ['Agrega al menos un producto a la solicitud.']
    return lineas, guardar


@roles_permitidos('Administrador', 'Operador')
def solicitud_guardar(request, pk=None):
    datos, errores, lineas = {}, {}, []
    with transaction.atomic():
        obj = get_object_or_404(Solicitud.objects.select_for_update(), pk=pk) if pk else Solicitud(usuario=request.user)
        if obj.estado != 'pendiente':
            messages.error(request, 'Solo se pueden modificar solicitudes pendientes.')
            return redirect('solicitud_detalle', pk=obj.pk)
        if request.method == 'POST':
            datos = {'sucursal': request.POST.get('sucursal', '').strip(),
                'observacion': request.POST.get('observacion', '').strip()}
            sucursal_id = _entero(datos['sucursal'], errores, 'sucursal', 1, 9223372036854775807)
            sucursal = Sucursal.objects.filter(pk=sucursal_id, activa=True).first() if sucursal_id else None
            if sucursal_id and not sucursal:
                errores['sucursal'] = ['Selecciona una sucursal activa.']
            if len(datos['observacion']) > 1000:
                errores['observacion'] = ['La observación admite hasta 1.000 caracteres.']
            lineas, pendientes = _capturar_lineas(request, obj, errores)
            if not errores:
                obj.sucursal = sucursal
                obj.observacion = datos['observacion']
                try:
                    obj.full_clean()
                except ValidationError as error:
                    _errores_modelo(errores, error)
            if not errores:
                try:
                    with transaction.atomic():
                        obj.save()
                        if obj.detalles.filter(movimiento__isnull=False).exists():
                            raise ValidationError('La solicitud tiene movimientos y debe conservar su detalle.')
                        # Se preservan los ID de las líneas existentes, incluso al intercambiar productos.
                        obj.detalles.all().delete()
                        for fila in pendientes:
                            detalle = DetalleSolicitud(pk=fila['id'], solicitud=obj,
                                producto=fila['producto'], cantidad=fila['cantidad'])
                            detalle.full_clean()
                            detalle.save()
                    messages.success(request, 'Solicitud guardada. El stock cambia al despachar.')
                    return redirect('solicitud_detalle', pk=obj.pk)
                except (ValidationError, ProtectedError) as error:
                    errores['general'] = error.messages if isinstance(error, ValidationError) else ['El historial de la solicitud está protegido.']
                except IntegrityError:
                    errores['general'] = ['El detalle cambió. Recarga la página y revisa los productos.']
        else:
            datos = {'sucursal': str(obj.sucursal_id or ''), 'observacion': obj.observacion}
            existentes = list(obj.detalles.all()) if obj.pk else []
            for i, detalle in enumerate(existentes):
                lineas.append({'indice': i, 'id': str(detalle.pk), 'producto': str(detalle.producto_id),
                    'cantidad': str(detalle.cantidad), 'eliminar': False, 'errores': {}})
            for i in range(len(existentes), min(100, max(4, len(existentes)+3))):
                lineas.append({'indice': i, 'id': '', 'producto': '', 'cantidad': '', 'eliminar': False, 'errores': {}})
    return render(request, 'inventario/solicitud_formulario.html', {
        'objeto': obj, 'tipo_formulario': 'solicitud', 'datos': datos, 'errores': errores,
        'lineas': lineas, 'total_lineas': len(lineas), 'lineas_iniciales': obj.detalles.count() if obj.pk else 0,
        'sucursales': Sucursal.objects.filter(activa=True), 'productos': Producto.objects.filter(activo=True).order_by('codigo'),
    })


@login_required
def solicitud_detalle(request, pk):
    obj = get_object_or_404(Solicitud.objects.select_related('sucursal', 'usuario', 'atendida_por', 'despachada_por'), pk=pk)
    return render(request, 'inventario/solicitud_detalle.html', {'objeto': obj, 'detalles': obj.detalles.select_related('producto')})


@roles_permitidos('Administrador')
def solicitud_eliminar(request, pk):
    with transaction.atomic():
        obj = get_object_or_404(Solicitud.objects.select_for_update(), pk=pk)
        if obj.estado != 'pendiente':
            messages.error(request, 'Solo se eliminan solicitudes pendientes; las atendidas conservan su historial.')
            return redirect('solicitud_detalle', pk=pk)
        if request.method == 'POST':
            obj.delete()
            messages.success(request, 'Solicitud pendiente y sus detalles eliminados.')
            return redirect('solicitudes')
    return render(request, 'gestion/eliminar.html', {'objeto': obj, 'volver': 'solicitudes'})


@require_POST
@roles_permitidos('Administrador')
def solicitud_revisar(request, pk):
    get_object_or_404(Solicitud, pk=pk)
    try:
        revisar_solicitud(solicitud_id=pk, usuario=request.user,
            estado=request.POST.get('estado'), respuesta=request.POST.get('respuesta', ''))
        messages.success(request, 'Revisión registrada.')
    except ValidationError as error:
        messages.error(request, ' '.join(error.messages))
    return redirect('solicitud_detalle', pk=pk)


@require_POST
@roles_permitidos('Administrador', 'Operador')
def solicitud_despachar(request, pk):
    get_object_or_404(Solicitud, pk=pk)
    try:
        _, creado = despachar_solicitud(solicitud_id=pk, usuario=request.user)
        messages.success(request, 'Solicitud despachada y stock actualizado.' if creado else 'El despacho ya estaba registrado.')
    except ValidationError as error:
        messages.error(request, 'No se realizó el despacho: ' + ' '.join(error.messages))
    return redirect('solicitud_detalle', pk=pk)
