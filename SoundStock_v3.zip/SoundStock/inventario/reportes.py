"""Las 20 consultas de BODEGA de la guía E3, resueltas exclusivamente con ORM."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, Max, Sum, Value
from django.db.models.functions import Coalesce
from django.utils import timezone

from catalogo.models import Categoria, Producto, Proveedor
from .models import DetalleSolicitud, Movimiento, Solicitud, Sucursal

TITULOS = [
    'Todos los productos registrados', 'Productos de una categoría', 'Stock por debajo del mínimo',
    'Los 10 productos con mayor precio', 'Cantidad de productos por categoría', 'Productos de un proveedor',
    'Solicitudes de una sucursal', 'Productos y cantidades de una solicitud', 'Solicitudes por estado',
    'Solicitudes en un rango de fechas', 'Las cinco sucursales con más unidades solicitadas',
    'Productos más solicitados', 'Proveedor con más productos diferentes', 'Valor total del inventario',
    'Productos nunca solicitados', 'Unidades salidas durante el mes anterior', 'Sucursales con solicitudes pendientes',
    'Categoría con mayor valor de inventario', 'Promedio de unidades por solicitud',
    'Los cinco productos con más unidades solicitadas en un período',
]


def valor_stock():
    return ExpressionWrapper(F('precio') * F('stock'), output_field=DecimalField(max_digits=24, decimal_places=2))


def generar_reporte(numero, filtros):
    # Se incluyen productos archivados e historial: la guía habla de todos los registros.
    productos = Producto.objects.all()
    solicitudes = Solicitud.objects.select_related('sucursal')
    campos_producto = ('codigo', 'nombre', 'categoria__nombre', 'precio', 'stock')
    columnas_producto = ['SKU', 'Producto', 'Categoría', 'Precio CLP', 'Stock']
    if numero == 1:
        return columnas_producto, productos.order_by('nombre', 'pk').values_list(*campos_producto)
    if numero == 2:
        return columnas_producto, productos.filter(categoria=filtros['categoria']).values_list(*campos_producto)
    if numero == 3:
        return ['SKU', 'Producto', 'Stock', 'Mínimo'], productos.filter(stock__lt=F('stock_minimo')).values_list(
            'codigo', 'nombre', 'stock', 'stock_minimo')
    if numero == 4:
        return columnas_producto, productos.order_by('-precio', 'pk').values_list(*campos_producto)[:10]
    if numero == 5:
        return ['Categoría', 'Productos'], Categoria.objects.annotate(total=Count('productos')).order_by('nombre', 'pk').values_list('nombre', 'total')
    if numero == 6:
        return columnas_producto, productos.filter(proveedor=filtros['proveedor']).values_list(*campos_producto)
    if numero in (7, 10):
        if numero == 7:
            solicitudes = solicitudes.filter(sucursal=filtros['sucursal'])
        else:
            solicitudes = solicitudes.filter(fecha__date__range=(filtros['desde'], filtros['hasta']))
        return ['Solicitud', 'Sucursal', 'Fecha', 'Estado'], solicitudes.values_list('pk', 'sucursal__nombre', 'fecha', 'estado')
    if numero == 8:
        return ['SKU', 'Producto', 'Solicitadas', 'Aprobadas', 'Despachadas'], DetalleSolicitud.objects.filter(solicitud=filtros['solicitud']).values_list(
            'producto__codigo', 'producto__nombre', 'cantidad', 'cantidad_aprobada', 'cantidad_despachada')
    if numero == 9:
        conteos = dict(Solicitud.objects.order_by().values('estado').annotate(total=Count('pk')).values_list('estado', 'total'))
        return ['Estado', 'Solicitudes'], [(etiqueta, conteos.get(estado, 0)) for estado, etiqueta in Solicitud.ESTADOS]
    if numero == 11:
        return ['Sucursal', 'Unidades solicitadas'], Sucursal.objects.annotate(total=Sum('solicitudes__detalles__cantidad')).filter(
            total__gt=0).order_by('-total', 'pk').values_list('nombre', 'total')[:5]
    if numero in (12, 20):
        if numero == 20:
            productos = productos.filter(detalles_solicitud__solicitud__fecha__date__range=(filtros['desde'], filtros['hasta']))
        rows = productos.annotate(total=Sum('detalles_solicitud__cantidad')).filter(total__gt=0).order_by('-total', 'pk')
        rows = rows.values_list('codigo', 'nombre', 'total')
        return ['SKU', 'Producto', 'Unidades solicitadas'], rows[:5] if numero == 20 else rows
    if numero == 13:
        proveedores = Proveedor.objects.annotate(total=Count('productos', distinct=True))
        maximo = proveedores.aggregate(maximo=Max('total'))['maximo'] or 0
        return ['Proveedor', 'Productos diferentes'], proveedores.filter(total=maximo, total__gt=0).order_by('nombre', 'pk').values_list('nombre', 'total')
    if numero == 14:
        total = productos.aggregate(total=Sum(valor_stock()))['total'] or Decimal('0')
        return ['Concepto', 'Monto CLP'], [('Valor total del inventario', total.quantize(Decimal('0.01')))]
    if numero == 15:
        return columnas_producto, productos.filter(detalles_solicitud__isnull=True).values_list(*campos_producto)
    if numero == 16:
        fin = timezone.localdate().replace(day=1)
        inicio = (fin - timedelta(days=1)).replace(day=1)
        rows = Movimiento.objects.filter(tipo='salida', fecha__date__gte=inicio, fecha__date__lt=fin).order_by().values(
            'producto__codigo', 'producto__nombre').annotate(unidades=-Sum('variacion')).order_by('-unidades', 'producto__codigo')
        return ['SKU', 'Producto', 'Unidades salidas'], rows.values_list('producto__codigo', 'producto__nombre', 'unidades')
    if numero == 17:
        return ['Sucursal', 'Pendientes'], Sucursal.objects.filter(solicitudes__estado='pendiente').annotate(
            total=Count('solicitudes')).order_by('nombre', 'pk').values_list('nombre', 'total')
    if numero == 18:
        valor = ExpressionWrapper(F('productos__precio') * F('productos__stock'),
            output_field=DecimalField(max_digits=24, decimal_places=2))
        return ['Categoría', 'Valor CLP'], Categoria.objects.annotate(total=Coalesce(Sum(valor),
            Value(Decimal('0')), output_field=DecimalField(max_digits=24, decimal_places=2))).order_by(
            '-total', 'pk').values_list('nombre', 'total')[:1]
    if numero == 19:
        total = Solicitud.objects.annotate(unidades=Coalesce(Sum('detalles__cantidad'), 0)).aggregate(
            promedio=Avg('unidades'))['promedio'] or 0
        return ['Concepto', 'Unidades'], [('Promedio de unidades por solicitud', round(total, 2))]
    raise ValueError('Número de reporte inválido.')
