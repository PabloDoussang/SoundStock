from decimal import Decimal, InvalidOperation
from django import template

register = template.Library()


@register.filter
def numero_cl(valor):
    try:
        return f'{Decimal(str(valor or 0)):,.0f}'.replace(',', '.')
    except (InvalidOperation, ValueError, TypeError):
        return valor


@register.filter
def moneda_cl(valor):
    try:
        numero = Decimal(str(valor or 0))
        texto = f'{numero:,.2f}' if numero % 1 else f'{numero:,.0f}'
        return '$' + texto.replace(',', '_').replace('.', ',').replace('_', '.')
    except (InvalidOperation, ValueError, TypeError):
        return valor


@register.filter
def tono_estado(estado):
    return {'pendiente': 'amber', 'aprobada': 'purple', 'rechazada': 'red',
        'despachada': 'green', 'entrada': 'purple', 'salida': 'green', 'ajuste': 'amber',
        'Disponible': 'green', 'Bajo': 'amber', 'Agotado': 'red'}.get(str(estado), 'neutral')
