from django.contrib import admin

from .models import Movimiento
from . import views


@admin.register(Movimiento)
class MovimientoAdmin(admin.ModelAdmin):
    # El listado de Admin se conserva; las operaciones usan las mismas vistas HTML.
    list_display = ('id', 'producto', 'tipo', 'variacion', 'anterior', 'posterior', 'usuario', 'fecha')
    list_filter = ('tipo', 'fecha', 'producto__categoria')
    search_fields = ('producto__codigo', 'producto__nombre', 'usuario__username', 'motivo', 'destino')
    list_select_related = ('producto', 'usuario')
    date_hierarchy = 'fecha'
    list_per_page = 25
    show_full_result_count = False
    actions = None

    def add_view(self, request, form_url='', extra_context=None):
        return views.nuevo_movimiento(request)

    def change_view(self, request, object_id, form_url='', extra_context=None):
        return views.editar_movimiento(request, object_id)

    def delete_view(self, request, object_id, extra_context=None):
        return views.eliminar_movimiento(request, object_id)

    def has_delete_permission(self, request, obj=None):
        return super().has_delete_permission(request, obj) and (
            obj is None or (not obj.detalle_solicitud_id and obj.producto.activo
                and obj.producto.movimientos.order_by('-pk').first().pk == obj.pk))

    def has_change_permission(self, request, obj=None):
        return super().has_change_permission(request, obj) and (obj is None or not obj.detalle_solicitud_id)
