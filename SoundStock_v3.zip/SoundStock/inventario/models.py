import uuid

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import F, Q
from django.utils import timezone

from catalogo.models import Producto


def codigo_sucursal():
    return f'SUC-{uuid.uuid4().hex[:12].upper()}'


class Sucursal(models.Model):
    codigo = models.CharField('código', max_length=30, unique=True, default=codigo_sucursal)
    nombre = models.CharField(max_length=120, unique=True)
    direccion = models.CharField(max_length=200)
    contacto = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    activa = models.BooleanField(default=True)

    class Meta:
        ordering = ['nombre']
        verbose_name_plural = 'sucursales'

    def __str__(self):
        return self.nombre


class Solicitud(models.Model):
    ESTADOS = [('pendiente', 'Pendiente'), ('aprobada', 'Aprobada'),
               ('rechazada', 'Rechazada'), ('despachada', 'Despachada')]
    sucursal = models.ForeignKey(Sucursal, on_delete=models.PROTECT, related_name='solicitudes')
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='solicitudes')
    fecha = models.DateTimeField(default=timezone.now, db_index=True)
    estado = models.CharField(max_length=12, choices=ESTADOS, default='pendiente', db_index=True)
    observacion = models.TextField(blank=True, max_length=1000)
    respuesta = models.CharField(max_length=240, blank=True)
    atendida_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
        related_name='solicitudes_atendidas', null=True, blank=True)
    fecha_revision = models.DateTimeField(null=True, blank=True)
    despachada_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
        related_name='solicitudes_despachadas', null=True, blank=True)
    fecha_despacho = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-fecha', '-pk']
        verbose_name_plural = 'solicitudes'
        constraints = [models.CheckConstraint(condition=Q(estado__in=[
            'pendiente', 'aprobada', 'rechazada', 'despachada']), name='solicitud_estado_valido')]

    def __str__(self):
        return f'SOL-{self.pk:05d} · {self.sucursal}' if self.pk else 'Nueva solicitud'


class DetalleSolicitud(models.Model):
    solicitud = models.ForeignKey(Solicitud, on_delete=models.CASCADE, related_name='detalles')
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name='detalles_solicitud')
    cantidad = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(1000000)])
    cantidad_aprobada = models.PositiveIntegerField(default=0)
    cantidad_despachada = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['pk']
        verbose_name_plural = 'detalles de solicitud'
        constraints = [
            models.UniqueConstraint(fields=['solicitud', 'producto'], name='solicitud_producto_unico'),
            models.CheckConstraint(condition=Q(cantidad__gte=1, cantidad__lte=1000000),
                name='detalle_cantidad_valida'),
            models.CheckConstraint(condition=Q(cantidad_aprobada__lte=F('cantidad')) &
                Q(cantidad_despachada__lte=F('cantidad_aprobada')), name='detalle_cantidades_coherentes'),
        ]

    def __str__(self):
        return f'{self.producto} × {self.cantidad}'


class Movimiento(models.Model):
    TIPOS = [('entrada', 'Entrada'), ('salida', 'Salida'), ('ajuste', 'Ajuste')]
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name='movimientos')
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='movimientos')
    tipo = models.CharField(max_length=10, choices=TIPOS)
    anterior = models.PositiveIntegerField()
    posterior = models.PositiveIntegerField()
    variacion = models.IntegerField()
    motivo = models.CharField(max_length=240)
    destino = models.CharField(max_length=120, blank=True)
    fecha = models.DateTimeField(default=timezone.now, db_index=True)
    token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    detalle_solicitud = models.OneToOneField(DetalleSolicitud, on_delete=models.PROTECT,
        related_name='movimiento', null=True, blank=True)

    class Meta:
        ordering = ['-fecha', '-pk']
        verbose_name = 'movimiento'
        verbose_name_plural = 'movimientos'
        constraints = [
            models.CheckConstraint(condition=Q(posterior=F('anterior') + F('variacion')), name='movimiento_saldo_cuadra'),
            models.CheckConstraint(condition=Q(posterior__lte=1000000) & Q(anterior__lte=1000000), name='movimiento_saldo_maximo'),
            models.CheckConstraint(condition=Q(tipo__in=['entrada', 'salida', 'ajuste']), name='movimiento_tipo_valido'),
            models.CheckConstraint(condition=(Q(tipo='entrada', variacion__gt=0) | Q(tipo='salida', variacion__lt=0) |
                (Q(tipo='ajuste') & ~Q(variacion=0))), name='movimiento_signo_valido'),
            models.CheckConstraint(condition=~Q(tipo='salida') | ~Q(destino=''), name='movimiento_destino_salida'),
        ]

    def __str__(self):
        return f'MOV-{self.pk:05d} · {self.get_tipo_display()}' if self.pk else 'Nuevo movimiento'
