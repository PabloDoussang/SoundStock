"""Verifica los datos de los gráficos y su exposición en las páginas protegidas."""
import json
import re
from datetime import timedelta
from decimal import Decimal

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from catalogo.models import Categoria, Producto
from .models import DetalleSolicitud, Movimiento, Solicitud, Sucursal
from .panel import contexto_panel
from .services import registrar_movimiento, revisar_solicitud
from .templatetags.presentacion import moneda_cl
from usuarios.models import Usuario


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class PanelVisualTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = Usuario.objects.create_superuser('panel_admin', password='Prueba-Panel-2026!')
        cls.cat = Categoria.objects.create(nombre='Instrumentos del panel')
        cls.producto = Producto.objects.create(codigo='PANEL-001', nombre='Guitarra', categoria=cls.cat,
            precio=Decimal('100.25'), ubicacion='A-01', stock_minimo=5)
        cls.agotado = Producto.objects.create(codigo='PANEL-002', nombre='Agotado', categoria=cls.cat,
            precio=20, ubicacion='A-02', stock_minimo=2)
        Producto.objects.create(codigo='PANEL-ARC', nombre='Archivado', categoria=cls.cat,
            precio=99, ubicacion='A-03', activo=False, stock=10)
        inicial, _ = registrar_movimiento(producto_id=cls.producto.pk, usuario=cls.admin,
            tipo='entrada', cantidad=20, motivo='Entrada anterior al período')
        Movimiento.objects.filter(pk=inicial.pk).update(fecha=timezone.now()-timedelta(days=35))
        registrar_movimiento(producto_id=cls.producto.pk, usuario=cls.admin,
            tipo='entrada', cantidad=5, motivo='Entrada reciente')
        salida, _ = registrar_movimiento(producto_id=cls.producto.pk, usuario=cls.admin,
            tipo='salida', cantidad=2, motivo='Salida reciente', destino='Sucursal')
        Movimiento.objects.filter(pk=salida.pk).update(fecha=timezone.now()-timedelta(days=1))
        registrar_movimiento(producto_id=cls.producto.pk, usuario=cls.admin,
            tipo='ajuste', cantidad=9, motivo='Conteo físico')
        sucursal = Sucursal.objects.create(nombre='Sucursal panel', direccion='Demo')
        for estado, cantidad in [('pendiente',3),('aprobada',4),('rechazada',2)]:
            solicitud = Solicitud.objects.create(sucursal=sucursal, usuario=cls.admin)
            DetalleSolicitud.objects.create(solicitud=solicitud, producto=cls.producto, cantidad=cantidad)
            if estado != 'pendiente':
                revisar_solicitud(solicitud_id=solicitud.pk, usuario=cls.admin, estado=estado, respuesta='Ejemplo')

    def setUp(self):
        self.client.force_login(self.admin)

    def test_indicadores_excluyen_productos_archivados(self):
        ctx = contexto_panel()
        self.assertEqual((ctx['cantidad_productos'], ctx['unidades'], ctx['alertas'], ctx['agotados']), (2,9,1,1))
        self.assertEqual(ctx['valor_inventario'], Decimal('902.25'))
        self.assertEqual(ctx['grafico_categorias']['series'][0]['values'], [9])

    def test_series_del_periodo_separan_entradas_salidas_y_ajustes(self):
        ctx = contexto_panel(7)
        series = ctx['grafico_movimientos']['series']
        self.assertEqual(len(ctx['grafico_movimientos']['labels']), 7)
        self.assertEqual(sum(series[0]['values']), 5)
        self.assertEqual(sum(series[1]['values']), 2)
        self.assertEqual(sum(fila[3] for fila in ctx['tabla_actividad']), -14)
        self.assertEqual(sum(contexto_panel(90)['grafico_movimientos']['series'][0]['values']), 25)

    def test_periodos_invalidos_se_limitan_a_30_dias(self):
        for valor, esperado in [('7',7),('30',30),('90',90),('999999999',30),('-4',30),('abc',30)]:
            r = self.client.get(reverse('inicio'), {'dias': valor})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.context['dias'], esperado)
            self.assertEqual(len(r.context['grafico_movimientos']['labels']), esperado)

    def test_grafico_de_estados_incluye_ceros_y_conteos_reales(self):
        valores = contexto_panel()['grafico_solicitudes']['series'][0]['values']
        self.assertEqual(valores, [1,1,1,0])
        self.assertEqual(contexto_panel()['pendientes'], 1)

    def test_datos_json_escapan_texto_y_requieren_sesion(self):
        etiqueta = '</script><script>alert("prueba")</script>'
        Categoria.objects.filter(pk=self.cat.pk).update(nombre=etiqueta)
        r = self.client.get(reverse('inicio'))
        html = r.content.decode()
        self.assertNotIn(etiqueta, html)
        match = re.search(r'<script id="datos-categorias" type="application/json">(.*?)</script>', html)
        self.assertIsNotNone(match)
        self.assertEqual(json.loads(match.group(1))['labels'], [etiqueta])
        self.client.logout()
        r = self.client.get(reverse('inicio'))
        self.assertEqual(r.status_code, 302)
        self.assertNotIn('datos-categorias', r.content.decode())

    def test_grafico_de_reporte_corresponde_solo_a_la_pagina_visible(self):
        Categoria.objects.bulk_create([Categoria(nombre=f'Categoría visual {n:02d}') for n in range(30)])
        for pagina in (1,2):
            r = self.client.get(reverse('reportes'), {'reporte': 5, 'pagina': pagina})
            filas = list(r.context['pagina'])
            chart = r.context['grafico_reporte']
            self.assertEqual(chart['labels'], [fila[0] for fila in filas])
            self.assertEqual(chart['series'][0]['values'], [float(fila[1]) for fila in filas])
            self.assertLessEqual(len(chart['labels']), 25)

    def test_panel_vacio_contiene_ceros_y_listas_validas(self):
        Solicitud.objects.all().delete()
        Movimiento.objects.all().delete()
        Producto.objects.all().delete()
        ctx = contexto_panel()
        self.assertEqual((ctx['cantidad_productos'],ctx['unidades'],ctx['valor_inventario']), (0,0,0))
        self.assertEqual(ctx['grafico_categorias']['labels'], [])
        self.assertEqual(ctx['grafico_solicitudes']['series'][0]['values'], [0,0,0,0])
        self.assertTrue(all(v==0 for s in ctx['grafico_movimientos']['series'] for v in s['values']))

    def test_formato_clp_conserva_decimales_sin_cambiar_el_precio(self):
        self.assertEqual(moneda_cl(Decimal('902.25')), '$902,25')
        self.assertEqual(moneda_cl(Decimal('1234567.00')), '$1.234.567')
