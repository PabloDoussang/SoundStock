from django.urls import path

from . import views
from . import solicitudes

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('movimientos/', views.movimientos, name='movimientos'),
    path('movimientos/nuevo/', views.nuevo_movimiento, name='movimiento_crear'),
    path('movimientos/<int:pk>/editar/', views.editar_movimiento, name='movimiento_editar'),
    path('movimientos/<int:pk>/eliminar/', views.eliminar_movimiento, name='movimiento_eliminar'),
    path('sucursales/', solicitudes.sucursales, name='sucursales'),
    path('sucursales/nueva/', solicitudes.sucursal_guardar, name='sucursales_crear'),
    path('sucursales/<int:pk>/editar/', solicitudes.sucursal_guardar, name='sucursales_editar'),
    path('sucursales/<int:pk>/eliminar/', solicitudes.sucursal_eliminar, name='sucursales_eliminar'),
    path('solicitudes/', solicitudes.lista, name='solicitudes'),
    path('solicitudes/nueva/', solicitudes.guardar, name='solicitud_crear'),
    path('solicitudes/<int:pk>/', solicitudes.detalle, name='solicitud_detalle'),
    path('solicitudes/<int:pk>/editar/', solicitudes.guardar, name='solicitud_editar'),
    path('solicitudes/<int:pk>/eliminar/', solicitudes.eliminar, name='solicitud_eliminar'),
    path('solicitudes/<int:pk>/revisar/', solicitudes.revisar, name='solicitud_revisar'),
    path('solicitudes/<int:pk>/despachar/', solicitudes.despachar, name='solicitud_despachar'),
    path('reportes/', views.reportes, name='reportes'),
    path('ubicaciones/', views.ubicaciones, name='ubicaciones'),
    path('exportar/<str:tipo>/', views.exportar, name='exportar'),
]
