# Modelo de datos de SoundStock Bodega

Generado con `python manage.py diagrama_bd` a partir de los ocho modelos de negocio.
Se conserva el nombre `Movimiento` del proyecto original para implementar `MovimientoStock` de la guía.
Las tablas internas de autenticación, grupos, permisos y sesiones son administradas por Django.

```mermaid
erDiagram
    direction TB
    catalogo_categoria {
        BigAutoField id PK
        CharField nombre UK
        TextField descripcion
    }
    catalogo_proveedor {
        BigAutoField id PK
        CharField nombre UK
        CharField rut UK
        CharField contacto
        CharField email
        CharField telefono
        CharField direccion
        BooleanField activo
    }
    catalogo_producto {
        BigAutoField id PK
        CharField codigo UK
        CharField nombre
        ForeignKey categoria_id FK
        ForeignKey proveedor_id FK
        DecimalField precio
        CharField ubicacion
        PositiveIntegerField stock
        PositiveIntegerField stock_minimo
        BooleanField activo
        TextField descripcion
    }
    inventario_sucursal {
        BigAutoField id PK
        CharField codigo UK
        CharField nombre UK
        CharField direccion
        CharField contacto
        CharField email
        CharField telefono
        BooleanField activa
    }
    inventario_solicitud {
        BigAutoField id PK
        ForeignKey sucursal_id FK
        ForeignKey usuario_id FK
        DateTimeField fecha
        CharField estado
        TextField observacion
        CharField respuesta
        ForeignKey atendida_por_id FK
        DateTimeField fecha_revision
        ForeignKey despachada_por_id FK
        DateTimeField fecha_despacho
    }
    inventario_detallesolicitud {
        BigAutoField id PK
        ForeignKey solicitud_id FK
        ForeignKey producto_id FK
        PositiveIntegerField cantidad
        PositiveIntegerField cantidad_aprobada
        PositiveIntegerField cantidad_despachada
    }
    inventario_movimiento {
        BigAutoField id PK
        ForeignKey producto_id FK
        ForeignKey usuario_id FK
        CharField tipo
        PositiveIntegerField anterior
        PositiveIntegerField posterior
        IntegerField variacion
        CharField motivo
        CharField destino
        DateTimeField fecha
        UUIDField token UK
        OneToOneField detalle_solicitud_id FK,UK
    }
    usuarios_usuario {
        BigAutoField id PK
        CharField password
        DateTimeField last_login
        BooleanField is_superuser
        CharField first_name
        CharField last_name
        CharField email
        BooleanField is_staff
        BooleanField is_active
        DateTimeField date_joined
        CharField username UK
        CharField rol
    }
    catalogo_categoria ||--o{ catalogo_producto : categoria_id
    catalogo_proveedor |o--o{ catalogo_producto : proveedor_id
    inventario_sucursal ||--o{ inventario_solicitud : sucursal_id
    usuarios_usuario ||--o{ inventario_solicitud : usuario_id
    usuarios_usuario |o--o{ inventario_solicitud : atendida_por_id
    usuarios_usuario |o--o{ inventario_solicitud : despachada_por_id
    inventario_solicitud ||--o{ inventario_detallesolicitud : solicitud_id
    catalogo_producto ||--o{ inventario_detallesolicitud : producto_id
    catalogo_producto ||--o{ inventario_movimiento : producto_id
    usuarios_usuario ||--o{ inventario_movimiento : usuario_id
    inventario_detallesolicitud |o--o| inventario_movimiento : detalle_solicitud_id
```

## Diccionario de datos

### catalogo_categoria

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| nombre | varchar(60) | UK | No |  |
| descripcion | text |  | No |  |

### catalogo_proveedor

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| nombre | varchar(150) | UK | No |  |
| rut | varchar(20) | UK | Sí |  |
| contacto | varchar(120) |  | No |  |
| email | varchar(254) |  | No |  |
| telefono | varchar(30) |  | No |  |
| direccion | varchar(200) |  | No |  |
| activo | bool |  | No |  |

### catalogo_producto

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| codigo | varchar(30) | UK | No |  |
| nombre | varchar(120) |  | No |  |
| categoria_id | bigint | FK | No | catalogo_categoria.id |
| proveedor_id | bigint | FK | Sí | catalogo_proveedor.id |
| precio | decimal |  | No |  |
| ubicacion | varchar(60) |  | No |  |
| stock | integer unsigned |  | No |  |
| stock_minimo | integer unsigned |  | No |  |
| activo | bool |  | No |  |
| descripcion | text |  | No |  |

Restricciones: `producto_precio_no_negativo`, `producto_stock_hasta_millon`, `producto_minimo_hasta_millon`.

### inventario_sucursal

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| codigo | varchar(30) | UK | No |  |
| nombre | varchar(120) | UK | No |  |
| direccion | varchar(200) |  | No |  |
| contacto | varchar(120) |  | No |  |
| email | varchar(254) |  | No |  |
| telefono | varchar(30) |  | No |  |
| activa | bool |  | No |  |

### inventario_solicitud

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| sucursal_id | bigint | FK | No | inventario_sucursal.id |
| usuario_id | bigint | FK | No | usuarios_usuario.id |
| fecha | datetime |  | No |  |
| estado | varchar(12) |  | No |  |
| observacion | text |  | No |  |
| respuesta | varchar(240) |  | No |  |
| atendida_por_id | bigint | FK | Sí | usuarios_usuario.id |
| fecha_revision | datetime |  | Sí |  |
| despachada_por_id | bigint | FK | Sí | usuarios_usuario.id |
| fecha_despacho | datetime |  | Sí |  |

Restricciones: `solicitud_estado_valido`.

### inventario_detallesolicitud

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| solicitud_id | bigint | FK | No | inventario_solicitud.id |
| producto_id | bigint | FK | No | catalogo_producto.id |
| cantidad | integer unsigned |  | No |  |
| cantidad_aprobada | integer unsigned |  | No |  |
| cantidad_despachada | integer unsigned |  | No |  |

Restricciones: `solicitud_producto_unico`, `detalle_cantidad_valida`, `detalle_cantidades_coherentes`.

### inventario_movimiento

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| producto_id | bigint | FK | No | catalogo_producto.id |
| usuario_id | bigint | FK | No | usuarios_usuario.id |
| tipo | varchar(10) |  | No |  |
| anterior | integer unsigned |  | No |  |
| posterior | integer unsigned |  | No |  |
| variacion | integer |  | No |  |
| motivo | varchar(240) |  | No |  |
| destino | varchar(120) |  | No |  |
| fecha | datetime |  | No |  |
| token | char(32) | UK | No |  |
| detalle_solicitud_id | bigint | FK UK | Sí | inventario_detallesolicitud.id |

Restricciones: `movimiento_saldo_cuadra`, `movimiento_saldo_maximo`, `movimiento_tipo_valido`, `movimiento_signo_valido`, `movimiento_destino_salida`.

### usuarios_usuario

| Campo | Tipo SQL | Clave | Nulo | Relación |
|---|---|---|---|---|
| id | integer | PK | No |  |
| password | varchar(128) |  | No |  |
| last_login | datetime |  | Sí |  |
| is_superuser | bool |  | No |  |
| first_name | varchar(150) |  | No |  |
| last_name | varchar(150) |  | No |  |
| email | varchar(254) |  | No |  |
| is_staff | bool |  | No |  |
| is_active | bool |  | No |  |
| date_joined | datetime |  | No |  |
| username | varchar(150) | UK | No |  |
| rol | varchar(20) |  | No |  |

## Integridad y compatibilidad

- El proveedor puede ser nulo en registros antiguos; el formulario de productos exige un proveedor activo.
- `Proveedor.nombre` representa la razón social; `Producto.codigo` representa el SKU; `Producto.stock` representa el stock actual.
- `DetalleSolicitud.cantidad` representa la cantidad solicitada. Aprobada y despachada se actualizan por el servicio.
- La relación de un movimiento con su solicitud pasa por `detalle_solicitud.solicitud`, evitando dos referencias inconsistentes.
- Todas las relaciones históricas usan PROTECT. Una solicitud pendiente elimina sus detalles con CASCADE.
- Despacho completo: las cantidades aprobadas igualan las solicitadas y el despacho registra una salida por detalle.
- El servicio usa transacciones cortas IMMEDIATE y actualizaciones condicionadas al saldo anterior en SQLite.
