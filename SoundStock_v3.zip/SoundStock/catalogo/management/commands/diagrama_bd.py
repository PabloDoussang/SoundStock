from pathlib import Path

from django.apps import apps
from django.conf import settings
from django.core.management.base import BaseCommand
from django.db import connection
from PIL import Image, ImageDraw, ImageFont


ETIQUETAS = [('catalogo', 'Categoria'), ('catalogo', 'Proveedor'),
    ('catalogo', 'Producto'), ('inventario', 'Sucursal'),
    ('inventario', 'Solicitud'), ('inventario', 'DetalleSolicitud'),
    ('inventario', 'Movimiento'), ('usuarios', 'Usuario')]


def fuente(tamano, negrita=False):
    candidatas = [
        'C:/Windows/Fonts/arialbd.ttf' if negrita else 'C:/Windows/Fonts/arial.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if negrita else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    ]
    for path in candidatas:
        if Path(path).exists():
            return ImageFont.truetype(path, tamano)
    return ImageFont.load_default(size=tamano)


def clave(field):
    return 'PK' if field.primary_key else 'FK UK' if field.is_relation and field.unique else 'FK' if field.is_relation else 'UK' if field.unique else ''


def generar_imagen(modelos, destino):
    ancho, margen, tarjeta, salto = 2200, 70, 1000, 36
    filas = [modelos[i:i + 2] for i in range(0, len(modelos), 2)]
    alturas = [130 + salto * max(len(m._meta.local_fields) for m in fila) for fila in filas]
    alto = 210 + sum(alturas) + margen * len(filas) + 70
    imagen = Image.new('RGB', (ancho, alto), '#f2f6fa')
    d = ImageDraw.Draw(imagen)
    d.text((margen, 45), 'SoundStock  ·  Bodega  ·  SQLite', font=fuente(48, True), fill='#183750')
    d.text((margen, 117), 'Ocho entidades de negocio. FK indica la tabla relacionada y PROTECT conserva el historial.', font=fuente(25), fill='#41586a')
    y = 190
    for fila, altura in zip(filas, alturas):
        for col, modelo in enumerate(fila):
            x = margen + col * (tarjeta + 60)
            d.rounded_rectangle((x, y, x + tarjeta, y + altura), radius=16, fill='white', outline='#c5d5e1', width=2)
            d.rounded_rectangle((x, y, x + tarjeta, y + 70), radius=16, fill='#275473')
            d.rectangle((x, y + 50, x + tarjeta, y + 70), fill='#275473')
            d.text((x + 20, y + 16), modelo._meta.db_table, font=fuente(30, True), fill='white')
            for i, field in enumerate(modelo._meta.local_fields):
                cy = y + 90 + i * salto
                marca = clave(field)
                tipo = field.get_internal_type()
                if field.is_relation:
                    tipo = f'→ {field.related_model._meta.db_table}'
                elif getattr(field, 'max_length', None):
                    tipo += f'({field.max_length})'
                texto = f'{marca + "  " if marca else ""}{field.column}'
                d.text((x + 20, cy), texto, font=fuente(24, bool(marca)), fill='#183750')
                d.text((x + tarjeta - 20, cy), tipo, font=fuente(22), anchor='ra', fill='#526b7c')
        y += altura + margen
    d.text((margen, alto - 60), 'PK: primaria   ·   FK: foránea   ·   UK: única   ·   Relaciones y restricciones completas en DIAGRAMA_BD.md', font=fuente(24), fill='#41586a')
    imagen.save(destino, optimize=True)


class Command(BaseCommand):
    help = 'Genera el modelo y diccionario actuales de bodega desde los modelos Django.'

    def handle(self, *args, **options):
        modelos = [apps.get_model(app, nombre) for app, nombre in ETIQUETAS]
        lines = ['# Modelo de datos de SoundStock Bodega', '',
            'Generado con `python manage.py diagrama_bd` a partir de los ocho modelos de negocio.',
            'Se conserva el nombre `Movimiento` del proyecto original para implementar `MovimientoStock` de la guía.',
            'Las tablas internas de autenticación, grupos, permisos y sesiones son administradas por Django.', '',
            '```mermaid', 'erDiagram', '    direction TB']
        for modelo in modelos:
            lines.append(f'    {modelo._meta.db_table} {{')
            for field in modelo._meta.local_fields:
                key = clave(field).replace(' ', ',')
                lines.append(f'        {field.get_internal_type()} {field.column}{" " + key if key else ""}')
            lines.append('    }')
        for modelo in modelos:
            for field in modelo._meta.local_fields:
                if field.is_relation:
                    uno = '|o' if field.null else '||'
                    varios = 'o|' if field.one_to_one else 'o{'
                    lines.append(f'    {field.related_model._meta.db_table} {uno}--{varios} {modelo._meta.db_table} : {field.column}')
        lines += ['```', '', '## Diccionario de datos', '']
        for modelo in modelos:
            lines += [f'### {modelo._meta.db_table}', '', '| Campo | Tipo SQL | Clave | Nulo | Relación |', '|---|---|---|---|---|']
            for field in modelo._meta.local_fields:
                relation = f'{field.related_model._meta.db_table}.{field.target_field.column}' if field.is_relation else ''
                lines.append(f'| {field.column} | {field.db_type(connection)} | {clave(field)} | {"Sí" if field.null else "No"} | {relation} |')
            if modelo._meta.constraints:
                lines += ['', 'Restricciones: ' + ', '.join(f'`{c.name}`' for c in modelo._meta.constraints) + '.']
            lines.append('')
        lines += ['## Integridad y compatibilidad', '',
            '- El proveedor puede ser nulo en registros antiguos; el formulario de productos exige un proveedor activo.',
            '- `Proveedor.nombre` representa la razón social; `Producto.codigo` representa el SKU; `Producto.stock` representa el stock actual.',
            '- `DetalleSolicitud.cantidad` representa la cantidad solicitada. Aprobada y despachada se actualizan por el servicio.',
            '- La relación de un movimiento con su solicitud pasa por `detalle_solicitud.solicitud`, evitando dos referencias inconsistentes.',
            '- Todas las relaciones históricas usan PROTECT. Una solicitud pendiente elimina sus detalles con CASCADE.',
            '- Despacho completo: las cantidades aprobadas igualan las solicitadas y el despacho registra una salida por detalle.',
            '- El servicio usa transacciones cortas IMMEDIATE y actualizaciones condicionadas al saldo anterior en SQLite.', '']
        carpeta = settings.BASE_DIR / 'archivos_de_apoyo'
        carpeta.mkdir(parents=True, exist_ok=True)
        target = carpeta / 'DIAGRAMA_BD.md'
        target.write_text('\n'.join(lines), encoding='utf-8')
        generar_imagen(modelos, carpeta / 'IMAGEN_MODELO_BD.png')
        self.stdout.write(self.style.SUCCESS(f'Modelo y diccionario actualizados: {target}'))
