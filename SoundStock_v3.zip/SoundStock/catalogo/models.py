from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models
from django.db.models import Q


class Categoria(models.Model):
    nombre = models.CharField(max_length=60, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        ordering = ['nombre']
        verbose_name = 'categoría'
        verbose_name_plural = 'categorías'

    def __str__(self):
        return self.nombre


class Proveedor(models.Model):
    nombre = models.CharField('razón social', max_length=150, unique=True)
    rut = models.CharField('RUT', max_length=20, unique=True, null=True, blank=True)
    contacto = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    activo = models.BooleanField(default=True)

    class Meta:
        ordering = ['nombre']
        verbose_name_plural = 'proveedores'

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    codigo = models.CharField('SKU', max_length=30, unique=True,
        validators=[RegexValidator(r'^[A-Z0-9-]{3,30}$', 'Usa de 3 a 30 letras mayúsculas, números o guiones.')])
    nombre = models.CharField(max_length=120, db_index=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT, related_name='productos')
    proveedor = models.ForeignKey(Proveedor, on_delete=models.PROTECT, related_name='productos',
        null=True, blank=True, help_text='Puede quedar pendiente para conservar el catálogo anterior.')
    precio = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0'),
        validators=[MinValueValidator(Decimal('0'))], help_text='Precio unitario en CLP.')
    ubicacion = models.CharField(max_length=60, db_index=True)
    stock = models.PositiveIntegerField(default=0, validators=[MaxValueValidator(1000000)])
    stock_minimo = models.PositiveIntegerField(default=0, validators=[MaxValueValidator(1000000)])
    activo = models.BooleanField(default=True)
    descripcion = models.TextField(blank=True, default='')

    class Meta:
        ordering = ['nombre', 'pk']
        verbose_name = 'producto'
        verbose_name_plural = 'productos'
        constraints = [
            models.CheckConstraint(condition=Q(precio__gte=0), name='producto_precio_no_negativo'),
            models.CheckConstraint(condition=Q(stock__lte=1000000), name='producto_stock_hasta_millon'),
            models.CheckConstraint(condition=Q(stock_minimo__lte=1000000), name='producto_minimo_hasta_millon'),
        ]
        indexes = [
            models.Index(fields=['activo', 'categoria'], name='producto_activo_categoria'),
            models.Index(fields=['stock'], name='producto_stock_idx'),
        ]

    @property
    def estado_stock(self):
        if self.stock == 0:
            return 'Agotado'
        return 'Bajo' if self.stock <= self.stock_minimo else 'Disponible'

    def __str__(self):
        return f'{self.codigo} · {self.nombre}'
