"""Archivo conservado para mantener la estructura original de la app.

Los controles se escriben en las plantillas HTML. La lectura de request.POST,
la validación y las operaciones ORM se implementan en views.py.
"""
