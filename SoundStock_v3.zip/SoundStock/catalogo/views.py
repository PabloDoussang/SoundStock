from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Count, F, Q, Sum
from django.db.models.deletion import ProtectedError
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from inventario.access import roles_permitidos
from .models import Categoria, Producto, Proveedor
from .gestion import contexto_catalogo


@login_required
def lista(request):
    productos = Producto.objects.select_related('categoria', 'proveedor').filter(activo=request.GET.get('archivados') != '1')
    busqueda = request.GET.get('q', '').strip()
    if busqueda:
        productos = productos.filter(Q(nombre__icontains=busqueda) | Q(codigo__icontains=busqueda) |
                                     Q(ubicacion__icontains=busqueda))
    for campo in ('categoria', 'proveedor'):
        valor = request.GET.get(campo, '')
        if valor:
            if valor.isascii() and valor.isdecimal() and len(valor) <= 10:
                productos = productos.filter(**{f'{campo}_id': int(valor)})
            else:
                productos = productos.none()
                messages.error(request, f'Filtro de {campo} inválido.')
    if request.GET.get('estado') == 'bajo':
        productos = productos.filter(stock__gt=0, stock__lte=F('stock_minimo'))
    elif request.GET.get('estado') == 'agotado':
        productos = productos.filter(stock=0)
    elif request.GET.get('estado') == 'disponible':
        productos = productos.filter(stock__gt=F('stock_minimo'))
    for parametro, lookup in (('stock_min', 'stock__gte'), ('stock_max', 'stock__lte')):
        valor = request.GET.get(parametro, '').strip()
        if valor.isascii() and valor.isdecimal() and len(valor) <= 7 and int(valor) <= 1000000:
            productos = productos.filter(**{lookup: int(valor)})
    ordenes = {
        'recientes': ('-pk',),
        'nombre_az': ('nombre', 'pk'),
        'nombre_za': ('-nombre', '-pk'),
        'stock_asc': ('stock', 'nombre', 'pk'),
        'stock_desc': ('-stock', 'nombre', 'pk'),
    }
    productos = productos.order_by(*ordenes.get(request.GET.get('orden'), ordenes['recientes']))
    por_pagina = int(request.GET.get('por_pagina', '20')) if request.GET.get('por_pagina') in ('20', '50', '100') else 20
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    resumen = productos.aggregate(unidades=Sum('stock'),
        agotados=Count('pk', filter=Q(stock=0)), bajos=Count('pk', filter=Q(stock__gt=0, stock__lte=F('stock_minimo'))))
    return render(request, 'catalogo/lista.html', {
        'pagina': Paginator(productos, por_pagina).get_page(request.GET.get('pagina')),
        'categorias': Categoria.objects.all(), 'proveedores': Proveedor.objects.all(), 'total': productos.count(),
        'filtros_query': parametros.urlencode(),
        'resumen': resumen,
    })


def _errores_modelo(errores, error):
    detalle = error.message_dict if hasattr(error, 'message_dict') else {'general': error.messages}
    for campo, lista in detalle.items():
        errores.setdefault('general' if campo == '__all__' else campo, []).extend(str(mensaje) for mensaje in lista)


def _producto_post(request, producto):
    # Captura y validación explícitas: ningún campo POST se asigna en bloque.
    datos = {campo: request.POST.get(campo, '').strip() for campo in (
        'codigo', 'nombre', 'categoria', 'proveedor', 'precio', 'ubicacion', 'stock_minimo', 'descripcion')}
    datos['codigo'] = datos['codigo'].upper()
    errores = {}
    relaciones = {}
    for campo, modelo in (('categoria', Categoria), ('proveedor', Proveedor)):
        raw = datos[campo]
        qs = modelo.objects.filter(activo=True) if campo == 'proveedor' else modelo.objects.all()
        registro = qs.filter(pk=int(raw)).first() if raw.isascii() and raw.isdecimal() and len(raw) <= 18 else None
        if registro is None:
            errores[campo] = ['Selecciona un registro válido y disponible.']
        else:
            relaciones[campo] = registro
    try:
        precio = Decimal(datos['precio'].replace(',', '.'))
        if not precio.is_finite() or precio < 0 or precio > Decimal('9999999999.99') or precio.as_tuple().exponent < -2:
            raise ValueError
    except (InvalidOperation, ValueError):
        errores['precio'] = ['Ingresa un precio no negativo, con hasta dos decimales y diez dígitos enteros.']
        precio = Decimal('0')
    raw = datos['stock_minimo']
    if not raw.isascii() or not raw.isdecimal() or len(raw) > 7 or int(raw) > 1000000:
        errores['stock_minimo'] = ['Ingresa un entero entre 0 y 1.000.000.']
        minimo = 0
    else:
        minimo = int(raw)
    if not errores:
        producto.codigo = datos['codigo']
        producto.nombre = datos['nombre']
        producto.categoria = relaciones['categoria']
        producto.proveedor = relaciones['proveedor']
        producto.precio = precio
        producto.ubicacion = datos['ubicacion']
        producto.stock_minimo = minimo
        producto.descripcion = datos['descripcion']
        # También se conservan las validaciones y restricciones de los modelos.
        try:
            producto.full_clean()
        except ValidationError as error:
            _errores_modelo(errores, error)
    return datos, errores


def _pantalla_producto(request, producto, titulo, datos=None, errores=None):
    if datos is None:
        datos = {campo: str(getattr(producto, campo)) for campo in (
            'codigo', 'nombre', 'precio', 'ubicacion', 'stock_minimo', 'descripcion')}
        datos.update(categoria=str(producto.categoria_id or ''), proveedor=str(producto.proveedor_id or ''))
    return render(request, 'catalogo/formulario.html', {
        'titulo': titulo, 'tipo_formulario': 'producto', 'datos': datos, 'errores': errores or {},
        'categorias': Categoria.objects.all(), 'proveedores': Proveedor.objects.filter(activo=True),
    })


@roles_permitidos('Administrador', 'Operador')
def crear(request):
    producto = Producto()
    datos, errores = None, {}
    if request.method == 'POST':
        datos, errores = _producto_post(request, producto)
        if not errores:
            try:
                with transaction.atomic():
                    producto.save()
                messages.success(request, 'Producto creado. Registra sus existencias desde Movimientos.')
                return redirect('productos')
            except IntegrityError:
                errores['general'] = ['El SKU ya existe o un registro relacionado cambió. Revisa los datos.']
    return _pantalla_producto(request, producto, 'Nuevo producto', datos, errores)


@roles_permitidos('Administrador', 'Operador')
def editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk, activo=True)
    datos, errores = None, {}
    if request.method == 'POST':
        datos, errores = _producto_post(request, producto)
        if not errores:
            try:
                with transaction.atomic():
                    # No sobrescribir stock, estado ni campos ajenos al formulario.
                    producto.save(update_fields=['codigo', 'nombre', 'categoria', 'proveedor', 'precio',
                        'ubicacion', 'stock_minimo', 'descripcion'])
                messages.success(request, 'Producto actualizado.')
                return redirect('productos')
            except IntegrityError:
                errores['general'] = ['El SKU ya existe o un registro relacionado cambió. Revisa los datos.']
    return _pantalla_producto(request, producto, 'Editar producto', datos, errores)


@require_POST
@roles_permitidos('Administrador')
def archivar(request, pk):
    with transaction.atomic():
        producto = get_object_or_404(Producto.objects.select_for_update(), pk=pk)
        if producto.activo and producto.stock:
            messages.error(request, 'Antes de archivar, el stock debe quedar en cero.')
        else:
            producto.activo = not producto.activo
            producto.save(update_fields=['activo'])
            messages.success(request, 'Estado del producto actualizado.')
    return redirect('productos')


@roles_permitidos('Administrador')
def eliminar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        try:
            with transaction.atomic():
                producto = Producto.objects.select_for_update().get(pk=pk)
                if producto.stock or producto.movimientos.exists():
                    raise ProtectedError('Producto con existencias o historial', [producto])
                producto.delete()
            messages.success(request, 'Producto eliminado.')
        except ProtectedError:
            messages.error(request, 'No puedes eliminar productos con stock, movimientos o solicitudes. Usa Archivar.')
        return redirect('productos')
    return render(request, 'catalogo/eliminar.html', {'producto': producto})


@login_required
def categorias(request):
    return render(request, 'gestion/lista.html', contexto_catalogo(request, Categoria,
        titulo='Categorías', nombre='categorias', campos=('nombre', 'descripcion')))


@login_required
def proveedores(request):
    return render(request, 'gestion/lista.html', contexto_catalogo(request, Proveedor,
        titulo='Proveedores', nombre='proveedores', campos=('nombre', 'rut', 'contacto', 'email', 'telefono', 'activo')))


def _guardar_catalogo(request, modelo, tipo, titulo, volver, campos, pk=None):
    obj = get_object_or_404(modelo, pk=pk) if pk else modelo()
    errores = {}
    datos = {campo: getattr(obj, campo) for campo in campos}
    if request.method == 'POST':
        datos = {campo: request.POST.get(campo, '').strip() for campo in campos}
        if 'activo' in campos:
            datos['activo'] = datos['activo'].lower() in ('on', '1', 'true')
        if 'rut' in campos:
            datos['rut'] = datos['rut'].upper() or None
        for campo in campos:
            setattr(obj, campo, datos[campo])
        try:
            obj.full_clean()
        except ValidationError as error:
            _errores_modelo(errores, error)
        if not errores:
            try:
                with transaction.atomic():
                    obj.save()
                messages.success(request, 'Registro guardado.')
                return redirect(volver)
            except IntegrityError:
                errores['general'] = ['Ya existe un registro con esos datos.']
    return render(request, 'gestion/formulario.html', {
        'titulo': f'{"Editar" if pk else "Crear"}: {titulo}', 'tipo_formulario': tipo,
        'datos': datos, 'errores': errores, 'volver': volver,
    })


@roles_permitidos('Administrador', 'Operador')
def categoria_guardar(request, pk=None):
    return _guardar_catalogo(request, Categoria, 'categoria', 'Categorías', 'categorias', ('nombre', 'descripcion'), pk)


@roles_permitidos('Administrador', 'Operador')
def proveedor_guardar(request, pk=None):
    return _guardar_catalogo(request, Proveedor, 'proveedor', 'Proveedores', 'proveedores',
        ('nombre', 'rut', 'contacto', 'email', 'telefono', 'direccion', 'activo'), pk)


def _eliminar_catalogo(request, modelo, pk, volver):
    obj = get_object_or_404(modelo, pk=pk)
    if request.method == 'POST':
        try:
            with transaction.atomic():
                obj.delete()
            messages.success(request, 'Registro eliminado.')
        except ProtectedError:
            messages.error(request, 'El registro tiene productos o solicitudes asociados y se debe conservar.')
        return redirect(volver)
    return render(request, 'gestion/eliminar.html', {'objeto': obj, 'volver': volver})


@roles_permitidos('Administrador')
def categoria_eliminar(request, pk):
    return _eliminar_catalogo(request, Categoria, pk, 'categorias')


@roles_permitidos('Administrador')
def proveedor_eliminar(request, pk):
    return _eliminar_catalogo(request, Proveedor, pk, 'proveedores')
