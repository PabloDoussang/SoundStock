from django.urls import path

from . import views

urlpatterns = [
    path('categorias/', views.categorias, name='categorias'),
    path('categorias/nueva/', views.categoria_guardar, name='categorias_crear'),
    path('categorias/<int:pk>/editar/', views.categoria_guardar, name='categorias_editar'),
    path('categorias/<int:pk>/eliminar/', views.categoria_eliminar, name='categorias_eliminar'),
    path('proveedores/', views.proveedores, name='proveedores'),
    path('proveedores/nuevo/', views.proveedor_guardar, name='proveedores_crear'),
    path('proveedores/<int:pk>/editar/', views.proveedor_guardar, name='proveedores_editar'),
    path('proveedores/<int:pk>/eliminar/', views.proveedor_eliminar, name='proveedores_eliminar'),
    path('', views.lista, name='productos'),
    path('nuevo/', views.crear, name='producto_crear'),
    path('<int:pk>/editar/', views.editar, name='producto_editar'),
    path('<int:pk>/archivar/', views.archivar, name='producto_archivar'),
    path('<int:pk>/eliminar/', views.eliminar, name='producto_eliminar'),
]
