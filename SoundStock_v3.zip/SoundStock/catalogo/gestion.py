"""Contexto de lectura de los listados. Las operaciones POST están en views.py."""
from django.core.paginator import Paginator


def contexto_catalogo(request, modelo, *, titulo, nombre, campos):
    rows = modelo.objects.all()
    if request.GET.get('q'):
        rows = rows.filter(nombre__icontains=request.GET['q'].strip())
    pagina = Paginator(rows, 20).get_page(request.GET.get('pagina'))
    parametros = request.GET.copy()
    parametros.pop('pagina', None)
    return {
        'titulo': titulo, 'pagina': pagina,
        'columnas': [modelo._meta.get_field(c).verbose_name.capitalize() for c in campos],
        'filas': [(obj, [('Activo' if getattr(obj, c) else 'Desactivado')
            if isinstance(getattr(obj, c), bool) else getattr(obj, c) for c in campos]) for obj in pagina],
        'crear_url': f'{nombre}_crear', 'editar_url': f'{nombre}_editar',
        'eliminar_url': f'{nombre}_eliminar', 'filtros_query': parametros.urlencode(),
    }
