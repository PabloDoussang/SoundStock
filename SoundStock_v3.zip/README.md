# SoundStock · Bodega con Django y SQLite · Evaluación 3

SoundStock administra la bodega central de Music Pro y las solicitudes de sus sucursales. Esta versión utiliza formularios HTML manuales, incorpora un panel visual con gráficos y continúa el proyecto adjunto, conserva las apps **usuarios**, **catalogo** e **inventario**, sus rutas principales y sus migraciones anteriores, y agrega las funciones exigidas para **Bodega** en la guía de la Evaluación 3.

La administración se realiza en las páginas propias del sistema: usuarios, categorías, proveedores, productos, sucursales, solicitudes, detalles y movimientos. **SQLite se mantiene por la indicación del profesor comunicada por el estudiante**, aunque la guía escrita menciona MySQL. No es necesario instalar MySQL ni cambiar de motor.

La interfaz renovada, sus gráficos y la forma de utilizarlos se explican en la [sección 19](#19-panel-visual-y-experiencia-del-crud). La adecuación a los desafíos CRUD y seguridad, sin `ProductoForm` ni `ModelForm`, se documenta en la [sección 20](#20-adecuación-a-la-práctica-crud-y-seguridad).

## 1. Alcance de la guía y criterios utilizados

Documento revisado: `E3 Evaluacion_inv_Caso_Semestral_Music_pro_U2 Backend(3).docx`, incluidos el texto, las tablas y el diagrama incrustado de Bodega.

La sección **“Evaluación 3: Escala de apreciación” está vacía**: contiene filas numeradas del 1 al 10, sin indicadores, descriptores ni puntajes. Por ello no se inventa una nota ni una rúbrica. La implementación se contrasta con los requisitos explícitos y los criterios **2.1.1, 2.1.3 y 2.1.4**.

| Requisito de la Evaluación 3 | Implementación y evidencia |
|---|---|
| 2.1.1: conexión local y persistencia | SQLite en `SoundStock/SoundStock/settings.py`; migraciones incluidas; comando `verificar_bd` |
| Administrador propio, sin utilizar Django Admin | Menú y formularios propios en `templates/`; `/admin/` deshabilitado por defecto |
| Inicio y cierre de sesión con Django | `usuarios/views.py`: `authenticate`, `login`, `logout`, sesiones y formulario POST de salida |
| Decoradores y restricción de URL directa | `@login_required` y `@roles_permitidos`; este último utiliza internamente `login_required` |
| Mantención de usuarios | Alta, consulta, edición, cambio de contraseña, desactivación y reactivación en `/usuarios/` |
| 2.1.3: CRUD de las entidades del caso | Categorías, proveedores, productos, sucursales, solicitudes y detalles; movimientos con reglas de integridad |
| 2.1.4: seguridad y acceso a datos | Roles comprobados en servidor, contraseñas con hash de Django, CSRF, operaciones POST y relaciones protegidas |
| Consultas exclusivamente con ORM | Las 20 consultas de Bodega en `inventario/reportes.py`, visibles en `/reportes/` |
| Interfaz funcional y persistencia comprobable | Pruebas de formularios, usuarios, stock, solicitudes, sesiones y consultas |
| Comprensión para la defensa individual | Recorrido, archivos relevantes y preguntas de explicación en la sección 15 |

La guía menciona un informe individual de **10 consultas que entregará el docente**, pero la tabla de Bodega ofrece **20**. Se implementan las 20 para disponer de la lista completa. Cuando el profesor indique las 10 definitivas, identifica sus números y prepara esas evidencias.

Las secciones de **Tienda, Transporte y Tarjetas** quedan fuera del proyecto. La API REST con DRF y JWT figura en la unidad semestral posterior; no se presenta como una función implementada ni como requisito específico de esta E3 de CRUD y sesiones.

## 2. Estructura que se conserva

Abre en VS Code la carpeta extraída que contiene este `README.md` y la carpeta `SoundStock`. Dentro de `SoundStock` está `manage.py`; la segunda carpeta `SoundStock/SoundStock` es la configuración normal de un proyecto Django.

| Carpeta o archivo | Responsabilidad |
|---|---|
| `SoundStock/SoundStock/` | Configuración, SQLite y rutas generales |
| `SoundStock/usuarios/` | Usuario personalizado, roles y vistas de mantención con captura manual de POST |
| `SoundStock/catalogo/` | Categorías, proveedores, productos y vistas compartidas para catálogos |
| `SoundStock/inventario/` | Sucursales, solicitudes, detalles, movimientos, servicios de stock y reportes |
| `SoundStock/templates/` | Páginas del sistema; conserva el diseño base y los estilos anteriores |
| `SoundStock/static/sitio.css` | Diseño de la interfaz, componentes y adaptación a móvil |
| `SoundStock/static/ui.js` | Menú móvil, filtros contextuales y formularios |
| `SoundStock/static/graficos.js` | Gráficos locales, leyendas y valores al pasar el cursor |
| `SoundStock/*/migrations/` | Historial original y nuevas migraciones de la E3 |
| `SoundStock/archivos_de_apoyo/` | Modelo de datos y evidencias técnicas |
| `SEEDS.md` | Acceso a los comandos de carga |
| `GUIA_FAKER_Y_ARCHIVOS.txt` | Guía de las cargas de volumen de la etapa anterior |
| `ACCESO_LOCAL.txt` | Credenciales locales de demostración; excluido de Git |

Los archivos `admin.py` se conservan para mantener el trabajo de la Evaluación 2. **No es necesario entrar a Django Admin para realizar ninguna operación de esta entrega.** La URL `/admin/` devuelve 404 con la configuración normal.

## 3. Abrir y ejecutar la entrega existente en Windows

Requisitos: **Python 3.12 o superior compatible con Django 6.1**, SQLite incluido en Python, VS Code y acceso a internet para instalar las dependencias. El proyecto se verificó con Python 3.12 y las versiones fijadas en `requirements.txt`.

En la terminal **Símbolo del sistema / CMD**, desde la carpeta exterior donde está este README:

```cmd
python -m venv venv
venv\Scripts\activate.bat
cd SoundStock
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_bodega
python manage.py check
python manage.py runserver 127.0.0.1:8000
```

Abre **http://127.0.0.1:8000/**. Si no has iniciado sesión, te enviará a `/ingresar/`. Usa la cuenta local indicada en `ACCESO_LOCAL.txt`. La migración histórica `usuarios/0002_cuenta_demostracion.py` conserva su creación automática en una base nueva.

`seed_bodega` prepara 12 productos del catálogo original con precios de ejemplo, dos proveedores, tres sucursales, solicitudes en los cuatro estados y dos cuentas adicionales (`operador_demo` y `consulta_demo`). Sus credenciales están en `ACCESO_LOCAL.txt`. Se puede repetir el comando sin duplicar las solicitudes de muestra ni descontar otra vez el stock.

Las cuentas, direcciones y precios de muestra sirven para la demostración; no representan datos comerciales reales. La cuenta automática es de uso local. Para una cuenta personal utiliza:

```cmd
python manage.py createsuperuser
```

Si ya tienes un entorno virtual, actívalo e instala `requirements.txt`; no necesitas crearlo otra vez. Para detener el servidor utiliza `Ctrl+C`. Si el puerto 8000 está ocupado, usa `python manage.py runserver 127.0.0.1:8001` y cambia el puerto en el navegador.

En Linux o macOS, desde la carpeta exterior:

```bash
python3 -m venv venv
source venv/bin/activate
cd SoundStock
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_bodega
python manage.py runserver 127.0.0.1:8000
```

El ZIP contiene código y migraciones. No incluye `venv`, bases SQLite, secretos locales ni cachés de Python. La base `SoundStock/db.sqlite3` se crea al ejecutar `migrate`.

## 4. Actualizar una copia que ya tiene datos

1. Detén el servidor y guarda una copia de tu carpeta actual.
2. Desde la carpeta que contiene `manage.py`, respalda la base:

   ```cmd
   copy db.sqlite3 db_respaldo.sqlite3
   ```

3. Actualiza los archivos del código. Conserva tu `db.sqlite3`, el respaldo y el archivo local de clave secreta.
4. Activa el entorno e instala las dependencias de la entrega.
5. Ejecuta:

   ```cmd
   python manage.py migrate
   python manage.py makemigrations --check --dry-run
   python manage.py verificar_bd
   ```

Las migraciones nuevas son `catalogo/0004_...` e `inventario/0003_...`. No se borran ni reescriben las migraciones recibidas. No ejecutes `startproject`, `startapp`, borres migraciones ni elimines tu base para actualizar.

Los productos anteriores conservan sus SKU, nombres, categorías, ubicaciones, cantidades y movimientos. El nuevo precio parte en **0,00 CLP** y el proveedor puede quedar sin asignar en registros heredados. Completa ambos en **Productos → Editar** antes de usar la valorización como información real. El formulario propio exige un proveedor activo al crear o actualizar productos.

`seed_bodega` es opcional en una base existente: agrega datos ficticios identificados como Demo y completa precios cero o proveedores faltantes en los SKU `MP-` del catálogo original. Si quieres conservar un catálogo exclusivamente real, no lo ejecutes y carga esos datos desde la interfaz.

## 5. Modelos y correspondencia con el diagrama de Bodega

| Entidad de la guía | Implementación | Información principal |
|---|---|---|
| Categoria | `catalogo.Categoria` | Nombre y descripción |
| Proveedor | `catalogo.Proveedor` | Razón social, RUT opcional y único, contacto, email, teléfono, dirección y estado activo |
| Producto | `catalogo.Producto` | SKU, nombre, descripción, categoría, proveedor, precio, ubicación, stock, stock mínimo y estado activo |
| Sucursal | `inventario.Sucursal` | Código único, nombre, dirección, contacto y estado activo |
| Solicitud | `inventario.Solicitud` | Sucursal, usuario, fecha, estado, observación, respuesta y responsables de revisión y despacho |
| DetalleSolicitud | `inventario.DetalleSolicitud` | Producto, cantidad solicitada, aprobada y despachada |
| MovimientoStock | `inventario.Movimiento` | Producto, responsable, tipo, saldos, variación, motivo, destino, fecha y relación al detalle despachado |
| Usuario | `usuarios.Usuario` | Autenticación Django y rol Administrador, Operador o Consulta |

Se conservan nombres que ya existían en el proyecto. Las equivalencias son:

| Nombre del diagrama de referencia | Campo del proyecto |
|---|---|
| `producto.sku` | `Producto.codigo` |
| `producto.stock_actual` | `Producto.stock` |
| `proveedor.razon_social` | `Proveedor.nombre`, presentado como “razón social” |
| `detalle_solicitud.cantidad_solicitada` | `DetalleSolicitud.cantidad` |
| `movimiento_stock.cantidad` | Valor absoluto de `Movimiento.variacion`; el signo identifica entrada o salida |
| `movimiento_stock.observacion` | `Movimiento.motivo` y `Movimiento.destino` |
| `movimiento_stock.solicitud_id` | `Movimiento.detalle_solicitud.solicitud_id` |

La relación del movimiento con la solicitud pasa por su detalle para identificar exactamente qué producto se despachó y evitar referencias contradictorias. Los movimientos manuales no necesitan solicitud. Cada producto tiene un proveedor principal, como en el diagrama adjunto.

Se usa `DecimalField(12, 2)` para precios no negativos. El stock y las cantidades se limitan a 1.000.000 de unidades. El SKU y el código de sucursal son únicos. Si no escribes código de sucursal, el formulario genera uno. El RUT se normaliza en mayúsculas y se comprueba su unicidad cuando se informa; no se implementa cálculo de su dígito verificador.

Genera o actualiza el modelo desde el código:

```cmd
python manage.py diagrama_bd
```

Resultados: [diagrama y diccionario](SoundStock/archivos_de_apoyo/DIAGRAMA_BD.md) e [imagen del modelo](SoundStock/archivos_de_apoyo/IMAGEN_MODELO_BD.png). Son los modelos actuales; la imagen anterior de cuatro tablas fue reemplazada.

## 6. Autenticación, sesiones y roles

| Funcionalidad | Administrador | Operador | Consulta |
|---|---|---|---|
| Consultar productos, catálogos, sucursales, solicitudes y reportes | Sí | Sí | Sí |
| Crear y editar categorías, proveedores, productos y sucursales | Sí | Sí | No |
| Crear y editar solicitudes pendientes y sus detalles | Sí | Sí | No |
| Aprobar o rechazar solicitudes | Sí | No | No |
| Despachar solicitudes aprobadas | Sí | Sí | No |
| Registrar entradas, salidas y ajustes manuales | Sí | Sí | No |
| Corregir o eliminar el último movimiento manual | Sí | No | No |
| Eliminar registros cuando la integridad lo permite | Sí | No | No |
| Archivar o reactivar productos | Sí | No | No |
| Mantener usuarios y cambiar contraseñas | Sí | No | No |

Todos los roles corresponden a personal interno. No se implementa un portal de sucursal ni una cuenta limitada a una sola sucursal, porque la guía no exige esos perfiles.

- `ingresar`, en `usuarios/views.py`, lee `request.POST` y autentica con `authenticate` e inicia la sesión con `login` de Django. Solo admite redirecciones locales seguras. Una cuenta desactivada no puede ingresar y una sesión existente pierde acceso en la siguiente petición.
- `salir`, en `usuarios/views.py`, ejecuta `logout` de Django mediante POST. Después, abrir una URL protegida redirige al ingreso.
- `roles_permitidos`, en `inventario/access.py`, combina `login_required` con la comprobación del rol en el servidor. Ocultar un botón es solo una ayuda visual: la URL también está protegida.
- Los formularios incluyen `{% csrf_token %}`. Despachar, revisar, cambiar estados y cerrar sesión requieren POST; visitar sus direcciones con GET no modifica datos.
- Las contraseñas se reciben desde HTML manual, se comprueban con `validate_password` y se guardan como hash mediante `set_password`. Se comprueban la confirmación, los límites y los validadores configurados de Django. Las claves nunca se repueblan en el HTML; la edición no permite sobrescribir el hash directamente.
- Cambiar la contraseña propia conserva la sesión actual con `update_session_auth_hash`; otras sesiones de esa cuenta dejan de ser válidas por el mecanismo de autenticación de Django.
- Un administrador no puede desactivarse ni quitarse su propio rol desde la interfaz. Los usuarios se desactivan en vez de borrar su historial.
- Se envían cabeceras `no-store` para las páginas del sistema. La cookie de sesión es HttpOnly y SameSite=Lax. CSRF y escape de plantillas se mantienen activos.

El proyecto es para ejecución local con `runserver`. La configuración de HTTPS y un servidor de producción no forma parte de esta entrega.

## 7. Mantención desde las páginas propias

| Sección | Dirección | Qué se puede demostrar |
|---|---|---|
| Resumen | `/` | Productos activos, unidades, alertas y actividad reciente |
| Productos | `/productos/` | Crear, consultar, editar, archivar, reactivar y eliminar si no hay historial |
| Categorías | `/productos/categorias/` | CRUD de categorías y descripción |
| Proveedores | `/productos/proveedores/` | CRUD de proveedores y estado activo |
| Sucursales | `/sucursales/` | CRUD, código, datos de contacto y estado activo |
| Solicitudes | `/solicitudes/` | Solicitudes, líneas de productos, revisión y despacho |
| Movimientos | `/movimientos/` | Entradas, salidas, ajustes y corrección controlada |
| Reportes | `/reportes/` | Las 20 consultas ORM con filtros y paginación |
| Ubicaciones | `/ubicaciones/` | Resumen de existencias por ubicación |
| Usuarios | `/usuarios/` | Alta, consulta, modificación, claves y desactivación |

Orden recomendado para cargar información manualmente: **categorías → proveedores → productos → entradas de stock → sucursales → solicitudes**. No escribas el stock en el formulario del producto: registra una entrada, salida o ajuste para que quede historial.

Los listados de productos mantienen búsqueda, filtros de categoría, proveedor, stock, estado, orden y paginación. Se conserva la exportación CSV de productos y movimientos. La exportación de movimientos respeta los filtros de su listado; la de productos exporta los productos activos.

## 8. Solicitudes y control del inventario

```mermaid
stateDiagram-v2
    [*] --> pendiente
    pendiente --> aprobada: Administrador aprueba
    pendiente --> rechazada: Administrador indica motivo
    aprobada --> despachada: Administrador u operador despacha
```

1. Crea una solicitud y selecciona una sucursal activa. Agrega uno o más productos activos y cantidades enteras positivas. El botón **Agregar línea** permite añadir productos, hasta 100 líneas por solicitud.
2. Mientras esté **pendiente**, se pueden editar la cabecera y sus detalles. El administrador puede eliminarla junto con sus líneas. No se permite repetir un producto en la misma solicitud.
3. El administrador revisa su contenido y **aprueba o rechaza**. El rechazo exige un motivo. Se guarda quién revisó y cuándo.
4. Se aprueba la cantidad completa de cada línea: `cantidad_aprobada = cantidad`. Rechazar deja la cantidad aprobada en cero. No se implementan aprobaciones parciales.
5. La aprobación **no reserva ni descuenta stock**. Antes de despachar, comprueba la disponibilidad del inventario.
6. Al **despachar**, se exige una sucursal activa, productos activos y stock suficiente para todas las líneas. Se crea una salida por producto, se registra el destino y responsable, y se actualizan las cantidades despachadas y la fecha del despacho.
7. Si una línea falla, la transacción revierte todas las salidas, cantidades y cambios de estado. La solicitud permanece aprobada y se puede reintentar después de reponer existencias.
8. Repetir el POST de un despacho ya completado no vuelve a descontar stock. Una relación uno a uno con cada detalle impide duplicar su movimiento de despacho.
9. Las solicitudes atendidas conservan su contenido e historial: no se editan ni se eliminan desde la interfaz. Las salidas de despacho tampoco se corrigen o eliminan de manera aislada. Una devolución física se registra con un movimiento compensatorio y su motivo.

Este alcance corresponde a **despachos completos**, sin reservas ni entregas parciales. Las cantidades solicitadas, aprobadas y despachadas se muestran por separado, tal como las distingue el diagrama del documento.

## 9. Entradas, salidas, ajustes y reglas de integridad

`inventario/services.py` concentra la lógica de stock para evitar que cada vista calcule saldos de manera distinta.

| Operación | Efecto |
|---|---|
| Entrada | Suma una cantidad positiva al stock actual |
| Salida | Resta una cantidad positiva; exige destino y stock suficiente |
| Ajuste | Fija el saldo físico final; la variación se calcula respecto del saldo anterior |
| Corregir último movimiento manual | Recalcula ese movimiento y el stock; no permite cambiar su producto |
| Eliminar último movimiento manual | Restaura el saldo anterior del producto |

Solo se corrige o elimina **el último movimiento según su ID para ese producto**, y nunca una salida enlazada a un despacho. Los movimientos anteriores se conservan para no invalidar los saldos posteriores. El formulario de alta usa un token UUID; repetir exactamente una operación con el mismo token no duplica stock, y reutilizarlo con datos diferentes se rechaza.

La base comprueba que `posterior = anterior + variacion`, el signo del movimiento, los tipos admitidos, los límites de saldo y la presencia de destino en una salida. También exige `0 ≤ cantidad_despachada ≤ cantidad_aprobada ≤ cantidad_solicitada`.

Las relaciones históricas usan `PROTECT`: no se elimina una categoría o un proveedor con productos, una sucursal con solicitudes ni un producto usado en solicitudes o movimientos. Un producto con stock no se elimina ni se archiva. Los pendientes sí pueden eliminar sus detalles por `CASCADE`.

**SQLite y concurrencia:** `select_for_update()` no bloquea filas en SQLite. Por ello la configuración usa `transaction_mode='IMMEDIATE'` y un tiempo de espera de 20 segundos para transacciones cortas. La actualización del producto también exige que el stock guardado siga coincidiendo con el saldo leído. Esto serializa las escrituras locales y conserva la atomicidad; SQLite puede devolver un error de bloqueo si otra escritura tarda más que el tiempo de espera. No se afirma que soporte carga ilimitada ni bloqueos de fila propios de otros motores.

## 10. Reportes de Bodega con Django ORM

Todos se consultan en `/reportes/`, con hasta 25 resultados por página. La implementación está centralizada en [inventario/reportes.py](SoundStock/inventario/reportes.py). Los datos se obtienen mediante QuerySets y agregaciones ORM; no se usa SQL directo en estos reportes.

| N.º | Pregunta o resultado | ORM principal | Filtro requerido |
|---|---|---|---|
| 1 | Todos los productos registrados | `all`, `order_by`, `values_list` | Ninguno |
| 2 | Productos de una categoría | `filter(categoria=...)` | Categoría |
| 3 | Productos con stock por debajo del mínimo | `filter(stock__lt=F('stock_minimo'))` | Ninguno |
| 4 | Los 10 productos con mayor precio | `order_by('-precio', 'pk')[:10]` | Ninguno |
| 5 | Cantidad de productos por categoría | `annotate(Count('productos'))` | Ninguno |
| 6 | Productos de un proveedor | `filter(proveedor=...)` | Proveedor |
| 7 | Solicitudes de una sucursal | `filter(sucursal=...)` | Sucursal |
| 8 | Productos y cantidades de una solicitud | `DetalleSolicitud.filter`, `values_list` | Solicitud |
| 9 | Solicitudes pendientes, aprobadas, rechazadas y despachadas | `values('estado')`, `annotate(Count('pk'))` | Ninguno |
| 10 | Solicitudes en un rango de fechas | `fecha__date__range` | Desde y hasta |
| 11 | Las cinco sucursales que más unidades solicitan | `Sum('solicitudes__detalles__cantidad')` | Ninguno |
| 12 | Productos más solicitados | `Sum('detalles_solicitud__cantidad')` | Ninguno |
| 13 | Proveedor con más productos diferentes | `Count(..., distinct=True)`, `Max` | Ninguno |
| 14 | Valor total del inventario | `Sum(ExpressionWrapper(F('precio') * F('stock')))` | Ninguno |
| 15 | Productos nunca solicitados | `filter(detalles_solicitud__isnull=True)` | Ninguno |
| 16 | Unidades salidas por producto durante el último mes | `filter(tipo='salida', fechas)`, `-Sum('variacion')` | Automático |
| 17 | Sucursales con solicitudes pendientes | `filter(solicitudes__estado='pendiente')`, `Count` | Ninguno |
| 18 | Categoría con mayor valor económico del inventario | `Sum(precio * stock)`, `Coalesce`, `order_by` | Ninguno |
| 19 | Promedio de unidades por solicitud | `Sum('detalles__cantidad')` y luego `Avg` | Ninguno |
| 20 | Cinco productos con más unidades solicitadas en un período | `filter(fecha__date__range)`, `Sum`, `order_by` | Desde y hasta |

Criterios para interpretar los resultados:

- Se incluyen productos archivados y solicitudes de todos los estados porque las preguntas se refieren a todos los registros y a las cantidades **solicitadas**. Los reportes 11, 12, 19 y 20 cuentan solicitudes rechazadas como demanda registrada; no son un reporte de ventas ni de despachos.
- El reporte 3 utiliza **menor que** el mínimo. Un producto exactamente en el mínimo queda fuera. La etiqueta histórica “Bajo” del listado de productos sigue usando menor o igual para facilitar la vigilancia preventiva.
- El reporte 5 incluye categorías sin productos. El 9 muestra los cuatro estados aunque su conteo sea cero.
- El reporte 13 devuelve todos los proveedores empatados en el máximo; si ninguno suministra productos, no devuelve un ganador.
- El reporte 16 interpreta “último mes” como **mes calendario anterior** en `America/Santiago`; incluye salidas manuales y despachos. No incluye ajustes negativos como salidas.
- Los períodos de los reportes 10 y 20 incluyen ambas fechas. Un rango invertido o una selección inválida muestra errores del formulario.
- Los desempates de los listados se resuelven por nombre o ID para mantener la paginación estable. El reporte 18 entrega una sola categoría; en un empate prevalece el menor ID.
- El reporte 19 suma las unidades de cada detalle antes de calcular el promedio entre solicitudes. No calcula el promedio de las líneas individuales.
- El valor del inventario usa los precios cargados y el stock actual; un precio heredado en cero aporta cero hasta corregirlo. SQLite maneja las expresiones decimales con sus limitaciones numéricas; esta valorización académica no sustituye un sistema contable.

Ejemplos de direcciones, sustituyendo los ID por registros de tu base:

```text
http://127.0.0.1:8000/reportes/?reporte=3
http://127.0.0.1:8000/reportes/?reporte=6&proveedor=1
http://127.0.0.1:8000/reportes/?reporte=8&solicitud=1
http://127.0.0.1:8000/reportes/?reporte=20&desde=2026-11-01&hasta=2026-11-30
```

## 11. Comprobaciones y evidencias

Desde la carpeta que contiene `manage.py`:

```cmd
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py showmigrations usuarios catalogo inventario
python manage.py test --verbosity 2
python manage.py verificar_bd --salida archivos_de_apoyo\VERIFICACION_BD.json
```

Se incluyen **59 pruebas automatizadas**: 10 de compatibilidad con el proyecto anterior en `inventario/tests.py`, 41 en `inventario/tests_e3.py` (22 de la E3, 18 de formularios HTML manuales y una regresión de codificación compatible con Windows) y 8 del panel visual en `inventario/tests_panel.py`. Las pruebas comprueban, entre otros casos:

- Inicio y cierre de sesión, bloqueo de URLs directas, POST obligatorio y CSRF.
- Roles de consulta y operador sin acceso a la mantención de usuarios o aprobación.
- CRUD de usuarios desde páginas propias, hash de contraseña, desactivación y cambio de clave.
- CRUD propio de catálogos y protección de sus relaciones.
- Solicitudes con detalles válidos; rechazo de cantidades inválidas y productos repetidos.
- Aprobación sin descuento, despacho completo, cantidades aprobadas y despachadas, repetición sin duplicación y reversión cuando una línea falla.
- Corrección del último movimiento manual y conservación de salidas asociadas a despachos.
- Las 20 consultas visibles y resultados calculados con datos de prueba conocidos; fechas, promedios, precios, empates y stock mínimo.
- Repetición de los comandos de carga sin duplicar registros ni stock.
- Totales y series de los gráficos, períodos permitidos, panel sin datos, JSON escapado, gráficos limitados a su página y formato CLP que conserva decimales.
- Ausencia de clases e importaciones de formularios Django en el código propio; controles HTML explícitos y procesamiento en `views.py`.
- Precio y mínimo obligatorios, valores no finitos, precisión decimal, relaciones inexistentes, duplicados y asignación limitada de campos POST.
- CSRF real en el ingreso y los formularios; redirecciones seguras; contraseñas inválidas, escape de HTML e imposibilidad de asignar privilegios adicionales por POST.
- Detalles de solicitud con IDs ajenos, repetidos u omitidos; límite de 100 líneas; cambios atómicos e intercambio de productos conservando los IDs.

Las pruebas usan una **base temporal independiente** y un hasher rápido únicamente bajo `override_settings` para reducir el tiempo de ejecución. La aplicación normal mantiene los hashers seguros de Django; no usa MD5 para sus cuentas.

[PRUEBAS_E3.txt](SoundStock/archivos_de_apoyo/PRUEBAS_E3.txt) registra la ejecución final. [VALIDACION_E3.json](SoundStock/archivos_de_apoyo/VALIDACION_E3.json) registra las verificaciones de entrega, incluida la actualización de una base creada con la versión original y la revisión de la interfaz. La carpeta también conserva `RESULTADOS_CARGAS.json` de la etapa anterior: es evidencia histórica y no una nueva prueba de volumen de E3.

`verificar_bd` informa motor, versión de SQLite, migraciones pendientes, integridad, claves foráneas y conteos de los ocho modelos. Sus consultas SQLite de diagnóstico (`PRAGMA`) no forman parte de las consultas de negocio: los reportes se resuelven mediante ORM.

## 12. Faker y comandos anteriores

Se conservan `cargar_catalogo`, `seed_productos`, `seed_usuarios`, `seed_movimientos` y `evaluar_cargas`. [SEEDS.md](SEEDS.md) indica sus archivos y usos.

```cmd
python manage.py seed_productos --cantidad 100
python manage.py seed_usuarios --cantidad 20
python manage.py seed_movimientos --cantidad 80 --tipo entrada
python manage.py seed_movimientos --cantidad 40 --tipo salida
```

Estos comandos anteriores sirven para probar listados y volumen. Los productos Faker pueden quedar sin precio o proveedor y no crean solicitudes: usa `seed_bodega` para una demostración pequeña de la E3, o completa los datos manualmente. Los usuarios Faker se crean desactivados.

Las cargas de 100.000 y 1.000.000 registros de la documentación histórica son opcionales y pueden tardar varios minutos. La E3 adjunta no exige repetirlas. No son necesarias para iniciar ni defender el sistema.

## 13. Cómo se construye la estructura desde cero

Esta sección conserva la secuencia de la etapa anterior como referencia. **No ejecutes estos comandos sobre la entrega existente**, porque las carpetas y aplicaciones ya están creadas.

Desde una carpeta vacía y en una terminal CMD:

```cmd
python -m venv venv
venv\Scripts\activate.bat
python -m pip install Django==6.1.2 Faker==40.43.0 Pillow==12.3.0
django-admin startproject SoundStock
cd SoundStock
django-admin startapp usuarios
django-admin startapp catalogo
django-admin startapp inventario
```

Después se configuran las apps, el usuario personalizado y SQLite; se escriben los modelos, servicios, vistas con captura manual de POST, rutas y formularios HTML en las plantillas; se generan y aplican las migraciones. `startapp` solo genera un esqueleto: no sustituye los archivos de esta entrega.

En el proyecto ya entregado utiliza `migrate`, no recrees los modelos ni regeneres todo el historial.

## 14. Archivos que conviene comprender

| Archivo, dentro de `SoundStock/` | Qué explicar |
|---|---|
| `SoundStock/settings.py` | Apps, usuario personalizado, SQLite, sesiones y transacciones IMMEDIATE |
| `SoundStock/urls.py` | Rutas propias, ingreso, salida y desactivación de Django Admin por defecto |
| `usuarios/models.py` | `AbstractUser`, rol y gestión de cuentas |
| `usuarios/views.py` | Login, logout, alta, edición, validación de contraseñas y desactivación mediante POST |
| `inventario/access.py` | Combinación de login obligatorio y autorización por rol |
| `catalogo/models.py`, `catalogo/views.py` | Modelos, CRUD manual, validación de precios, relaciones y campos permitidos |
| `catalogo/gestion.py` | Contexto reutilizable de listado y paginación; las escrituras se procesan en las vistas |
| `inventario/models.py` | Sucursales, solicitudes, cantidades y movimientos |
| `usuarios/forms.py`, `catalogo/forms.py`, `inventario/forms.py` | Archivos conservados por estructura; contienen una aclaración y no definen formularios |
| `inventario/solicitudes.py`, `inventario/views.py` | Alias compatibles para las rutas; sucursales, detalles manuales, solicitudes, movimientos y filtros se procesan en `views.py` |
| `inventario/services.py` | Operaciones atómicas, idempotencia y actualización del stock |
| `inventario/reportes.py` | Las 20 consultas ORM y sus filtros |
| `inventario/panel.py` | Agregaciones de indicadores y datos de los gráficos |
| `inventario/templatetags/presentacion.py` | Formato de números, precios y estados |
| `inventario/tests_e3.py` | Casos verificables de seguridad, solicitudes, stock y consultas |
| `templates/` | Navegación, formularios con CSRF y resultados visibles |

## 15. Recorrido para la defensa individual

1. Ejecuta `check`, `showmigrations` y `verificar_bd`. Explica que el profesor indicó conservar SQLite y que las migraciones reproducen el esquema.
2. Sin sesión, intenta abrir `/productos/`, `/usuarios/`, `/solicitudes/` y `/reportes/`. Muestra la redirección al ingreso.
3. Inicia sesión como administrador. Crea una categoría, un proveedor y un producto. Edita el producto y demuestra su persistencia al recargar.
4. Registra una entrada de 10 unidades. Explica por qué el producto no permite editar el stock directamente.
5. Crea una sucursal y una solicitud de 3 unidades del producto. Muestra los detalles y el estado pendiente.
6. Aprueba la solicitud: el stock sigue en 10 y la cantidad aprobada es 3. Despacha: el stock queda en 7 y la cantidad despachada es 3. Abre el historial de movimientos.
7. Intenta despachar otra solicitud con más stock del disponible. Muestra el mensaje y que los saldos y el estado se conservan. La prueba automática también comprueba una solicitud de varios productos, donde una línea insuficiente revierte las anteriores.
8. Crea, consulta y modifica un usuario. Desactívalo y comprueba que no puede iniciar sesión. Explica la conservación del historial y la protección de la cuenta propia.
9. Muestra al menos una consulta básica, una intermedia y una avanzada: reportes 3, 8, 14 y 19 son buenos ejemplos. Después muestra las 10 que asigne el docente.
10. Inicia sesión como Consulta e intenta una URL de creación: el servidor responde 403. Con Operador se permite la operación diaria, pero no aprobar ni mantener usuarios.
11. Cierra sesión y vuelve a intentar una URL protegida. Demuestra que se perdió el acceso.
12. Ejecuta `python manage.py test` y explica un caso real de fallo que se previene.

Preguntas que debes poder responder con tus palabras:

- ¿Qué diferencia hay entre autenticación y autorización?
- ¿Qué hacen `login_required`, `roles_permitidos` y el token CSRF?
- ¿Por qué se guarda un hash y no la contraseña escrita?
- ¿Qué diferencia hay entre `filter`, `annotate`, `aggregate`, `Count`, `Sum`, `Avg` y `F`?
- ¿Por qué un stock mínimo se compara campo contra campo con `F`?
- ¿Por qué una solicitud aprobada no modifica el stock hasta despacharse?
- ¿Qué revierte `transaction.atomic` si falla la segunda línea del despacho?
- ¿Por qué `select_for_update` por sí solo no protege una fila en SQLite?
- ¿Por qué se protegen los productos con historial y se desactivan usuarios?
- ¿Por qué el promedio del reporte 19 debe calcularse sobre el total por solicitud?

La guía advierte que una defensa sin comprensión del código puede calificarse con **1,0**, aunque la aplicación funcione. Practica el recorrido y modifica un ejemplo pequeño para comprobar que puedes explicarlo.

## 16. Uso de inteligencia artificial como apoyo

La guía permite utilizar IA y exige evaluar sus recomendaciones. En esta actualización se utilizó para contrastar los requisitos de Bodega, detectar entidades faltantes, proponer la organización dentro de las apps existentes, implementar formularios y servicios, revisar riesgos de stock y crear casos de prueba.

Las propuestas se verifican ejecutando Django, las migraciones, las pruebas y la interfaz. Una decisión concreta fue conservar SQLite por la indicación docente y usar transacciones IMMEDIATE en lugar de confiar en bloqueos de fila que SQLite no proporciona. Otra fue interpretar el promedio de unidades por solicitud mediante dos niveles de agregación.

Antes de la defensa, revisa esos archivos y contrasta los resultados de los reportes con registros que puedas calcular a mano. La explicación del trabajo debe ser propia.

## 17. Entrega y pendientes académicos

| Acción | Estado |
|---|---|
| Mantener la estructura del proyecto recibido | Realizado |
| Mantener SQLite | Realizado según indicación del profesor |
| Implementar administrador propio y usuarios | Realizado |
| Completar las entidades de Bodega | Realizado con equivalencias documentadas |
| Incorporar solicitudes, revisión, despacho y detalles | Realizado; cantidades completas, sin parcialidades |
| Implementar las 20 consultas de Bodega | Realizado |
| Ejecutar pruebas y comprobar actualización desde la versión anterior | Evidencia incluida en `archivos_de_apoyo` |
| Obtener una rúbrica con indicadores y puntajes | Pendiente del docente; la del adjunto está vacía |
| Identificar las 10 consultas definitivas asignadas | Pendiente de indicación docente |
| Preparar evidencia de esas consultas con la base de tu computador | Debe realizarse antes de la defensa |
| Practicar la explicación individual y entregar en la plataforma | Debe realizarlo el estudiante |

El README anterior incluía instrucciones de entrega de la Evaluación 2 y una rama específica de GitHub. No se afirma que esa rama contenga esta versión: **esta actualización no fue publicada ni enviada a GitHub o a INACAP**. Si el docente solicita repositorio o capturas, prepara la evidencia y sube esta versión mediante el procedimiento que indique.

Para usar excepcionalmente el Admin histórico de E2 en una terminal CMD independiente:

```cmd
set DJANGO_HABILITAR_ADMIN=1
python manage.py runserver 127.0.0.1:8000
```

Para volver a la configuración de E3, detén ese servidor, ejecuta `set DJANGO_HABILITAR_ADMIN=` e inicia de nuevo. La evaluación y las pruebas de E3 utilizan la interfaz propia.

## 18. Documentación oficial de referencia

- [Django 6.1: autenticación, sesiones y formularios de usuario](https://docs.djangoproject.com/en/6.1/topics/auth/default/)
- [Django 6.1: consultas ORM](https://docs.djangoproject.com/en/6.1/topics/db/queries/)
- [Django 6.1: agregaciones](https://docs.djangoproject.com/en/6.1/topics/db/aggregation/)
- [Django 6.1: transacciones](https://docs.djangoproject.com/en/6.1/topics/db/transactions/)
- [Django 6.1: particularidades de SQLite](https://docs.djangoproject.com/en/6.1/ref/databases/#sqlite-notes)
- [Django 6.1: protección CSRF](https://docs.djangoproject.com/en/6.1/ref/csrf/)


## 19. Panel visual y experiencia del CRUD

La interfaz utiliza un menú lateral oscuro y una zona de trabajo clara con acentos violeta y verde. Incluye navegación activa, tarjetas de indicadores, tablas con estados por color, campos agrupados, confirmación de eliminación y una pantalla de ingreso renovada. En pantallas pequeñas, el menú se abre con el botón superior y se cierra con Escape o al pulsar fuera. Las tablas anchas se pueden desplazar horizontalmente.

### Panel de control

En `/` se muestran indicadores de productos activos, valor del inventario en CLP, unidades, alertas, productos agotados y solicitudes pendientes. Las alertas cuentan stock estrictamente inferior al mínimo; la lista de reposición también incluye productos agotados aunque su mínimo sea cero.

| Gráfico | Qué representa | Alcance |
|---|---|---|
| Entradas y salidas | Unidades ingresadas y salidas por día | Últimos 7, 30 o 90 días, incluidos hoy y la fecha inicial |
| Solicitudes | Cantidad pendiente, aprobada, rechazada y despachada | Todo el historial de solicitudes |
| Unidades por categoría | Existencias de productos activos por categoría | Las ocho categorías con más unidades; puede incluir categorías con saldo cero |

El selector de período afecta **solo al gráfico de actividad**. Los indicadores de stock y el gráfico de categorías reflejan las existencias actuales; el gráfico de solicitudes conserva el historial completo. Las salidas se muestran como cantidades positivas para compararlas con las entradas. Los ajustes se muestran por separado en la tabla desplegable de datos diarios y en Movimientos. Los días sin operaciones se incluyen con cero.

Los gráficos se calculan con datos guardados mediante el ORM de Django. Se actualizan al abrir o recargar la página y al cambiar el período. No se simulan variaciones ni se agregan registros al consultar el panel. Si todavía no hay operaciones, aparecen ceros y mensajes explicativos.

### Gráficos en Reportes

Los reportes **3, 4, 5, 8, 9, 11, 12, 13, 16, 17, 18 y 20** incluyen barras o un gráfico circular cuando son apropiados para su resultado. El reporte 3 compara stock y mínimo; el 8 compara cantidades solicitadas, aprobadas y despachadas. Los reportes 14 y 19 destacan el valor total y el promedio en tarjetas. Se conserva la tabla de resultados en todos los casos.

Cada gráfico de reporte representa **la página visible, hasta 25 filas**, no la suma de páginas que no se muestran. Para otros registros utiliza la paginación. Los filtros necesarios aparecen según el reporte elegido; por ejemplo, el 6 pide proveedor y el 20 pide ambas fechas.

### Uso del CRUD

- Productos muestra tarjetas con el total de registros, unidades, stock bajo y agotados de la selección filtrada.
- Los formularios agrupan los campos, muestran qué datos son obligatorios y presentan errores junto al campo correspondiente.
- Las solicitudes muestran una secuencia de atención y sus responsables, fechas y cantidades.
- Las acciones disponibles siguen dependiendo del rol, y la autorización se mantiene en el servidor.
- La búsqueda superior consulta el catálogo de productos.
- El ingreso permite mostrar u ocultar la contraseña sin modificarla.

### Funcionamiento local y accesibilidad

El diseño y los gráficos utilizan archivos incluidos en `static/`. No requieren CDN, claves API, Chart.js, cuentas externas ni conexión a internet después de instalar las dependencias. Los iconos y gráficos se dibujan con SVG y elementos HTML. Los datos llegan al navegador mediante `json_script`, con escape de caracteres de Django; los nombres se insertan como texto.

Hay etiquetas de formulario, foco visible, navegación con teclado, valores en los gráficos al pasar el cursor o enfocar un punto, una tabla alternativa para la serie diaria y respeto por la preferencia de movimiento reducido. Los importes usan separadores chilenos y conservan hasta dos decimales cuando existen.

Esta actualización conserva las tablas, el historial de migraciones, los roles y las reglas de stock de E3. Para actualizar una instalación existente, reemplaza el código y los archivos de `static/` y `templates/` siguiendo la sección 4; no requiere nuevas migraciones de modelos. Si el navegador conserva el estilo anterior, recarga con `Ctrl+F5`.

### Comprobaciones de la versión visual

Las **59 pruebas automáticas** incluyen las anteriores, ocho del panel para verificar indicadores, períodos, estados, protección de los datos, resultados paginados, ausencia de datos y precios con decimales, y 19 para comprobar los formularios HTML manuales y su lectura compatible con Windows.

[VALIDACION_VISUAL.json](SoundStock/archivos_de_apoyo/VALIDACION_VISUAL.json) registra el recorrido en Chromium: navegación de secciones, gráficos y períodos, filtros, creación y edición de producto, entrada de stock, aprobación y despacho de una solicitud, actualización de gráficos, eliminación de un producto sin historial, menú móvil y cierre de sesión. Se verifican resoluciones de 1440 × 1050 y 390 × 844. Las capturas se utilizaron para revisión interna y no forman parte del ZIP.


## 20. Adecuación a la práctica CRUD y seguridad

Esta corrección aplica los parámetros de la práctica pegados por el estudiante. Se conserva el orden de las secciones anteriores, las apps, los archivos, las carpetas, los nombres y el orden de las rutas, los campos de cada pantalla y el menú. Tampoco cambian los modelos, las migraciones, SQLite, el diseño ni los gráficos de la versión visual.

### Formularios HTML y procesamiento en las vistas

Todos los formularios propios se escriben mediante etiquetas HTML `input`, `select` y `textarea`. La plantilla `includes/campos_formulario.html` contiene los controles explícitos de cada pantalla; no genera widgets ni recorre objetos de formulario de Django. El ingreso, los filtros de reportes y las líneas de solicitudes también utilizan HTML manual.

Las vistas leen una lista explícita de campos desde `request.POST`, validan y guardan mediante ORM. Los filtros de lectura utilizan `request.GET`. No se usan `ProductoForm`, `ModelForm`, `Form`, formularios de autenticación ni formsets en la aplicación propia. Los tres archivos `forms.py` se conservan para respetar la estructura, pero ya no definen clases ni se importan. `inventario/solicitudes.py` conserva los nombres importados por las rutas y los enlaza a las funciones de `inventario/views.py`.

- `catalogo/views.py`: productos, categorías y proveedores; SKU normalizado, campos obligatorios, relaciones disponibles, duplicados y precio finito no negativo con hasta dos decimales. El precio admite cero; el mínimo admite enteros entre cero y un millón.
- `usuarios/views.py`: ingreso, cierre de sesión, usuarios y cambio de contraseña; email, rol, unicidad del nombre, validadores de contraseña, hash y protección de la cuenta administradora propia.
- `inventario/views.py`: sucursales, movimientos, solicitudes y filtros; cantidades enteras, sucursales/productos activos, destino obligatorio para salidas, token de idempotencia y validación de fechas y selecciones.
- Las líneas de solicitudes se capturan con nombres `detalles-0-producto`, `detalles-0-cantidad`, etc. Los campos de control conservan sus nombres para que siga funcionando el botón Agregar línea. El servidor valida el límite de 100 líneas, sus IDs, duplicados, cantidades y pertenencia a la solicitud; no confía en los campos ocultos para autorizar cambios.
- `full_clean()` valida el **modelo**, sus relaciones, unicidad y restricciones antes del guardado. No es un formulario Django. Los errores se envían como un diccionario y se muestran junto a los campos; se conserva lo escrito excepto las contraseñas.
- Los servicios de inventario siguen concentrando los cálculos y las transacciones. Una solicitud pendiente no cambia existencias y un despacho solo descuenta una vez. Un dato inválido no deja guardados parciales.

### Correspondencia con los desafíos

| Parámetro solicitado | Ubicación y comprobación |
|---|---|
| Producto con nombre, precio, stock y estado | `catalogo/models.py`: `nombre`, `precio`, `stock` y `activo`; `estado_stock` informa Agotado/Bajo/Disponible. El stock se modifica desde Movimientos y el estado mediante Archivar/Reactivar para proteger el historial. |
| Migraciones y registro en Django Admin | Se conserva el historial aplicado y el registro de `Producto` en `catalogo/admin.py`; `check` y `makemigrations --check --dry-run` verifican la coherencia. |
| Tabla HTML obtenida por ORM | `catalogo/views.py` y `templates/catalogo/lista.html`, con filtros y paginación. |
| Crear, editar y eliminar con HTML y POST | Vistas y plantillas propias de Productos; GET muestra o confirma, y la escritura se realiza con POST. La eliminación respeta el stock y las relaciones. |
| Validación, CSRF y mensajes | Comprobaciones explícitas en las vistas, validación del modelo, `{% csrf_token %}`, errores por campo y `messages`. |
| Login, sesiones y logout | `ingresar` y `salir` en `usuarios/views.py`, utilizando las funciones de autenticación de Django. |
| CRUD protegido con `login_required` | Aplicado directamente en lecturas y dentro del decorador de autorización para operaciones de escritura. |
| Grupos o perfiles | Campo `Usuario.rol`: Administrador, Operador y Consulta; matriz de permisos en la sección 6. |
| Permisos aplicados en servidor | Las vistas comprueban los roles, aunque se visite una URL directamente o se modifique el POST. |
| Decorador reutilizable y accesos no autorizados | `roles_permitidos` en `inventario/access.py`; las pruebas verifican redirección al login y respuestas 403. |
| Regla: sin ProductoForm ni ModelForm | Controles HTML y captura manual en `views.py`, con prueba automática sobre las fuentes y plantillas. |

El registro de Django Admin se mantiene porque la práctica lo exige y para conservar la compatibilidad anterior. `/admin/` continúa desactivado por defecto conforme a la guía E3. Al habilitarlo explícitamente, Django genera internamente sus pantallas estándar de catálogo y usuarios; no hay formularios personalizados basados en `ModelForm` en nuestro código. Las operaciones de movimientos del Admin reutilizan las vistas HTML manuales para conservar las reglas del stock. El recorrido de evaluación se realiza desde las páginas propias.

### Cómo comprobar esta corrección en VS Code

1. Respalda tu carpeta y tu `db.sqlite3`; reemplaza el código con esta entrega conservando la base y la clave local, como indica la sección 4.
2. Activa el entorno y entra a la carpeta donde se encuentra `manage.py`.
3. Ejecuta `python manage.py check`, `python manage.py makemigrations --check --dry-run` y `python manage.py test --verbosity 2`. El resultado de esta entrega es **59 pruebas aprobadas**, sin cambios de esquema.
4. Ejecuta `python manage.py runserver` e ingresa con tu cuenta. Crea, edita y elimina un producto sin historial; prueba un SKU repetido y un precio inválido.
5. Registra una entrada de stock, crea una solicitud con detalles, apruébala y despáchala. Comprueba el saldo y los gráficos. Agregar o editar la solicitud antes del despacho no descuenta stock.
6. Prueba perfiles Operador y Consulta, visita las URLs restringidas directamente y cierra sesión. Comprueba que el servidor bloquee las acciones y que vuelva a pedir el ingreso.
7. Para explicar el código al profesor, muestra un control HTML, su lectura mediante `request.POST`, la validación, el guardado con ORM, el token CSRF y el decorador correspondiente. No es necesario reconstruir el proyecto ni crear nuevas migraciones por esta corrección.

Las 19 pruebas adicionales cubren las reglas manuales, los intentos de manipulación y la lectura UTF-8 al simular Windows con cp1252. El recorrido en Chromium verifica también altas de catálogos, sucursales y usuarios, edición de usuario, cambio de clave, errores visibles, ingreso con la nueva contraseña y rechazo por rol. Las evidencias se registran en los archivos existentes de `archivos_de_apoyo/`.


## 21. Entrega SoundStock_v3 y revisión final

La entrega se distribuye como **SoundStock_v3.zip**. Se mantienen los 105 archivos,
las carpetas internas, los nombres y orden de las rutas, el menú, los modelos,
las migraciones, el diseño y los gráficos de la última versión HTML manual.
Esta revisión actualiza documentación y evidencias; el código funcional conserva
los mismos bytes que la entrega HTML manual anterior.

Se entrega por separado **SoundStock_v3_Cambios_y_Pruebas.txt**, con los cambios
respecto del proyecto original, los archivos relevantes, la preparación en VS Code,
los comandos de comprobación y 21 pruebas manuales con resultados esperados.
El TXT está fuera del ZIP para conservar la estructura de la entrega.

La revisión final del 6 de noviembre de 2026 se ejecutó sobre una copia extraída
del paquete y con una base SQLite nueva e independiente. Se comprobó:

- Aplicación de migraciones, carga de demostración y `check` sin problemas.
- `makemigrations --check --dry-run` sin cambios; todas las migraciones aplicadas.
- **59 pruebas automatizadas aprobadas** y dependencias sin conflictos.
- SQLite con integridad correcta, sin migraciones pendientes ni errores de claves foráneas.
- Formularios propios HTML, captura en `views.py`, CSRF y uso de ORM.
- Recorrido en Chromium: nueve secciones, gráficos, períodos, filtros, CRUD de
  productos, movimientos, aprobación y despacho, eliminación y cierre de sesión.
- Altas de categorías, proveedores, sucursales y usuarios; edición de usuario,
  validación de contraseñas, cambio de clave, nuevo ingreso y bloqueo por rol.
- Adaptación móvil, menú con teclado y ausencia de errores de JavaScript o
  solicitudes a servicios externos durante ese recorrido.

Los resultados están en los archivos existentes `archivos_de_apoyo/PRUEBAS_E3.txt`,
`VALIDACION_E3.json` y `VALIDACION_VISUAL.json`. Las capturas y bases de prueba son
evidencia interna de revisión y no se incluyen en el ZIP. Las verificaciones de
esta entrega no sustituyen el recorrido que debes realizar en tu computador ni
la explicación individual exigida por el docente.


## 22. Corrección UTF-8 de las pruebas en Windows

Se corrigieron las dos lecturas de archivos en `inventario/tests_e3.py` para
indicar `encoding='utf-8'`. Antes se utilizaba `path.read_text()` y se dependía
de la codificación del sistema. En el Windows de la captura, Python 3.13 utiliza
cp1252 para esa lectura y algunos caracteres de las plantillas UTF-8 provocaban
un `UnicodeDecodeError`.

La corrección conserva las validaciones originales y todos los archivos,
carpetas, rutas, formularios, modelos, migraciones, diseño y reglas de stock.
Solo cambia el archivo de pruebas y su documentación/evidencia. Se agregó una
regresión que simula cp1252 cuando no se indica codificación: reproduce el error
antes de la corrección y aprueba después. La suite completa ahora contiene
**59 pruebas aprobadas**. La comprobación se ejecutó en el entorno Linux de
revisión, reproduciendo la codificación observada en Windows.

Para aplicar esta corrección a tu copia existente, extrae el ZIP actualizado
en otra carpeta y reemplaza únicamente `SoundStock/inventario/tests_e3.py` en
tu proyecto. El README, el TXT externo y las evidencias también están actualizados
si deseas conservarlos junto a tu copia. Desde la carpeta con `manage.py` y con
el entorno activado ejecuta:

```cmd
python manage.py test --verbosity 2
```

El resultado esperado es `Ran 59 tests` y `OK`. Esta corrección no requiere
migraciones nuevas ni modificar o reemplazar `db.sqlite3`, y no necesita cambiar
la configuración de idioma, terminal o codificación global de Windows.
