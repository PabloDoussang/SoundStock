# Comandos de carga de SoundStock

Para demostrar la **Evaluación 3 de Bodega**, comienza con `seed_bodega`. Ejecuta los comandos dentro de `SoundStock/`, donde está `manage.py`, después de aplicar `migrate`.

| Comando | Archivo | Finalidad |
|---|---|---|
| `python manage.py seed_bodega` | [seed_bodega.py](SoundStock/inventario/management/commands/seed_bodega.py) | Datos pequeños de E3: catálogo, precios, proveedores, sucursales, usuarios y solicitudes |
| `python manage.py cargar_catalogo` | [cargar_catalogo.py](SoundStock/catalogo/management/commands/cargar_catalogo.py) | Los 12 productos originales y sus entradas de stock |
| `python manage.py seed_productos --cantidad 100` | [seed_productos.py](SoundStock/catalogo/management/commands/seed_productos.py) | Productos Faker de la etapa anterior; completar proveedor y precio si se usarán en E3 |
| `python manage.py seed_usuarios --cantidad 20` | [seed_usuarios.py](SoundStock/usuarios/management/commands/seed_usuarios.py) | Cuentas ficticias desactivadas |
| `python manage.py seed_movimientos --cantidad 80 --tipo entrada` | [seed_movimientos.py](SoundStock/inventario/management/commands/seed_movimientos.py) | Entradas de prueba sobre productos Faker |
| `python manage.py seed_movimientos --cantidad 40 --tipo salida` | [seed_movimientos.py](SoundStock/inventario/management/commands/seed_movimientos.py) | Salidas de prueba, después de cargar entradas |

Repetir una misma carga conserva los registros identificados y no vuelve a descontar el stock. Los datos son ficticios. `seed_bodega` asigna precios de ejemplo y proveedores donde faltan en los SKU originales `MP-`.

Consulta el [README actualizado](README.md) para instalar, actualizar, probar y defender la E3. Las cargas masivas de `evaluar_cargas` son una herramienta histórica de E2.
